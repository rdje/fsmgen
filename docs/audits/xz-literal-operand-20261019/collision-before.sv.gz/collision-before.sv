//=============================================================================
// Flattened Decision Tree FSM: worker
// Generated using Enable-based Methodology with WEN/EN Signals
// Date: Mon Oct 19 10:48:28 2026
// 
// This implementation uses:
// - Flattened decision tree approach
// - Enable-based logic with assign statements
// - Write Enable (WEN) and Enable (EN) signals for each LHS
// - Flat Boolean expressions from DT traversal
//=============================================================================

module worker (
  input  wire clk,
  input  wire rst_n,
  input  wire start,
  input  wire [2:0] x01,
  output reg  done,
  output reg  [2:0] result
);

  // State encoding
  localparam WORKER_IDLE_0 = 2'd0;
  localparam WORKER_SET_0 = 2'd1;
  localparam WORKER_DONE_1 = 2'd2;

  // State registers
  reg [1:0] current_state, next_state;

  // State sequential logic
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      current_state <= WORKER_IDLE_0;
    end else begin
      current_state <= next_state;
    end
  end

  // Internal signal declarations
  reg isf_child_start_seen;
  // Internal mux helper registers
  reg done_pulse_delay_pipe;
  reg isf_child_start_seen_next;
  reg [2:0] result_next;
  // Generated enable wires
  wire done_1_en;
  wire isf_child_start_seen_en;
  wire isf_child_start_seen_isf_child_start_seen_start_en;
  wire isf_child_start_seen_start_en;
  wire next_state_worker_done_1_en;
  wire next_state_worker_idle_0_en;
  wire next_state_worker_set_0_en;
  wire result_x01_en;
  wire worker_done_1_done_1_en;
  wire worker_done_1_en;
  wire worker_done_1_next_state_worker_idle_0_en;
  wire worker_idle_0_en;
  wire worker_idle_0_next_state_worker_set_0_en;
  wire worker_set_0_en;
  wire worker_set_0_next_state_worker_done_1_en;
  wire worker_set_0_result_x01_en;

  // State and DT Enable Conditions
  assign worker_done_1_en = current_state == WORKER_DONE_1;
  assign worker_idle_0_en = current_state == WORKER_IDLE_0;
  assign worker_set_0_en = current_state == WORKER_SET_0;
  assign isf_child_start_seen_en = 1'b1;

  // Consolidated intermediate signals (AST factorization + pre-scan)
  wire intermediate_and_start_not_isf_child_start_seen_1;

  assign intermediate_and_start_not_isf_child_start_seen_1 = start & !isf_child_start_seen; // Source: fsmgen_parsing

  // Unified WEN/EN Signal Generation from Phase 1 Analysis
  // DT-Specific Enable Signals from Unified Analysis


  // === DT: -isf_child_start_seen ===
  // isf_child_start_seen
  assign isf_child_start_seen_isf_child_start_seen_start_en = isf_child_start_seen_en;  // isf_child_start_seen <- start


  // === DT: worker_done_1 ===
  // done
  assign worker_done_1_done_1_en = worker_done_1_en;  // done <- 1
  // next_state
  assign worker_done_1_next_state_worker_idle_0_en = worker_done_1_en;  // next_state <- WORKER_IDLE_0


  // === DT: worker_idle_0 ===
  // next_state
  assign worker_idle_0_next_state_worker_set_0_en = worker_idle_0_en & intermediate_and_start_not_isf_child_start_seen_1;  // next_state <- WORKER_SET_0


  // === DT: worker_set_0 ===
  // next_state
  assign worker_set_0_next_state_worker_done_1_en = worker_set_0_en;  // next_state <- WORKER_DONE_1
  // result
  assign worker_set_0_result_x01_en = worker_set_0_en;  // result <- x01

  // LHS-Level Enable Signals from Unified Analysis

  // LHS-level enables for: done
  assign done_1_en = worker_done_1_done_1_en;

  // LHS-level enables for: isf_child_start_seen
  assign isf_child_start_seen_start_en = isf_child_start_seen_isf_child_start_seen_start_en;

  // LHS-level enables for: next_state
  assign next_state_worker_done_1_en = worker_set_0_next_state_worker_done_1_en;
  assign next_state_worker_idle_0_en = worker_done_1_next_state_worker_idle_0_en;
  assign next_state_worker_set_0_en = worker_idle_0_next_state_worker_set_0_en;

  // LHS-level enables for: result
  assign result_x01_en = worker_set_0_result_x01_en;

  // Unified Multiplexer Logic from Phase 1 Analysis

  // Unified Multiplexer for LHS: done
  // Delayed pulse logic for: done (<1, exact Q+1)
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      done <= 1'b0;
      done_pulse_delay_pipe <= 1'b0;
    end else begin
      done <= 1'b0;
      if (done_pulse_delay_pipe) begin
        done <= 1'b1;
      end
      done_pulse_delay_pipe <= done_1_en;
    end
  end

  // Unified Multiplexer for LHS: isf_child_start_seen
  // Unified flop with mux for: isf_child_start_seen (register_out assignment)
  always_comb begin
    isf_child_start_seen_next = isf_child_start_seen;  // Default value
    if (isf_child_start_seen_start_en) begin
      isf_child_start_seen_next = start;
    end
  end
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      isf_child_start_seen <= 0;
    end else begin
      isf_child_start_seen <= isf_child_start_seen_next;
    end
  end

  // Unified Multiplexer for LHS: next_state
  // Unified combinational mux for: next_state
  always_comb begin
    next_state = current_state;  // Default value
    if (next_state_worker_done_1_en) begin
      next_state = WORKER_DONE_1;
    end
    if (next_state_worker_idle_0_en) begin
      next_state = WORKER_IDLE_0;
    end
    if (next_state_worker_set_0_en) begin
      next_state = WORKER_SET_0;
    end
  end

  // Unified Multiplexer for LHS: result
  // Unified flop with mux for: result (register_out assignment)
  always_comb begin
    result_next = result;  // Default value
    if (result_x01_en) begin
      result_next = x01;
    end
  end
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      result <= 3'h0;
    end else begin
      result <= result_next;
    end
  end

  `ifndef SYNTHESIS
  always_comb begin
    assert ($onehot0({next_state_worker_done_1_en, next_state_worker_idle_0_en, next_state_worker_set_0_en})) else $error("selector multi-value conflict: next_state");
  end
  `endif
endmodule