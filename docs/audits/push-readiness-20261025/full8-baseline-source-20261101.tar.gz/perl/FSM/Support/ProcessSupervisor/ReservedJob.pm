package FSM::Support::ProcessSupervisor::ReservedJob;

use strict;
use warnings;

use IO::Select;
use Scalar::Util qw(refaddr);
use FSM::Support::ProcessSupervisor ();
use FSM::Support::ProcessSupervisor::GroupClosure ();

# Inactive private strategy. The coordinator reserves aggregate capacity and
# retains this prepared job BEFORE start. Only explicit release may follow
# complete ownership publication. Public/sealed callers still use the legacy
# engine; this component owns no connection, subtree or receipt-review policy.
# prepare_record/allocate also let that coordinator retain every native owner
# before descriptor creation; prepare remains the convenience composition.
my ($TERM_GRACE, $KILL_GRACE) = FSM::Support::ProcessSupervisor::_termination_graces();

sub _error { die "private reserved process: $_[0]\n" }
sub _now { return FSM::Support::ProcessSupervisor::Reservation::_now() }
sub _minimum { return $_[0] < $_[1] ? $_[0] : $_[1] }
sub _owner {
    my ($self) = @_;
    _error('invalid or inherited job') unless ref($self) eq __PACKAGE__
        && $self->{owner_pid} == $$;
    _error('invalid or copied job') unless ($self->{identity} // 0) == refaddr($self);
    _error('job lost original pair') unless ref($self->{pair})
        eq 'FSM::Support::ProcessSupervisor::GatedPair'
        && ($self->{pair_identity} // 0) == refaddr($self->{pair});
}

sub prepare_record {
    my (%args) = @_;
    _error('expected snapshot, deadline and close_handles') unless keys(%args) == 3
        && exists($args{snapshot}) && exists($args{deadline}) && exists($args{close_handles});
    my $pair = FSM::Support::ProcessSupervisor::GatedPair::prepare_record(%args);
    my $snapshot = $pair->{snapshot};
    my $started = $snapshot->{started_ns} / 1_000_000_000;
    my $now = _now();
    if ($started > $now || $args{deadline} > $started + $snapshot->{timeout_seconds}) {
        _error('deadline must preserve the original invocation wall');
    }
    my $self = bless {
        owner_pid => $$, pair => $pair, received => {},
        state => {
            map({ $_ => $snapshot->{$_} } qw(schema stage containment)),
            bounds => {map { $_ => $snapshot->{$_} } qw(timeout_seconds capture_limit_bytes)},
            phase => 'unallocated', deadline => 0 + $args{deadline}, started => $started,
            stdout => '', stderr => '', exec_error => '',
            exec_handoff => undef, first_output => undef,
            leader_reaped => 0, leader_status => undef,
            timed_out => 0, output_limited => 0, latch_failures => 1,
            cleanup => FSM::Support::ProcessSupervisor::_new_cleanup(0, $snapshot->{containment}),
            select => IO::Select->new, streams => {},
        },
    }, __PACKAGE__;
    $self->{identity} = refaddr($self);
    $self->{pair_identity} = refaddr($pair);
    $self->{original_cleanup} = $self->{state}{cleanup};
    $self->{original_stage} = $snapshot->{stage};
    $self->{original_containment} = $snapshot->{containment};
    $self->_sync_identity;
    return $self;
}

sub allocate {
    my ($self, $check) = @_; _owner($self);
    _error('allocation requires a retained unallocated job')
        unless (@_ == 1 || (@_ == 2 && ref($check) eq 'CODE'))
            && $self->{state}{phase} eq 'unallocated';
    my $ok = eval {
        FSM::Support::ProcessSupervisor::Reservation::_masked_preparation(sub {
            $self->{state}{phase} = 'allocating';
            my $allocated = eval { $self->{pair}->allocate(defined($check) ? ($check) : ()); 1 };
            unless ($allocated) {
                my $error = $@;
                $self->_latch('host_error', FSM::Support::ProcessSupervisor::_sanitize_control($error));
                $self->{state}{phase} = 'preparation_failed';
                die $error;
            }
            $self->{state}{phase} = 'prepared';
        });
        1;
    };
    unless ($ok) {
        my $error = $@;
        $self->_latch('host_error', FSM::Support::ProcessSupervisor::_sanitize_control($error));
        $self->{state}{phase} = 'preparation_failed';
        die $error;
    }
    return;
}

sub prepare {
    my $self = prepare_record(@_);
    my $ok = eval { $self->allocate; 1 };
    unless ($ok) {
        my $error = $@;
        $self->{pair}->retire(_minimum($self->{state}{deadline}, _now()));
        die $error;
    }
    return $self;
}

sub _sync_identity {
    my ($self) = @_;
    my $s = $self->{state};
    my $c = $self->{pair}->observation;
    my $r = $self->{pair}->reservation->observation;
    @{$s}{qw(pid birth_sec birth_usec leader_reaped leader_status)} =
        @{$c}{qw(command_pid birth_sec birth_usec command_reaped command_status)};
    $s->{cleanup}{leader_started} = $c->{command_pid} ? 1 : 0;
    $s->{group_identity} = {
        pid => $r->{pid}, start_sec => $r->{birth_sec}, start_usec => $r->{birth_usec},
    };
    $s->{reservation_observation} = $r;
    return ($c, $r);
}

sub start {
    my ($self, $check) = @_; _owner($self);
    _error('start requires a retained prepared job')
        unless (@_ == 1 || (@_ == 2 && ref($check) eq 'CODE'))
            && $self->{state}{phase} eq 'prepared';
    $self->{state}{phase} = 'launch';
    my $ok = eval { $self->{pair}->start(defined($check) ? ($check) : ()); 1 };
    unless ($ok) {
        my $error = $@;
        $self->_latch('host_error', FSM::Support::ProcessSupervisor::_sanitize_control($error));
        die $error;
    }
    $self->_sync_identity;
}

sub release {
    my ($self, $check) = @_; _owner($self);
    _error('release requires the ready published job')
        unless (@_ == 1 || (@_ == 2 && ref($check) eq 'CODE'))
            && $self->{state}{phase} eq 'ready';
    my $pair = $self->{pair};
    my $started = 0;
    my $ok = eval {
        # This queues E on an already-ready pair; it cannot launch or fork.
        # Publish the wrapper phase before Pair publication can be interrupted.
        FSM::Support::ProcessSupervisor::Reservation::_masked_preparation(sub {
            _owner($self);
            _error('release requires the ready published job')
                unless $self->{state}{phase} eq 'ready';
            $started = 1;
            $self->{state}{phase} = 'releasing';
            my $queued = eval {
                $pair->release(sub {
                    my ($original_pair) = @_;
                    $self->_release_live($original_pair);
                    my $allow = $check ? $check->($original_pair) : 1;
                    $self->_release_live($original_pair);
                    return $allow;
                });
                1;
            };
            unless ($queued) {
                my $error = $@;
                eval { $self->_release_failed($pair, $error); 1 };
                die $error;
            }
        });
        1;
    };
    unless ($ok) {
        my $error = $@;
        eval { $self->_release_failed($pair, $error); 1 } if $started;
        die $error;
    }
    return;
}

sub _release_live {
    my ($self, $pair) = @_; _owner($self);
    _error('execution admission lost original releasing job')
        unless ref($pair) eq 'FSM::Support::ProcessSupervisor::GatedPair'
            && refaddr($pair) == $self->{pair_identity}
            && $self->{state}{phase} eq 'releasing' && !$self->{state}{first_failure};
    _error('execution admission exceeded original job wall')
        unless $self->{state}{deadline} == $pair->{original_deadline}
            && _now() < $self->{state}{deadline};
    return;
}

sub _release_failed {
    my ($self, $pair, $error) = @_;
    # This also runs after a fatal mask failure: refusal must not require a
    # second successful mask. The latched failure itself blocks the E guard
    # before native cancellation; ordinary queue errors already hold the mask.
    $self->_latch('host_error', FSM::Support::ProcessSupervisor::_sanitize_control($error));
    # Use the original retained pair even if a handler changed wrapper state.
    # Cancellation revokes pending E but preserves confirmed release.
    eval { $pair->cancel; 1 };
    return;
}

sub _custody_state {
    my ($self) = @_; _owner($self);
    return 0 if $self->{state}{first_failure}
        || $self->{state}{phase} =~ /\A(?:cleanup|finished)\z/;
    _error('custody inspection requires the original live published job')
        unless $self->{state}{phase} =~ /\A(?:ready|releasing|capture)\z/;
    _error('custody inspection changed original invocation wall')
        unless $self->{state}{deadline} == $self->{pair}{original_deadline};
    my $native = $self->{pair}->observation;
    return 0 if $native->{failure} || $native->{retired} || $native->{release_uncertain};
    _error('custody inspection lost original published Pair state')
        unless $native->{phase} =~ /\A(?:ready|release_pending|released)\z/;
    return _now() < $self->{state}{deadline} ? 1 : 0;
}

sub check_custody {
    my ($self) = @_; _owner($self);
    _error('unexpected custody inspection arguments') unless @_ == 1;
    return 0 unless $self->_custody_state;
    my $pair = $self->{pair};
    my ($started, $live) = (0, 0);
    my $ok = eval {
        # Poll publication is atomic with respect to creator signals. This
        # ready-or-executing inspection never advances launch, capture or E.
        FSM::Support::ProcessSupervisor::Reservation::_masked_preparation(sub {
            return unless $self->_custody_state;
            $started = 1;
            my $checked = eval {
                $live = $pair->_check_custody('custody inspection', 1);
                $live = 0 unless $self->_custody_state;
                $self->_sync_identity;
                1;
            };
            unless ($checked) {
                my $error = $@;
                # The same pure failure latch also revokes any queued E;
                # it preserves a native effect that was already confirmed.
                eval { $self->_release_failed($pair, $error); 1 };
                die $error;
            }
        });
        $live = 0 unless $self->_custody_state;
        1;
    };
    unless ($ok) {
        my $error = $@;
        eval { $self->_release_failed($pair, $error); 1 } if $started;
        die $error;
    }
    return $live ? 1 : 0;
}

sub _latch {
    my ($self, $status, $diagnostic) = @_;
    FSM::Support::ProcessSupervisor::_latch_supervision_failure(
        $self->{state}, $status, $diagnostic);
}

sub _attach_capture {
    my ($self) = @_;
    my $s = $self->{state};
    # Keep the recipient reachable before transfer. If mask restoration throws,
    # cancellation still sees every transferred handle through this record.
    $self->{pair}->transfer_streams($self->{received});
    for my $name (qw(stdout stderr control)) {
        my $fh = $self->{received}{$name};
        $s->{streams}{fileno($fh)} = [$name, $fh];
        $s->{select}->add($fh);
    }
    $s->{control_fileno} = fileno($self->{received}{control});
    $s->{phase} = 'ready';
}

sub _close_capture {
    my ($self) = @_;
    # streams borrows these handles; the shared reader may already have closed
    # some at EOF. Closing the retained recipient handles also covers an
    # interrupted transfer return or partially constructed selector.
    FSM::Support::ProcessSupervisor::_close_handles(values %{$self->{received}});
    $self->{received} = {};
    $self->{state}{streams} = {};
    $self->{state}{select} = IO::Select->new;
}

sub _begin_cleanup {
    my ($self, $cancel, $deadline) = @_;
    my $s = $self->{state};
    return if $s->{phase} eq 'finished';
    if ($s->{phase} eq 'cleanup') {
        $self->{closure}->shorten_deadline($deadline) if defined $deadline;
        return;
    }
    $deadline //= _minimum($s->{deadline}, _now()) + $TERM_GRACE + $KILL_GRACE;
    $self->{closure} = FSM::Support::ProcessSupervisor::GroupClosure::prepare(
        pair => $self->{pair}, cancel => $cancel, deadline => $deadline);
    $self->_close_capture;
    $s->{phase} = 'cleanup';
}

sub cancel {
    my ($self, $diagnostic, $deadline) = @_; _owner($self);
    _error('cancel requires a diagnostic and shared closure deadline')
        unless @_ == 3 && defined($diagnostic) && !ref($diagnostic)
            && length($diagnostic) && defined($deadline);
    return if $self->{state}{phase} eq 'finished';
    $self->_latch('host_error', FSM::Support::ProcessSupervisor::_sanitize_control($diagnostic));
    $self->_begin_cleanup(1, $deadline);
}

sub _capture {
    my ($self) = @_;
    my $s = $self->{state};
    FSM::Support::ProcessSupervisor::_read_supervision_streams($s);
    $self->{pair}->poll_command;
    my ($c, $r) = $self->_sync_identity;
    if (defined($c->{failure})) { $self->_latch('host_error', $c->{failure}); }
    if (defined($s->{host_error}) || $s->{output_limited} || length($s->{exec_error})
            || defined($c->{failure})) {
        $self->_begin_cleanup(1);
        return;
    }
    return unless $c->{command_reaped};
    my $raw = $c->{command_status};
    if ($raw & 127) { $self->_latch('signaled', 'supervised process exited after a signal'); }
    elsif ($raw >> 8) { $self->_latch('nonzero_exit', 'supervised process exited nonzero'); }
    my $absent = $self->{pair}->reservation->group_absent;
    if (!defined($absent)) {
        $self->_latch('host_error', 'reserved command group absence is uncertain');
        $self->_begin_cleanup(1);
    }
    elsif (!$absent) {
        $s->{surviving_descendants} = $s->{cleanup}{surviving_descendants} = 1;
        $self->_latch('surviving_descendants', 'supervised process left descendants after leader exit');
        $self->_begin_cleanup(0);
    }
    elsif (!$s->{select}->count) { $self->_begin_cleanup(0); }
}

sub _finish {
    my ($self) = @_;
    my $s = $self->{state};
    my (undef, $r) = $self->_sync_identity;
    my $closed = $self->{closure}->observation;
    @{$s->{cleanup}}{qw(leader_reaped group_gone term_sent kill_sent)} =
        @{$closed}{qw(leader_reaped group_gone term_sent kill_sent)};
    $s->{surviving_descendants} ||= $closed->{surviving_descendants};
    $s->{cleanup}{surviving_descendants} = $s->{surviving_descendants} ? 1 : 0;
    $s->{reservation_reaped} = $closed->{reservation_reaped};
    $s->{resources_closed} = $closed->{complete};
    $s->{closure_observation} = $closed;
    $self->_latch('cleanup_failed', $closed->{failure}) unless $closed->{complete};
    $self->_latch('host_error', $r->{failure}) if defined($r->{failure});
    FSM::Support::ProcessSupervisor::_publish_supervision_result($s);
    $self->{original_receipt} = $s->{receipt_observation};
}

sub advance {
    my ($self) = @_; _owner($self);
    _error('unexpected advance arguments') unless @_ == 1;
    my $s = $self->{state};
    return if $s->{phase} eq 'unallocated' || $s->{phase} eq 'prepared' || $s->{phase} eq 'finished';
    if ($s->{phase} eq 'cleanup') {
        $self->{closure}->advance;
        $self->_finish if $self->{closure}->observation->{phase} eq 'finished';
        return;
    }
    if (_now() >= $s->{deadline}) {
        $s->{timed_out} = 1;
        $self->_latch('timed_out', 'supervised process exceeded its fixed deadline');
        $self->_begin_cleanup(1);
        return;
    }
    my $advanced = eval { $self->{pair}->advance; 1 };
    unless ($advanced) {
        my $error = $@;
        $self->_latch('host_error', FSM::Support::ProcessSupervisor::_sanitize_control($error));
        die $error;
    }
    my ($c) = $self->_sync_identity;
    if (defined($c->{failure})) {
        $self->_latch('host_error', $c->{failure});
        $self->_begin_cleanup(1);
        return;
    }
    if ($s->{phase} eq 'launch' && $c->{phase} eq 'ready') { $self->_attach_capture; }
    if ($s->{phase} eq 'releasing' && $c->{released}) { $s->{phase} = 'capture'; }
    $self->_capture if $s->{phase} eq 'capture';
}

sub observation {
    my ($self) = @_; _owner($self);
    _error('unexpected observation arguments') unless @_ == 1;
    my ($c, $r) = $self->_sync_identity;
    return {phase => $self->{state}{phase}, command => $c, reservation => $r,
        cleanup_deadline => $self->{closure} ? $self->{closure}->observation->{deadline} : undef,
        first_failure => $self->{state}{first_failure}
            ? {%{$self->{state}{first_failure}}} : undef};
}

# Return only this job's owned live handles. Pair close_handles and the shared
# reader's streams are borrowed aliases; transferred capture belongs here.
sub handles {
    my ($self) = @_; _owner($self);
    _error('unexpected handles arguments') unless @_ == 1;
    return [grep { defined(fileno($_)) } @{$self->{pair}->handles},
        @{$self->{pair}->reservation->handles}, values %{$self->{received}}];
}

sub finished_job {
    my ($self) = @_; _owner($self);
    _error('result requires a finished job')
        unless @_ == 1 && $self->{state}{phase} eq 'finished';
    return $self->{state};
}

# Read-only receipt basis held by this creator, independent of replaceable
# fields in the returned plain job or its copied public result. This does not
# authenticate kernel birth or establish logical subtree/delivery closure.
sub receipt_basis {
    my ($self) = @_; _owner($self);
    _error('receipt basis requires a finished job')
        unless @_ == 1 && $self->{state}{phase} eq 'finished';
    return {
        receipt => $self->{original_receipt}, cleanup => $self->{original_cleanup},
        stage => $self->{original_stage}, containment => $self->{original_containment},
        command => $self->{pair}->observation,
        reservation => $self->{pair}->reservation->observation,
        closure => $self->{closure}->observation,
        capture_closed => !keys(%{$self->{received}})
            && !keys(%{$self->{state}{streams}}) && !$self->{state}{select}->count ? 1 : 0,
    };
}

1;
