package FSM::Support::HDLExternalValidation;

=head1 NAME

FSM::Support::HDLExternalValidation - Optional external SystemVerilog lint and synthesis validation

=head1 DESCRIPTION

Owns the bounded external-tool validation lane for generated SystemVerilog.
FSMGen still performs semantic and pre-generation checks internally; this
support package runs Verilator and Yosys after emission. Verilator checks that
the rendered text is valid lint-clean SystemVerilog. Yosys checks that the
same text can be turned into a structural netlist-like design, deliberately
without running the ABC mapping/optimization algorithm unless the caller
explicitly opts into the bounded ABC mapping probe.

=cut

use v5.20;
use strict;
use warnings;
use feature qw(signatures);
no warnings 'experimental::signatures';

use Config qw(%Config);
use Cwd qw(abs_path);
use Exporter qw(import);
use File::Basename qw(basename);
use File::Spec;
use IPC::Cmd qw(can_run);
use bytes ();

use FSM::ProjectDataLocality qw(repository_root);
use FSM::Support::ProcessSupervisor qw(supervise_process);

our @EXPORT_OK = qw(
    hdl_external_validation_abc_tool_candidates
    hdl_external_validation_failure_stream_excerpt_strategy
    hdl_external_validation_failure_stream_retained_bytes
    hdl_external_validation_process_containment
    hdl_external_validation_required_tools
    hdl_external_validation_step_capture_limit_bytes
    hdl_external_validation_step_timeout_seconds
    hdl_external_validation_tools
    hdl_external_validation_yosys_log_mode
    missing_systemverilog_validation_tools
    validate_systemverilog_file
);

my $PROCESS_SCHEMA = 'fsmgen.hdl_external_validation_process_result.v1';
my $PROCESS_CONTAINMENT = 'hdl_external_validation_process_group';
my $STEP_TIMEOUT_SECONDS = 120;
my $STEP_CAPTURE_LIMIT_BYTES = 8_388_608;
my $FAILURE_STREAM_RETAINED_BYTES = 65_536;
my $FAILURE_STREAM_EXCERPT_STRATEGY = 'head_tail_with_omitted_byte_count';
my $YOSYS_LOG_MODE = 'quiet';
my $REPOSITORY_ROOT = repository_root();
my $RUNNING_PERL = _canonical_running_perl();

sub hdl_external_validation_required_tools () {
    return qw(verilator yosys);
}

sub hdl_external_validation_abc_tool_candidates () {
    return qw(yosys-abc berkeley-abc abc);
}

sub hdl_external_validation_failure_stream_excerpt_strategy () {
    return $FAILURE_STREAM_EXCERPT_STRATEGY;
}

sub hdl_external_validation_failure_stream_retained_bytes () {
    return $FAILURE_STREAM_RETAINED_BYTES;
}

sub hdl_external_validation_process_containment () {
    return $PROCESS_CONTAINMENT;
}

sub hdl_external_validation_step_capture_limit_bytes () {
    return $STEP_CAPTURE_LIMIT_BYTES;
}

sub hdl_external_validation_step_timeout_seconds () {
    return $STEP_TIMEOUT_SECONDS;
}

sub hdl_external_validation_yosys_log_mode () {
    return $YOSYS_LOG_MODE;
}

sub hdl_external_validation_tools () {
    my ($abc_tool, $abc_path) = _first_available_tool(hdl_external_validation_abc_tool_candidates());
    return {
        verilator => can_run('verilator'),
        yosys => can_run('yosys'),
        abc_mapping => $abc_path,
        abc_mapping_tool => $abc_tool,
    };
}

sub missing_systemverilog_validation_tools () {
    my $tools = hdl_external_validation_tools();
    return sort grep { !$tools->{$_} } hdl_external_validation_required_tools();
}

sub validate_systemverilog_file (%args) {
    my $source_file = $args{source_file}
        or die "[HDLExternalValidation.pm][validate_systemverilog_file()] Missing required 'source_file'";
    my $top_module = $args{top_module}
        or die "[HDLExternalValidation.pm][validate_systemverilog_file()] Missing required 'top_module'";
    my $abc_mapping = $args{abc_mapping} ? 1 : 0;

    die "[HDLExternalValidation.pm][validate_systemverilog_file()] Source file does not exist: $source_file"
        unless -f $source_file;
    my $source_path = File::Spec->rel2abs($source_file);

    my $tools = hdl_external_validation_tools();
    my @missing = sort grep { !$tools->{$_} } qw(verilator yosys);
    push @missing, 'abc_mapping'
        if $abc_mapping && !$tools->{abc_mapping};
    die "[HDLExternalValidation.pm][validate_systemverilog_file()] Missing external HDL validation tool(s): "
        . join(', ', @missing)
        if @missing;

    my @steps;
    push @steps, _run_step(
        name => 'verilator_lint',
        command => _tool_command(
            $tools->{verilator},
            '--lint-only',
            '--sv',
            $source_path,
        ),
    );

    my $yosys_stage = $abc_mapping
        ? 'synth -top ' . _yosys_identifier($top_module)
        : 'synth -noabc -top ' . _yosys_identifier($top_module);
    my $yosys_script = join '; ',
        'read_verilog -sv -noautowire ' . _yosys_quote($source_path),
        $yosys_stage,
        'stat';
    push @steps, _run_step(
        name => $abc_mapping ? 'yosys_abc_synthesis' : 'yosys_synthesis',
        command => _tool_command(
            $tools->{yosys},
            '-q',
            '-p',
            $yosys_script,
        ),
    );

    return {
        ok => 1,
        source_file => $source_file,
        top_module => $top_module,
        steps => \@steps,
    };
}

sub _run_step (%args) {
    my $name = $args{name};
    my $command = $args{command};

    my $result = supervise_process(
        schema => $PROCESS_SCHEMA,
        stage => $name,
        bounds => {
            timeout_seconds => $STEP_TIMEOUT_SECONDS,
            capture_limit_bytes => $STEP_CAPTURE_LIMIT_BYTES,
        },
        containment => $PROCESS_CONTAINMENT,
        cwd => $REPOSITORY_ROOT,
        argv => $command,
    );

    unless ($result->{ok}) {
        die _format_step_failure(
            name => $name,
            command => $command,
            error_message => _process_failure_reason($result),
            stdout => $result->{stdout},
            stderr => $result->{stderr},
        );
    }

    return {
        name => $name,
        command => [@$command],
        stdout => $result->{stdout},
        stderr => $result->{stderr},
    };
}

sub _process_failure_reason ($result) {
    my $status = defined($result->{status}) && length($result->{status})
        ? $result->{status} : 'host_error';
    my $text = "status=$status";
    $text .= ": $result->{diagnostic}"
        if defined($result->{diagnostic}) && length($result->{diagnostic});
    return $text;
}

sub _canonical_running_perl () {
    my $candidate = File::Spec->file_name_is_absolute($^X)
        ? $^X : $Config{perlpath};
    my $resolved = defined($candidate) ? abs_path($candidate) : undef;
    die "[HDLExternalValidation.pm] Cannot resolve the running Perl interpreter"
        unless defined($resolved) && -f $resolved && -x $resolved;
    return $resolved;
}

sub _tool_command ($tool, @arguments) {
    return [$tool, @arguments] unless _has_plain_perl_shebang($tool);
    return [$RUNNING_PERL, $tool, @arguments];
}

sub _has_plain_perl_shebang ($path) {
    return 0 unless defined($path) && !ref($path) && -f $path;
    open my $fh, '<:raw', $path or return 0;
    my $prefix = '';
    my $read = read($fh, $prefix, 256);
    close $fh;
    return 0 unless defined($read) && $read;
    my ($line) = $prefix =~ /\A([^\r\n]*)/;
    return 1 if $line eq '#!/usr/bin/env perl';
    return 0 unless $line =~ /\A#!(\S+)\z/;
    return basename($1) eq 'perl' ? 1 : 0;
}

sub _format_step_failure (%args) {
    my $text = "External HDL validation step '$args{name}' failed\n";
    $text .= "Command: " . join(' ', map { _shellish($_) } @{$args{command} || []}) . "\n";
    $text .= "Reason: $args{error_message}\n"
        if defined($args{error_message}) && length($args{error_message});
    $text .= "stdout:\n" . _failure_stream_excerpt($args{stdout}) . "\n"
        if defined($args{stdout}) && length($args{stdout});
    $text .= "stderr:\n" . _failure_stream_excerpt($args{stderr}) . "\n"
        if defined($args{stderr}) && length($args{stderr});
    return $text;
}

sub _failure_stream_excerpt ($text) {
    return '' unless defined($text) && length($text);
    my $length = bytes::length($text);
    return $text if $length <= $FAILURE_STREAM_RETAINED_BYTES;

    my $half = int($FAILURE_STREAM_RETAINED_BYTES / 2);
    my $omitted = $length - $FAILURE_STREAM_RETAINED_BYTES;
    return bytes::substr($text, 0, $half)
        . "\n... [$omitted captured bytes omitted; retained first $half and last $half bytes] ...\n"
        . bytes::substr($text, -$half);
}

sub _yosys_quote ($text) {
    $text =~ s/\\/\\\\/g;
    $text =~ s/"/\\"/g;
    return qq("$text");
}

sub _yosys_identifier ($text) {
    die "[HDLExternalValidation.pm][_yosys_identifier()] Unsupported top-module identifier '$text'"
        unless defined($text) && $text =~ /^[A-Za-z_]\w*\z/;
    return $text;
}

sub _first_available_tool (@tool_names) {
    for my $tool_name (@tool_names) {
        my $path = can_run($tool_name);
        return ($tool_name, $path) if $path;
    }
    return (undef, undef);
}

sub _shellish ($text) {
    return "''" unless defined($text) && length($text);
    return $text if $text =~ /^[A-Za-z0-9_\/.:\-+=,\@]+\z/;
    $text =~ s/'/'"'"'/g;
    return "'$text'";
}

1;

__END__

=head1 FUNCTIONS

=head2 hdl_external_validation_tools

Returns the discovered required C<verilator> and C<yosys> executable paths, or
false values for tools that are not available on C<PATH>. It also reports the
first optional ABC mapping executable discovered from
C<hdl_external_validation_abc_tool_candidates> under C<abc_mapping>, plus the
matching command spelling under C<abc_mapping_tool>. The ABC mapping tool is
reported for planning/contract visibility only; it is not required and is not
run by default C<validate_systemverilog_file> calls.

=head2 hdl_external_validation_required_tools

Returns the tool keys that are required for the shipped external SystemVerilog
validation lane. This remains C<verilator> and C<yosys>.

=head2 hdl_external_validation_abc_tool_candidates

Returns the optional ABC mapping executable command names probed by
C<hdl_external_validation_tools>, in priority order.

=head2 hdl_external_validation_failure_stream_excerpt_strategy

Returns the stable strategy label for rendering bounded failed-step streams.

=head2 hdl_external_validation_failure_stream_retained_bytes

Returns the maximum number of captured tool-output bytes retained in each
failed stream's rendered head/tail excerpt. The omission marker is bounded
diagnostic metadata and is additional to the retained tool-output bytes.

=head2 hdl_external_validation_step_timeout_seconds

Returns the fixed per-step wall-clock limit used for Verilator and Yosys.

=head2 hdl_external_validation_step_capture_limit_bytes

Returns the fixed aggregate stdout/stderr capture ceiling for each step.

=head2 hdl_external_validation_process_containment

Returns the stable process-group containment policy label.

=head2 hdl_external_validation_yosys_log_mode

Returns the stable label for native quiet Yosys validation logging.

=head2 missing_systemverilog_validation_tools

Returns the sorted list of required SystemVerilog validation tools that are
not currently available.

=head2 validate_systemverilog_file(%args)

Runs Verilator lint and ABC-free Yosys structural synthesis over one generated
SystemVerilog file. Required arguments are C<source_file> and C<top_module>.
The Yosys pass uses native C<-q> logging, C<read_verilog -sv -noautowire>,
C<synth -noabc -top>, and C<stat>. The C<-noabc> guard is intentional: this
lane proves FSMGen did not emit garbage HDL and that Yosys can lower it into
structural logic, while leaving ABC timeout/optimization edge cases for a
later dedicated hardening lane.

Passing C<abc_mapping =E<gt> 1> enables the explicit opt-in ABC mapping probe.
That mode requires the optional C<abc_mapping> tool discovery to succeed and
uses C<synth -top> instead of C<synth -noabc -top>. The default CLI validation
path remains ABC-free.

Every external step is launched without a shell from the repository-derived
working directory, with one fixed wall-clock limit, one aggregate capture
ceiling, and owned process-group cleanup. A failed step is never retried.
Failed stdout and stderr are presented independently as byte-exact bounded
head/tail excerpts with an exact omitted-byte count.

=cut
