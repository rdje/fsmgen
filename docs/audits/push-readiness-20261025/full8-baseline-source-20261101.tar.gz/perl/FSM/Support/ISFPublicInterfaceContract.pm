package FSM::Support::ISFPublicInterfaceContract;

use strict;
use warnings;

use Exporter 'import';
use JSON::PP ();
use FSM::Support::ISFResetProvenance qw(reset_provenance_contract);
use FSM::Support::ISFInterfacePortMetadata qw(interface_port_metadata_contract);
use FSM::Support::ISFReductions qw(reduction_metadata_contract);
use FSM::Support::ISFResourceCatalog qw(
    isf_backlog_resource_kind_values
    isf_enforced_resource_kind_values
    isf_resource_arbiter_values
    isf_resource_kind_meaning_map
    isf_resource_kind_status_map
    isf_resource_kind_values
);

our @EXPORT_OK = qw(
    build_isf_public_interface_contract
    isf_public_interface_actor_shell_drive_shape
    isf_public_interface_actor_shell_actor_name_shape
    isf_public_interface_actor_shell_interface_shape
    isf_public_interface_actor_shell_required_keys
    isf_public_interface_actor_shell_rule_shape
    isf_public_interface_actor_shell_timing_shape
    isf_public_interface_actor_shell_transaction_shape
    isf_public_interface_actor_shell_value_shape
    isf_public_interface_cli_hdl_generation_success_shape
    isf_public_interface_cli_option_names
    isf_public_interface_cli_outdir_success_shape
    isf_public_interface_cli_schedule_json_success_shape
    isf_public_interface_cli_strict_hdl_generation_success_shape
    isf_public_interface_contract_source
    isf_public_interface_constructor_option_names
    isf_public_interface_dt_assignment_operator_family_map
    isf_public_interface_facade_failure_diagnostic_shape
    isf_public_interface_backlog_resource_kind_values
    isf_public_interface_enforced_resource_kind_values
    isf_public_interface_library_catalog_entry_keys
    isf_public_interface_library_catalog_paths
    isf_public_interface_live_document_paths
    isf_public_interface_lower_return_shape
    isf_public_interface_lower_result_file_name_shape
    isf_public_interface_lower_result_file_text_shape
    isf_public_interface_lower_result_presence_keys
    isf_public_interface_dt_ordering_policy
    isf_public_interface_parse_file_return_shape
    isf_public_interface_parse_source_return_shape
    isf_public_interface_parser_method_names
    isf_public_interface_public_top_level_keys
    isf_public_interface_resource_arbiter_values
    isf_public_interface_resource_kind_meaning_map
    isf_public_interface_resource_kind_status_map
    isf_public_interface_resource_kind_values
    isf_public_interface_schedule_report_compile_issues_success_shape
    isf_public_interface_schedule_report_clock_shape
    isf_public_interface_schedule_report_clock_domain_child_instance_keys
    isf_public_interface_schedule_report_clock_domain_crossing_endpoint_keys
    isf_public_interface_schedule_report_clock_domain_keys
    isf_public_interface_schedule_report_compile_issue_keys
    isf_public_interface_schedule_report_compile_issue_proof_status_values
    isf_public_interface_schedule_report_compile_issue_severity_values
    isf_public_interface_schedule_report_compile_issue_source_keys
    isf_public_interface_schedule_report_crossing_keys
    isf_public_interface_schedule_report_bank_access_keys
    isf_public_interface_schedule_report_bank_access_kind_values
    isf_public_interface_schedule_report_bank_access_policy_values
    isf_public_interface_schedule_report_dt_assignments_shape
    isf_public_interface_schedule_report_dt_kind_values
    isf_public_interface_schedule_report_fanin_group_kind_values
    isf_public_interface_schedule_report_fanin_group_optional_keys
    isf_public_interface_schedule_report_fanin_group_required_keys
    isf_public_interface_schedule_report_priority_resolution_keys
    isf_public_interface_schedule_report_resource_arbitration_keys
    isf_public_interface_schedule_report_generated_composition_binding_keys
    isf_public_interface_schedule_report_generated_composition_child_keys
    isf_public_interface_schedule_report_generated_composition_child_parameter_keys
    isf_public_interface_schedule_report_generated_composition_drive_handoff_keys
    isf_public_interface_schedule_report_generated_composition_instance_keys
    isf_public_interface_schedule_report_generated_composition_kind_values
    isf_public_interface_schedule_report_generated_composition_link_keys
    isf_public_interface_schedule_report_generated_composition_parent_keys
    isf_public_interface_schedule_report_generated_composition_payload_keys
    isf_public_interface_schedule_report_generated_composition_required_keys
    isf_public_interface_schedule_report_library_use_binding_keys
    isf_public_interface_schedule_report_library_use_keys
    isf_public_interface_schedule_report_library_use_parameter_keys
    isf_public_interface_schedule_report_multi_file_scope
    isf_public_interface_schedule_report_interface_count_shape
    isf_public_interface_schedule_report_presence_key_family_map
    isf_public_interface_schedule_report_reset_kind_values
    isf_public_interface_schedule_report_reset_keys
    isf_public_interface_schedule_report_reset_polarity_values
    isf_public_interface_schedule_report_reset_shape
    isf_public_interface_schedule_report_scheduled_fsm_shape
    isf_public_interface_schedule_report_source_shape
    isf_public_interface_schedule_report_state_count_shape
    isf_public_interface_schedule_report_actor_phase_keys
    isf_public_interface_schedule_report_actor_stage_keys
    isf_public_interface_schedule_report_actor_network_association_schedule_keys
    isf_public_interface_schedule_report_actor_network_data_movement_keys
    isf_public_interface_schedule_report_actor_network_event_wait_keys
    isf_public_interface_schedule_report_actor_network_generated_top_child_keys
    isf_public_interface_schedule_report_actor_network_generated_top_keys
    isf_public_interface_schedule_report_actor_network_generated_top_multi_child_keys
    isf_public_interface_schedule_report_actor_network_group_schedule_keys
    isf_public_interface_schedule_report_actor_network_group_keys
    isf_public_interface_schedule_report_actor_network_instance_keys
    isf_public_interface_schedule_report_actor_network_keys
    isf_public_interface_schedule_report_actor_network_resolved_instance_keys
    isf_public_interface_schedule_report_actor_network_transaction_trigger_keys
    isf_public_interface_schedule_report_actor_param_keys
    isf_public_interface_schedule_report_actor_constant_keys
    isf_public_interface_schedule_report_storage_kind_values
    isf_public_interface_schedule_report_storage_optional_keys
    isf_public_interface_schedule_report_storage_required_keys
    isf_public_interface_schedule_report_storage_role_values
    isf_public_interface_schedule_report_storage_width_shape
    isf_public_interface_schedule_report_temporal_contract_assertion_projection_values
    isf_public_interface_schedule_report_temporal_contract_keys
    isf_public_interface_schedule_report_temporal_contract_kind_values
    isf_public_interface_schedule_report_temporal_contract_overlap_policy_values
    isf_public_interface_schedule_report_temporal_contract_reset_policy_shape
    isf_public_interface_schedule_report_top_level_keys
    isf_public_interface_schedule_report_transaction_loop_keys
    isf_public_interface_schedule_report_transaction_wait_count_kind_values
    isf_public_interface_schedule_report_transaction_wait_keys
    isf_public_interface_schedule_report_transaction_port_binding_keys
    isf_public_interface_schedule_report_transaction_port_binding_actor_endpoint_kind_values
    isf_public_interface_schedule_report_transaction_port_binding_timing_values
    isf_public_interface_schedule_report_transaction_port_binding_authored_timing_mode_values
    isf_public_interface_schedule_report_transaction_port_binding_site_kind_values
    isf_public_interface_schedule_report_transaction_stage_keys
    isf_public_interface_schedule_report_transaction_stage_kind_values
    isf_public_interface_schedule_report_transaction_count_shape
    isf_public_interface_schedule_report_transaction_ordering
    isf_public_interface_schedule_report_transaction_states_shape
    isf_public_interface_schedule_report_transaction_keys
    isf_public_interface_schedule_report_verification_observation_keys
    isf_public_interface_schedule_report_verification_observation_signal_keys
    isf_public_interface_schedule_report_verification_observation_role_values
    isf_public_interface_schedule_report_verification_bridge_keys
    isf_public_interface_schedule_report_verification_bridge_protocol_keys
    isf_public_interface_schedule_report_verification_bridge_fact_keys
    isf_public_interface_schedule_report_verification_bridge_transaction_keys
    isf_public_interface_schedule_report_verification_bridge_field_keys
    isf_public_interface_schedule_report_verification_bridge_source_keys
    isf_public_interface_schedule_report_verification_bridge_event_keys
    isf_public_interface_schedule_report_verification_bridge_probe_keys
    isf_public_interface_schedule_report_watchdog_shape
    isf_public_interface_shipped_library_definitions
    isf_public_interface_report_return_shape
    isf_public_interface_schedule_report_dt_keys
    isf_public_interface_scheduler_method_names
);

sub isf_public_interface_contract_source {
    return 'FSM::Support::ISFPublicInterfaceContract';
}

sub build_isf_public_interface_contract {
    return {
        schema_version => 1,
        status => 'bounded_public',
        contract_source => isf_public_interface_contract_source(),
        implementation_owners => [
            'FSM::Adapter::ISF',
            'FSM::Scheduler::ISF',
            'FSM::Scheduler::ISF::Emitter::FSM',
            'FSM::Scheduler::ISF::Emitter::JSON',
        ],
        entrypoints => {
            manifest => './bin/fsmgen --capability-manifest -> embedding.isf_public_interface',
            cli => [
                './bin/fsmgen path/to/file.isf',
                './bin/fsmgen --emit-schedule-json path/to/file.isf',
                './bin/fsmgen --outdir path/to/outdir path/to/file.isf',
            ],
            in_process => [
                'FSM::Adapter::ISF->new(%args)',
                'FSM::Adapter::ISF->new(%args)->parse_file($path)',
                'FSM::Adapter::ISF->new(%args)->parse_source($source_text, $source_label)',
                'FSM::Scheduler::ISF->new(%args)',
                'FSM::Scheduler::ISF->new(%args)->lower($actor)',
                'FSM::Scheduler::ISF->new(%args)->report($actor)',
            ],
        },
        public_top_level_presence_keys => isf_public_interface_public_top_level_keys(),
        parser_method_names => isf_public_interface_parser_method_names(),
        scheduler_method_names => isf_public_interface_scheduler_method_names(),
        constructor_option_names => isf_public_interface_constructor_option_names(),
        cli_option_names => isf_public_interface_cli_option_names(),
        resource_arbiter_values => isf_public_interface_resource_arbiter_values(),
        resource_kind_values => isf_public_interface_resource_kind_values(),
        resource_kind_status_map => isf_public_interface_resource_kind_status_map(),
        resource_kind_meaning_map => isf_public_interface_resource_kind_meaning_map(),
        enforced_resource_kind_values => isf_public_interface_enforced_resource_kind_values(),
        backlog_resource_kind_values => isf_public_interface_backlog_resource_kind_values(),
        library_catalog_paths => isf_public_interface_library_catalog_paths(),
        library_catalog_entry_keys => isf_public_interface_library_catalog_entry_keys(),
        shipped_library_definitions => isf_public_interface_shipped_library_definitions(),
        cli_schedule_json_success_shape => isf_public_interface_cli_schedule_json_success_shape(),
        cli_outdir_success_shape => isf_public_interface_cli_outdir_success_shape(),
        cli_hdl_generation_success_shape => isf_public_interface_cli_hdl_generation_success_shape(),
        cli_strict_hdl_generation_success_shape => isf_public_interface_cli_strict_hdl_generation_success_shape(),
        constructor_receiver_shape => 'exact class invocant: FSM::Adapter::ISF or FSM::Scheduler::ISF',
        constructor_argument_shape => 'even-length option/value list after class invocant; currently only debug is public',
        parser_method_receiver_shape => 'object returned by FSM::Adapter::ISF->new(...)',
        scheduler_method_receiver_shape => 'object returned by FSM::Scheduler::ISF->new(...)',
        parse_file_argument_shape => 'exactly one scalar filesystem path to a .isf source after object invocant',
        parse_file_path_requirement => 'defined scalar path with .isf suffix naming a readable regular file before private parsing',
        parse_source_argument_shape => 'exactly two scalar arguments after object invocant: source text and source label',
        parse_file_return_shape => isf_public_interface_parse_file_return_shape(),
        parse_source_return_shape => isf_public_interface_parse_source_return_shape(),
        lower_argument_shape => 'scheduler-consumable actor value returned by FSM::Adapter::ISF',
        report_argument_shape => 'scheduler-consumable actor value returned by FSM::Adapter::ISF',
        facade_failure_diagnostic_shape => isf_public_interface_facade_failure_diagnostic_shape(),
        lower_return_shape => isf_public_interface_lower_return_shape(),
        report_return_shape => isf_public_interface_report_return_shape(),
        actor_shell_required_keys => isf_public_interface_actor_shell_required_keys(),
        actor_shell_value_shape => isf_public_interface_actor_shell_value_shape(),
        actor_shell_actor_name_shape => isf_public_interface_actor_shell_actor_name_shape(),
        actor_shell_timing_shape => isf_public_interface_actor_shell_timing_shape(),
        actor_shell_interface_shape => isf_public_interface_actor_shell_interface_shape(),
        actor_shell_transaction_shape => isf_public_interface_actor_shell_transaction_shape(),
        actor_shell_rule_shape => isf_public_interface_actor_shell_rule_shape(),
        actor_shell_drive_shape => isf_public_interface_actor_shell_drive_shape(),
        lower_result_presence_keys => isf_public_interface_lower_result_presence_keys(),
        lower_result_file_map_shape => 'hash reference mapping .fsm basename to scheduled module, resolved ATL child module, generated ATL top, multi-domain domain scheduled module, specialized library-child module, generated multi-domain top, or generated composition-top .fsm source text',
        lower_result_file_name_shape => isf_public_interface_lower_result_file_name_shape(),
        lower_result_file_text_shape => isf_public_interface_lower_result_file_text_shape(),
        dt_assignment_operator_family_map => isf_public_interface_dt_assignment_operator_family_map(),
        scheduled_fsm_dt_ordering => isf_public_interface_dt_ordering_policy(),
        schedule_report_top_level_keys => isf_public_interface_schedule_report_top_level_keys(),
        schedule_report_source_shape => isf_public_interface_schedule_report_source_shape(),
        schedule_report_scheduled_fsm_shape => isf_public_interface_schedule_report_scheduled_fsm_shape(),
        schedule_report_clock_shape => isf_public_interface_schedule_report_clock_shape(),
        schedule_report_watchdog_shape => isf_public_interface_schedule_report_watchdog_shape(),
        schedule_report_clock_domain_keys => isf_public_interface_schedule_report_clock_domain_keys(),
        schedule_report_clock_domain_child_instance_keys => isf_public_interface_schedule_report_clock_domain_child_instance_keys(),
        schedule_report_clock_domain_crossing_endpoint_keys => isf_public_interface_schedule_report_clock_domain_crossing_endpoint_keys(),
        schedule_report_crossing_keys => isf_public_interface_schedule_report_crossing_keys(),
        schedule_report_actor_phase_keys => isf_public_interface_schedule_report_actor_phase_keys(),
        schedule_report_actor_stage_keys => isf_public_interface_schedule_report_actor_stage_keys(),
        schedule_report_verification_observation_keys => isf_public_interface_schedule_report_verification_observation_keys(),
        schedule_report_verification_observation_signal_keys => isf_public_interface_schedule_report_verification_observation_signal_keys(),
        schedule_report_verification_observation_role_values => isf_public_interface_schedule_report_verification_observation_role_values(),
        schedule_report_verification_bridge_keys => isf_public_interface_schedule_report_verification_bridge_keys(),
        schedule_report_verification_bridge_protocol_keys => isf_public_interface_schedule_report_verification_bridge_protocol_keys(),
        schedule_report_verification_bridge_fact_keys => isf_public_interface_schedule_report_verification_bridge_fact_keys(),
        schedule_report_verification_bridge_transaction_keys => isf_public_interface_schedule_report_verification_bridge_transaction_keys(),
        schedule_report_verification_bridge_field_keys => isf_public_interface_schedule_report_verification_bridge_field_keys(),
        schedule_report_verification_bridge_source_keys => isf_public_interface_schedule_report_verification_bridge_source_keys(),
        schedule_report_verification_bridge_event_keys => isf_public_interface_schedule_report_verification_bridge_event_keys(),
        schedule_report_verification_bridge_probe_keys => isf_public_interface_schedule_report_verification_bridge_probe_keys(),
        schedule_report_actor_network_keys => isf_public_interface_schedule_report_actor_network_keys(),
        schedule_report_actor_network_instance_keys => isf_public_interface_schedule_report_actor_network_instance_keys(),
        schedule_report_actor_network_resolved_instance_keys => isf_public_interface_schedule_report_actor_network_resolved_instance_keys(),
        schedule_report_actor_network_group_keys => isf_public_interface_schedule_report_actor_network_group_keys(),
        schedule_report_actor_network_generated_top_keys => isf_public_interface_schedule_report_actor_network_generated_top_keys(),
        schedule_report_actor_network_generated_top_multi_child_keys => isf_public_interface_schedule_report_actor_network_generated_top_multi_child_keys(),
        schedule_report_actor_network_generated_top_child_keys => isf_public_interface_schedule_report_actor_network_generated_top_child_keys(),
        schedule_report_actor_network_group_schedule_keys => isf_public_interface_schedule_report_actor_network_group_schedule_keys(),
        schedule_report_actor_network_association_schedule_keys => isf_public_interface_schedule_report_actor_network_association_schedule_keys(),
        schedule_report_actor_network_data_movement_keys => isf_public_interface_schedule_report_actor_network_data_movement_keys(),
        schedule_report_actor_network_event_wait_keys => isf_public_interface_schedule_report_actor_network_event_wait_keys(),
        schedule_report_actor_network_transaction_trigger_keys => isf_public_interface_schedule_report_actor_network_transaction_trigger_keys(),
        schedule_report_actor_param_keys => isf_public_interface_schedule_report_actor_param_keys(),
        schedule_report_actor_constant_keys => isf_public_interface_schedule_report_actor_constant_keys(),
        schedule_report_compile_issues_success_shape => isf_public_interface_schedule_report_compile_issues_success_shape(),
        schedule_report_compile_issue_keys => isf_public_interface_schedule_report_compile_issue_keys(),
        schedule_report_compile_issue_source_keys => isf_public_interface_schedule_report_compile_issue_source_keys(),
        schedule_report_bank_access_keys => isf_public_interface_schedule_report_bank_access_keys(),
        schedule_report_bank_access_kind_values => isf_public_interface_schedule_report_bank_access_kind_values(),
        schedule_report_bank_access_policy_values => isf_public_interface_schedule_report_bank_access_policy_values(),
        schedule_report_transaction_port_binding_keys => isf_public_interface_schedule_report_transaction_port_binding_keys(),
        schedule_report_transaction_port_binding_actor_endpoint_kind_values => isf_public_interface_schedule_report_transaction_port_binding_actor_endpoint_kind_values(),
        schedule_report_transaction_port_binding_timing_values => isf_public_interface_schedule_report_transaction_port_binding_timing_values(),
        schedule_report_transaction_port_binding_authored_timing_mode_values => isf_public_interface_schedule_report_transaction_port_binding_authored_timing_mode_values(),
        schedule_report_transaction_port_binding_site_kind_values => isf_public_interface_schedule_report_transaction_port_binding_site_kind_values(),
        schedule_report_compile_issue_severity_values => isf_public_interface_schedule_report_compile_issue_severity_values(),
        schedule_report_compile_issue_proof_status_values => isf_public_interface_schedule_report_compile_issue_proof_status_values(),
        schedule_report_fanin_group_required_keys => isf_public_interface_schedule_report_fanin_group_required_keys(),
        schedule_report_fanin_group_optional_keys => isf_public_interface_schedule_report_fanin_group_optional_keys(),
        schedule_report_fanin_group_kind_values => isf_public_interface_schedule_report_fanin_group_kind_values(),
        schedule_report_priority_resolution_keys => isf_public_interface_schedule_report_priority_resolution_keys(),
        schedule_report_resource_arbitration_keys => isf_public_interface_schedule_report_resource_arbitration_keys(),
        schedule_report_generated_composition_required_keys => isf_public_interface_schedule_report_generated_composition_required_keys(),
        schedule_report_generated_composition_kind_values => isf_public_interface_schedule_report_generated_composition_kind_values(),
        schedule_report_generated_composition_parent_keys => isf_public_interface_schedule_report_generated_composition_parent_keys(),
        schedule_report_generated_composition_child_keys => isf_public_interface_schedule_report_generated_composition_child_keys(),
        schedule_report_generated_composition_child_parameter_keys => isf_public_interface_schedule_report_generated_composition_child_parameter_keys(),
        schedule_report_generated_composition_instance_keys => isf_public_interface_schedule_report_generated_composition_instance_keys(),
        schedule_report_generated_composition_link_keys => isf_public_interface_schedule_report_generated_composition_link_keys(),
        schedule_report_generated_composition_binding_keys => isf_public_interface_schedule_report_generated_composition_binding_keys(),
        schedule_report_generated_composition_drive_handoff_keys => isf_public_interface_schedule_report_generated_composition_drive_handoff_keys(),
        schedule_report_generated_composition_payload_keys => isf_public_interface_schedule_report_generated_composition_payload_keys(),
        schedule_report_library_use_keys => isf_public_interface_schedule_report_library_use_keys(),
        schedule_report_library_use_parameter_keys => isf_public_interface_schedule_report_library_use_parameter_keys(),
        schedule_report_library_use_binding_keys => isf_public_interface_schedule_report_library_use_binding_keys(),
        schedule_report_multi_file_scope => isf_public_interface_schedule_report_multi_file_scope(),
        schedule_report_interface_count_shape => isf_public_interface_schedule_report_interface_count_shape(),
        schedule_report_state_count_shape => isf_public_interface_schedule_report_state_count_shape(),
        schedule_report_presence_key_family_map => isf_public_interface_schedule_report_presence_key_family_map(),
        schedule_report_reset_shape => isf_public_interface_schedule_report_reset_shape(),
        schedule_report_reset_keys => isf_public_interface_schedule_report_reset_keys(),
        schedule_report_reset_provenance => reset_provenance_contract(),
        schedule_report_interface_ports => interface_port_metadata_contract(),
        schedule_report_reductions => reduction_metadata_contract(),
        schedule_report_reset_kind_values => isf_public_interface_schedule_report_reset_kind_values(),
        schedule_report_reset_polarity_values => isf_public_interface_schedule_report_reset_polarity_values(),
        schedule_report_storage_required_keys => isf_public_interface_schedule_report_storage_required_keys(),
        schedule_report_storage_optional_keys => isf_public_interface_schedule_report_storage_optional_keys(),
        schedule_report_storage_kind_values => isf_public_interface_schedule_report_storage_kind_values(),
        schedule_report_storage_role_values => isf_public_interface_schedule_report_storage_role_values(),
        schedule_report_storage_width_shape => isf_public_interface_schedule_report_storage_width_shape(),
        schedule_report_transaction_keys => isf_public_interface_schedule_report_transaction_keys(),
        schedule_report_transaction_states_shape => isf_public_interface_schedule_report_transaction_states_shape(),
        schedule_report_transaction_count_shape => isf_public_interface_schedule_report_transaction_count_shape(),
        schedule_report_transaction_ordering => isf_public_interface_schedule_report_transaction_ordering(),
        schedule_report_transaction_loop_keys => isf_public_interface_schedule_report_transaction_loop_keys(),
        schedule_report_transaction_wait_keys => isf_public_interface_schedule_report_transaction_wait_keys(),
        schedule_report_transaction_wait_count_kind_values => isf_public_interface_schedule_report_transaction_wait_count_kind_values(),
        schedule_report_transaction_stage_keys => isf_public_interface_schedule_report_transaction_stage_keys(),
        schedule_report_transaction_stage_kind_values => isf_public_interface_schedule_report_transaction_stage_kind_values(),
        schedule_report_temporal_contract_keys => isf_public_interface_schedule_report_temporal_contract_keys(),
        schedule_report_temporal_contract_kind_values => isf_public_interface_schedule_report_temporal_contract_kind_values(),
        schedule_report_temporal_contract_overlap_policy_values => isf_public_interface_schedule_report_temporal_contract_overlap_policy_values(),
        schedule_report_temporal_contract_assertion_projection_values => isf_public_interface_schedule_report_temporal_contract_assertion_projection_values(),
        schedule_report_temporal_contract_reset_policy_shape => isf_public_interface_schedule_report_temporal_contract_reset_policy_shape(),
        schedule_report_dt_keys => isf_public_interface_schedule_report_dt_keys(),
        schedule_report_dt_kind_values => isf_public_interface_schedule_report_dt_kind_values(),
        schedule_report_dt_assignments_shape => isf_public_interface_schedule_report_dt_assignments_shape(),
        schedule_report_dt_ordering => isf_public_interface_dt_ordering_policy(),
        live_document_paths => isf_public_interface_live_document_paths(),
        live_contract_documentation => JSON::PP::true,
        evolves_with_isf_implementation => JSON::PP::true,
        raw_actor_full_hash_stable => JSON::PP::false,
        lowering_ir_full_hash_stable => JSON::PP::false,
        schedule_report_full_schema_stable => JSON::PP::true,
        scheduled_fsm_text_is_review_artifact => JSON::PP::true,
        tested_by => [
            't/1096-isf-schedule-json-report.t',
            't/1112-isf-public-interface-contract.t',
            't/1113-isf-public-interface-contract-json-roundtrip-audit.t',
            't/1114-isf-public-interface-contract-defensive-copy-audit.t',
            't/1115-isf-public-interface-cli-manifest-audit.t',
            't/1116-isf-public-schedule-report-key-family-audit.t',
            't/1117-isf-public-lower-result-files-audit.t',
            't/1118-isf-public-parse-source-facade-audit.t',
            't/1119-isf-deterministic-dt-block-order.t',
            't/1120-isf-public-live-document-path-audit.t',
            't/1121-isf-public-cli-schedule-report-audit.t',
            't/1122-isf-public-cli-outdir-lowering-audit.t',
            't/1123-isf-public-cli-hdl-generation-audit.t',
            't/1124-isf-public-cli-strict-mode-audit.t',
            't/1125-isf-public-constructor-boundary-audit.t',
            't/1126-isf-public-parser-method-boundary-audit.t',
            't/1127-isf-public-scheduler-method-boundary-audit.t',
            't/1128-isf-public-multifile-schedule-report-audit.t',
            't/1129-isf-public-actor-shell-contract-audit.t',
            't/1130-isf-public-compile-issues-success-audit.t',
            't/1131-isf-public-top-level-discovery-audit.t',
            't/1132-isf-public-method-receiver-boundary-audit.t',
            't/1133-isf-public-constructor-receiver-boundary-audit.t',
            't/1134-isf-public-parse-file-path-boundary-audit.t',
            't/1135-isf-public-entrypoint-metadata-audit.t',
            't/1136-isf-public-cli-option-metadata-audit.t',
            't/1137-isf-public-method-name-metadata-audit.t',
            't/1138-isf-public-constructor-option-metadata-audit.t',
            't/1139-isf-public-lower-result-metadata-audit.t',
            't/1140-isf-public-schedule-report-metadata-audit.t',
            't/1141-isf-public-identity-flags-metadata-audit.t',
            't/1142-isf-public-guidance-metadata-audit.t',
            't/1143-isf-public-facade-shape-metadata-audit.t',
            't/1144-isf-public-tested-by-metadata-audit.t',
            't/1145-isf-public-scheduled-fsm-metadata-audit.t',
            't/1146-isf-public-dt-assignment-metadata-audit.t',
            't/1147-isf-public-report-dt-assignment-count-audit.t',
            't/1148-isf-public-storage-metadata-audit.t',
            't/1149-isf-public-transaction-metadata-audit.t',
            't/1150-isf-public-reset-metadata-audit.t',
            't/1151-isf-public-report-count-metadata-audit.t',
            't/1152-isf-public-report-scalar-metadata-audit.t',
            't/1153-isf-public-cli-success-metadata-audit.t',
            't/1154-isf-public-facade-return-metadata-audit.t',
            't/1155-isf-public-cli-strict-success-metadata-audit.t',
            't/1156-isf-public-lower-result-file-shape-audit.t',
            't/1157-isf-public-report-transaction-ordering-audit.t',
            't/1158-isf-public-report-dt-kind-metadata-audit.t',
            't/1159-isf-public-report-reset-shape-metadata-audit.t',
            't/1978-isf-reset-provenance.t',
            't/1160-isf-public-actor-shell-value-shape-audit.t',
            't/1161-isf-public-facade-failure-diagnostic-metadata-audit.t',
            't/1162-isf-public-actor-shell-interface-shape-audit.t',
            't/1163-isf-public-actor-shell-transaction-shape-audit.t',
            't/1164-isf-public-actor-shell-actor-name-shape-audit.t',
            't/1165-isf-public-actor-shell-timing-shape-audit.t',
            't/1166-isf-public-actor-shell-rule-shape-audit.t',
            't/1167-isf-public-actor-shell-drive-shape-audit.t',
            't/1168-isf-rule-guard-factoring.t',
            't/1169-isf-rule-shorthand-guard.t',
            't/1171-isf-rule-trigger-fanin.t',
            't/1172-isf-rule-trigger-fanin-schedule-report.t',
            't/1173-isf-shift-right-explicit-width.t',
            't/1174-isf-extract-explicit-widths.t',
            't/1176-isf-resource-priority-boundary.t',
            't/1177-isf-do-child-done-pulse.t',
            't/1178-isf-handshake-compatibility-boundary.t',
            't/1179-isf-phase-stage-boundary.t',
            't/1180-isf-unsupported-transaction-clause-boundary.t',
            't/1181-isf-rule-action-boundary.t',
            't/1182-isf-rule-trigger-target-boundary.t',
            't/1184-isf-child-transaction-target-boundary.t',
            't/1185-isf-transaction-name-boundary.t',
            't/1186-isf-rule-name-boundary.t',
            't/1187-isf-drive-name-boundary.t',
            't/1188-isf-interface-port-boundary.t',
            't/1189-isf-drive-parameter-boundary.t',
            't/1190-isf-rule-priority-target-boundary.t',
            't/1191-isf-actor-priority-target-boundary.t',
            't/1192-isf-singleton-actor-clause-boundary.t',
            't/1193-isf-drive-call-arity-boundary.t',
            't/1194-isf-drive-body-boundary.t',
            't/1195-isf-sample-clause-boundary.t',
            't/1196-isf-complete-clause-boundary.t',
            't/1197-isf-latency-clause-boundary.t',
            't/1361-isf-latency-package-constant-bounds.t',
            't/1198-isf-update-clause-boundary.t',
            't/1199-isf-shift-clause-boundary.t',
            't/1200-isf-assemble-clause-boundary.t',
            't/1201-isf-extract-clause-boundary.t',
            't/1202-isf-repeat-clause-boundary.t',
            't/1203-isf-await-sync-clause-boundary.t',
            't/1204-isf-child-composition-clause-boundary.t',
            't/1205-isf-switch-clause-boundary.t',
            't/1206-isf-when-clause-boundary.t',
            't/1209-isf-static-conflict-detection.t',
            't/1210-isf-priority-conflict-resolution.t',
            't/1211-isf-runtime-selector-conflict-instrumentation.t',
            't/1212-isf-schedule-report-compile-issues-projection.t',
            't/1213-isf-schedule-report-compatible-fanin-projection.t',
            't/1214-isf-rejected-conflict-diagnostics.t',
            't/1215-isf-spawn-parameter-binding.t',
            't/1216-isf-generated-composition-top.t',
            't/1217-isf-generated-composition-schedule-report.t',
            't/1218-isf-rule-slot-resource-arbitration.t',
            't/1219-isf-rule-transaction-priority.t',
            't/1220-isf-arbitration-schedule-report.t',
            't/1221-isf-rule-expression-assignment.t',
            't/1222-isf-rule-expression-conflict-report.t',
            't/1223-isf-stage-lowering.t',
            't/1369-isf-timing-param-activation-override-gates.t',
            't/1226-isf-data-width-storage-report.t',
            't/1227-isf-schedule-report-freeze-boundary.t',
            't/1228-isf-spi-fixture-coverage.t',
            't/1229-isf-compatibility-cli-parity.t',
            't/1230-isf-library-import-resolution.t',
            't/1231-isf-library-generated-top.t',
            't/1232-isf-actor-storage-declarations.t',
            't/1453-isf-storage-field-metadata.t',
            't/1981-isf-storage-word-access.t',
            't/1982-isf-domain-storage-report.t',
            't/1233-isf-rule-expression-guards.t',
            't/1234-isf-disjoint-rule-writes.t',
            't/1235-isf-fifo-same-cycle-update-matrix.t',
            't/1236-isf-bank-access-lowering.t',
            't/1237-isf-fifo-library-fixture.t',
            't/1238-isf-fifo-library-hdl-generation.t',
            't/1239-isf-library-catalog-contract.t',
            't/1240-isf-transaction-port-declarations.t',
            't/1241-isf-transaction-port-bindings.t',
            't/1242-isf-port-binding-conflict-semantics.t',
            't/1243-isf-port-binding-schedule-report.t',
            't/1244-isf-wait-clause-lowering.t',
            't/1245-isf-transaction-loop-lowering.t',
            't/1246-isf-setter-syntax.t',
            't/1247-isf-clock-domain-partition.t',
            't/1248-isf-rule-trigger-parameter-binding.t',
            't/1249-isf-activation-parameter-constants.t',
            't/1252-isf-actor-phase-stage-report.t',
            't/1253-isf-actor-param-report.t',
            't/1255-isf-schedule-report-golden-matrix.t',
            't/1257-isf-scalar-type-aliases.t',
            't/1258-isf-enum-member-constants.t',
            't/1259-isf-aggregate-storage-type-aliases.t',
            't/1260-isf-aggregate-storage-leaf-reads.t',
            't/1261-isf-aggregate-storage-leaf-writes.t',
            't/1262-isf-aggregate-storage-leaf-expression-reads.t',
            't/1263-isf-enum-member-set-values.t',
            't/1264-isf-enum-member-set-expression-values.t',
            't/1265-isf-enum-member-switch-branch-values.t',
            't/1266-isf-enum-member-drive-values.t',
            't/1267-isf-enum-member-drive-call-values.t',
            't/1268-isf-enum-member-drive-call-expression-values.t',
            't/1269-isf-enum-member-actor-params.t',
            't/1270-isf-enum-member-transaction-params.t',
            't/1271-isf-enum-member-activation-params.t',
            't/1272-isf-enum-member-rule-values.t',
            't/1273-isf-enum-member-rule-expression-values.t',
            't/1274-isf-enum-member-rule-guard-values.t',
            't/1275-isf-enum-member-condition-values.t',
            't/1276-isf-enum-member-activation-aggregate-params.t',
            't/1277-isf-enum-member-actor-aggregate-params.t',
            't/1278-isf-enum-member-transaction-aggregate-params.t',
            't/1279-isf-enum-member-inline-drive-values.t',
            't/1280-isf-enum-member-inline-drive-expression-values.t',
            't/1281-isf-enum-member-library-use-params.t',
            't/1282-isf-enum-member-drive-expression-values.t',
            't/1283-isf-aggregate-rule-values.t',
            't/1284-isf-aggregate-rule-expression-values.t',
            't/1285-isf-aggregate-rule-guard-values.t',
            't/1286-isf-aggregate-condition-values.t',
            't/1287-isf-aggregate-drive-values.t',
            't/1288-isf-aggregate-drive-expression-values.t',
            't/1289-isf-aggregate-drive-call-values.t',
            't/1290-isf-aggregate-drive-call-expression-values.t',
            't/1291-isf-aggregate-inline-drive-values.t',
            't/1292-isf-aggregate-inline-drive-expression-values.t',
            't/1293-isf-aggregate-switch-branch-values.t',
            't/1294-isf-aggregate-switch-selector-values.t',
            't/1295-isf-enum-member-switch-selector-values.t',
            't/1296-isf-aggregate-rule-target-values.t',
            't/1297-isf-aggregate-drive-target-values.t',
            't/1298-isf-aggregate-inline-drive-target-values.t',
            't/1299-isf-aggregate-standalone-condition-values.t',
            't/1300-isf-enum-member-standalone-condition-values.t',
            't/1301-isf-enum-member-rule-standalone-guard-values.t',
            't/1302-isf-aggregate-rule-standalone-guard-values.t',
            't/1303-isf-public-live-book-paths-audit.t',
            't/1308-isf-dynamic-divisor-safety.t',
            't/1309-isf-i2c-fixture-coverage.t',
            't/1310-isf-burst-fixture-coverage.t',
            't/1311-isf-uart-fixture-coverage.t',
            't/1312-isf-phase-fixture-coverage.t',
            't/1313-isf-switch-fixture-coverage.t',
            't/1314-isf-when-fixture-coverage.t',
            't/1315-isf-generated-composition-fixture-coverage.t',
            't/1316-isf-rule-resource-fixture-coverage.t',
            't/1318-isf-shift-left-explicit-width.t',
            't/1319-isf-fifo-datapath-fixture-coverage.t',
            't/1320-isf-fifo-controller-fixture-coverage.t',
            't/1321-isf-fifo-library-fixture-coverage.t',
            't/1322-isf-actor-network-static.t',
            't/1324-isf-atl-fixture-coverage.t',
            't/1325-isf-atl-data-route-fixture-coverage.t',
            't/1326-isf-atl-pin-ingress-fixture-coverage.t',
            't/1327-isf-atl-pin-egress-fixture-coverage.t',
            't/1328-isf-atl-trigger-wait-fixture-coverage.t',
            't/1329-isf-atl-trigger-batch-wait-fixture-coverage.t',
            't/1330-isf-atl-resolved-child-fixture-coverage.t',
            't/1331-isf-timing-conventions.t',
            't/1363-isf-watchdog-package-constant-limits.t',
            't/1333-isf-interface-actor-param-widths.t',
            't/1334-isf-scalar-storage-actor-param-widths.t',
            't/1335-isf-bank-storage-actor-param-widths.t',
            't/1336-isf-transaction-port-actor-param-widths.t',
            't/1337-isf-bank-storage-actor-param-depths.t',
            't/1338-isf-interface-actor-constant-widths.t',
            't/1353-isf-interface-package-constant-widths.t',
            't/1339-isf-scalar-storage-actor-constant-widths.t',
            't/1354-isf-scalar-storage-package-constant-widths.t',
            't/1340-isf-bank-storage-actor-constant-widths.t',
            't/1355-isf-bank-storage-package-constant-widths.t',
            't/1341-isf-bank-storage-actor-constant-depths.t',
            't/1356-isf-bank-storage-package-constant-depths.t',
            't/1342-isf-transaction-port-actor-constant-widths.t',
            't/1343-isf-data-op-static-width-sources.t',
            't/1344-isf-assemble-static-part-widths.t',
            't/1345-isf-actor-param-actor-constants.t',
            't/1346-isf-actor-param-actor-params.t',
            't/1347-isf-transaction-param-actor-static-defaults.t',
            't/1348-isf-transaction-param-transaction-params.t',
            't/1349-isf-actor-param-package-constants.t',
            't/1350-isf-transaction-param-package-constants.t',
            't/1351-isf-activation-param-package-constants.t',
            't/1352-isf-library-use-package-constants.t',
            't/1357-isf-transaction-port-package-constant-widths.t',
            't/1368-isf-transaction-port-transaction-param-widths.t',
            't/1358-isf-data-op-package-constant-widths.t',
            't/1359-isf-wait-package-constant-counts.t',
            't/1360-isf-repeat-package-constant-counts.t',
            't/1367-isf-data-op-transaction-param-widths.t',
            't/1476-isf-output-default-reset.t',
        ],
        guidance => [
            'Treat this as the first bounded public ISF downstream-consumer contract, advertised through embedding.isf_public_interface.',
            'Treat the contract as live: exact metadata audits describe the current advertised surface, not a promise that ISF or the schedule-report schema is frozen.',
            'The public in-process seam is the parser/scheduler facade pair, not the raw parser AST or LoweringIR internals.',
            'The lower(...) result currently advertises the files map as scheduled module, resolved ATL child module, generated ATL top, multi-domain domain scheduled module, specialized library-child module, generated multi-domain top, and generated composition-top .fsm artifacts; the whole result hash is not yet a broad API.',
            'The library catalog path list and shipped_library_definitions entries are live discovery metadata for reusable ISF definitions; add or change entries only with source, limitations, and tests updated together.',
            'The schedule report currently advertises only the named top-level and summary key families; wider schema promises must be documented and regression-backed before downstream tools rely on them.',
            'The live human contract documents must evolve in the same slices that change supported ISF syntax, facade behavior, lower result shape, or schedule-report shape.',
            'Feature-driven public ISF changes must move the matching public contract and manifest audit tests in the same slice as the implementation.',
        ],
    };
}

sub isf_public_interface_public_top_level_keys {
    return [
        qw(
            schema_version
            status
            contract_source
            implementation_owners
            entrypoints
            public_top_level_presence_keys
            parser_method_names
            scheduler_method_names
            constructor_option_names
            cli_option_names
            resource_arbiter_values
            resource_kind_values
            resource_kind_status_map
            resource_kind_meaning_map
            enforced_resource_kind_values
            backlog_resource_kind_values
            library_catalog_paths
            library_catalog_entry_keys
            shipped_library_definitions
            cli_schedule_json_success_shape
            cli_outdir_success_shape
            cli_hdl_generation_success_shape
            cli_strict_hdl_generation_success_shape
            constructor_receiver_shape
            constructor_argument_shape
            parser_method_receiver_shape
            scheduler_method_receiver_shape
            parse_file_argument_shape
            parse_file_path_requirement
            parse_source_argument_shape
            parse_file_return_shape
            parse_source_return_shape
            lower_argument_shape
            report_argument_shape
            facade_failure_diagnostic_shape
            lower_return_shape
            report_return_shape
            actor_shell_required_keys
            actor_shell_value_shape
            actor_shell_actor_name_shape
            actor_shell_timing_shape
            actor_shell_interface_shape
            actor_shell_transaction_shape
            actor_shell_rule_shape
            actor_shell_drive_shape
            lower_result_presence_keys
            lower_result_file_map_shape
            lower_result_file_name_shape
            lower_result_file_text_shape
            dt_assignment_operator_family_map
            scheduled_fsm_dt_ordering
            schedule_report_top_level_keys
            schedule_report_source_shape
            schedule_report_scheduled_fsm_shape
            schedule_report_clock_shape
            schedule_report_watchdog_shape
            schedule_report_actor_phase_keys
            schedule_report_actor_stage_keys
            schedule_report_verification_bridge_keys
            schedule_report_verification_bridge_protocol_keys
            schedule_report_verification_bridge_fact_keys
            schedule_report_verification_bridge_transaction_keys
            schedule_report_verification_bridge_field_keys
            schedule_report_verification_bridge_source_keys
            schedule_report_verification_bridge_event_keys
            schedule_report_verification_bridge_probe_keys
            schedule_report_actor_network_keys
            schedule_report_actor_network_instance_keys
            schedule_report_actor_network_resolved_instance_keys
            schedule_report_actor_network_group_keys
            schedule_report_actor_network_generated_top_keys
            schedule_report_actor_network_generated_top_multi_child_keys
            schedule_report_actor_network_generated_top_child_keys
            schedule_report_actor_network_group_schedule_keys
            schedule_report_actor_network_association_schedule_keys
            schedule_report_actor_network_data_movement_keys
            schedule_report_actor_network_event_wait_keys
            schedule_report_actor_network_transaction_trigger_keys
            schedule_report_actor_param_keys
            schedule_report_actor_constant_keys
            schedule_report_clock_domain_keys
            schedule_report_clock_domain_child_instance_keys
            schedule_report_clock_domain_crossing_endpoint_keys
            schedule_report_crossing_keys
            schedule_report_compile_issues_success_shape
            schedule_report_compile_issue_keys
            schedule_report_compile_issue_source_keys
            schedule_report_bank_access_keys
            schedule_report_bank_access_kind_values
            schedule_report_bank_access_policy_values
            schedule_report_transaction_port_binding_keys
            schedule_report_transaction_port_binding_actor_endpoint_kind_values
            schedule_report_transaction_port_binding_timing_values
            schedule_report_transaction_port_binding_authored_timing_mode_values
            schedule_report_transaction_port_binding_site_kind_values
            schedule_report_compile_issue_severity_values
            schedule_report_compile_issue_proof_status_values
            schedule_report_fanin_group_required_keys
            schedule_report_fanin_group_optional_keys
            schedule_report_fanin_group_kind_values
            schedule_report_priority_resolution_keys
            schedule_report_resource_arbitration_keys
            schedule_report_generated_composition_required_keys
            schedule_report_generated_composition_kind_values
            schedule_report_generated_composition_parent_keys
            schedule_report_generated_composition_child_keys
            schedule_report_generated_composition_child_parameter_keys
            schedule_report_generated_composition_instance_keys
            schedule_report_generated_composition_link_keys
            schedule_report_generated_composition_binding_keys
            schedule_report_generated_composition_drive_handoff_keys
            schedule_report_generated_composition_payload_keys
            schedule_report_library_use_keys
            schedule_report_library_use_parameter_keys
            schedule_report_library_use_binding_keys
            schedule_report_multi_file_scope
            schedule_report_interface_count_shape
            schedule_report_state_count_shape
            schedule_report_presence_key_family_map
            schedule_report_reset_shape
            schedule_report_reset_keys
            schedule_report_reset_provenance
            schedule_report_interface_ports
            schedule_report_reductions
            schedule_report_reset_kind_values
            schedule_report_reset_polarity_values
            schedule_report_storage_required_keys
            schedule_report_storage_optional_keys
            schedule_report_storage_kind_values
            schedule_report_storage_role_values
            schedule_report_storage_width_shape
            schedule_report_transaction_keys
            schedule_report_transaction_states_shape
            schedule_report_transaction_count_shape
            schedule_report_transaction_ordering
            schedule_report_transaction_loop_keys
            schedule_report_transaction_wait_keys
            schedule_report_transaction_wait_count_kind_values
            schedule_report_transaction_stage_keys
            schedule_report_transaction_stage_kind_values
            schedule_report_verification_observation_keys
            schedule_report_verification_observation_role_values
            schedule_report_verification_observation_signal_keys
            schedule_report_temporal_contract_keys
            schedule_report_temporal_contract_kind_values
            schedule_report_temporal_contract_overlap_policy_values
            schedule_report_temporal_contract_assertion_projection_values
            schedule_report_temporal_contract_reset_policy_shape
            schedule_report_dt_keys
            schedule_report_dt_kind_values
            schedule_report_dt_assignments_shape
            schedule_report_dt_ordering
            live_document_paths
            live_contract_documentation
            evolves_with_isf_implementation
            raw_actor_full_hash_stable
            lowering_ir_full_hash_stable
            schedule_report_full_schema_stable
            scheduled_fsm_text_is_review_artifact
            tested_by
            guidance
        ),
    ];
}

sub isf_public_interface_resource_arbiter_values {
    return isf_resource_arbiter_values();
}

sub isf_public_interface_resource_kind_values {
    return isf_resource_kind_values();
}

sub isf_public_interface_resource_kind_status_map {
    return isf_resource_kind_status_map();
}

sub isf_public_interface_resource_kind_meaning_map {
    return isf_resource_kind_meaning_map();
}

sub isf_public_interface_enforced_resource_kind_values {
    return isf_enforced_resource_kind_values();
}

sub isf_public_interface_backlog_resource_kind_values {
    return isf_backlog_resource_kind_values();
}

sub isf_public_interface_library_catalog_paths {
    return [
        qw(
            docs/ISF_LIBRARY_CATALOG.md
        ),
    ];
}

sub isf_public_interface_library_catalog_entry_keys {
    return [
        qw(
            qualified_name
            library
            export
            kind
            status
            source
            import_fixture
            parameters
            interface
            storage
            semantics
            tests
            limitations
        ),
    ];
}

sub isf_public_interface_shipped_library_definitions {
    return [
        {
            qualified_name => 'common.fifo.fifo',
            library => 'common.fifo',
            export => 'fifo',
            kind => 'actor',
            status => 'shipped',
            source => 'isf/common/fifo.isf',
            import_fixture => 'isf/fifo_library_use.isf',
            parameters => [
                { name => 'DATA_WIDTH', value => '8' },
                { name => 'DEPTH', value => '4' },
                { name => 'PTR_WIDTH', value => '2' },
                { name => 'OCC_WIDTH', value => '3' },
            ],
            interface => {
                inputs => [
                    { name => 'write_req', width => 1 },
                    { name => 'data_in', width => 8 },
                    { name => 'read_req', width => 1 },
                ],
                outputs => [
                    { name => 'full', width => 1 },
                    { name => 'empty', width => 1 },
                    { name => 'data_out', width => 8 },
                ],
            },
            storage => [
                { name => 'wr_ptr', kind => 'var', width => 2 },
                { name => 'rd_ptr', kind => 'var', width => 2 },
                { name => 'occupancy', kind => 'var', width => 3 },
                { name => 'data', kind => 'bank', width => 8, depth => 4 },
            ],
            semantics => [
                'actor-maintained full and empty flags',
                'idle, push-only, pop-only, and push-plus-pop request cases',
                'depth-4 pointer wrap for wr_ptr and rd_ptr',
                'read-before-write same-cycle bank access policy',
                'retained importing-actor inputs and direct library-output readbacks',
                'outputs reset low; the first idle clock after release sets empty',
                'explicit and inferred clock/reset bindings use the selected domain',
            ],
            tests => [
                't/1237-isf-fifo-library-fixture.t',
                't/1238-isf-fifo-library-hdl-generation.t',
                't/1321-isf-fifo-library-fixture-coverage.t',
                't/1914-isf-library-parent-interfaces.t',
                't/1915-isf-library-domain-system-bindings.t',
            ],
            limitations => [
                'fixed-shape DATA_WIDTH=8 DEPTH=4 fixture',
                'no use-site parameter-driven FIFO interface shape, bank-depth specialization, or generated-top respecialization yet',
                'no memory-array backend emission yet',
                'no standalone transaction or drive library exports yet',
                'no nested library imports from library actors yet',
                'no reset-policy override at use sites; clock/reset name remapping keeps actor-owned reset policy',
            ],
        },
    ];
}

sub isf_public_interface_parser_method_names {
    return [
        qw(
            new
            parse_file
            parse_source
        ),
    ];
}

sub isf_public_interface_scheduler_method_names {
    return [
        qw(
            new
            lower
            report
        ),
    ];
}

sub isf_public_interface_constructor_option_names {
    return [
        qw(
            debug
        ),
    ];
}

sub isf_public_interface_cli_option_names {
    return [
        qw(
            --emit-schedule-json
            --outdir
            --strict
        ),
    ];
}

sub isf_public_interface_cli_schedule_json_success_shape {
    return '--emit-schedule-json writes schedule-report JSON to stdout and keeps stderr empty on success';
}

sub isf_public_interface_cli_outdir_success_shape {
    return '--outdir DIR writes lower-result .fsm files by basename into DIR and keeps stderr empty on success';
}

sub isf_public_interface_cli_hdl_generation_success_shape {
    return 'plain single-clock file.isf generation lowers through scheduled .fsm and writes requested HDL output with empty stderr on success; accepted multi-domain event-crossing actors lower through generated domain/top artifacts and emit SystemVerilog/Verilog-family HDL with a concrete generated acknowledged-event CDC child when each emitted domain artifact satisfies the current scheduled .fsm HDL contract, including clock-only no-reset domain artifacts';
}

sub isf_public_interface_cli_strict_hdl_generation_success_shape {
    return '--strict file.isf generation follows cli_hdl_generation_success_shape for accepted ISF inputs and keeps stderr empty on success';
}

sub isf_public_interface_actor_shell_required_keys {
    return [
        qw(
            actor_name
            transactions
            interface
        ),
    ];
}

sub isf_public_interface_actor_shell_value_shape {
    return 'actor_name is scalar; transactions is an array reference; interface is a hash reference; storage is an optional array reference for authored scalar storage and bank declarations when actor-owned storage is declared; scalar width-based storage variables may carry optional parser-validated declarative fields metadata with literal bit ranges, non-overlap, optional access/reset/inline enum metadata, and report-only inferred_storage[].fields projection; scalar width-based storage variables also accept optional word access with the same checked token vocabulary, independent of field metadata and reported as inferred_storage[].access without changing generated hardware; actor interface widths, scalar storage widths, bank widths, and bank depths are resolved positive integers from literals, actor constants, actor-local scalar parameters, or qualified imported package scalar constants; transaction-local port widths are resolved positive integers from literals, same-transaction scalar parameter defaults on generated child or direct transactions, actor constants, actor-local scalar parameters, or qualified imported package scalar constants; data-operation explicit width evidence for shift, assemble, and extract accepts positive literal, same-transaction scalar parameter default on generated child or direct transactions, actor constant, actor-local scalar parameter, or qualified imported package scalar constant sources before scheduler publication; constants is an optional array reference for actor-local compile-time integer constants; same-transaction scalar parameter defaults may back static transaction wait counts, positive latency bounds, and positive top-level await-local watchdog limits while shadowing actor-level static names and remaining local lowering inputs; generated child activation overrides for repeat, wait, latency, top-level await-local watchdog, and contract-window transaction parameters are accepted only when they preserve the child default value, with mismatches failing closed until per-activation specialization ships; imported package scalar constants are exposed through bounded package constant symbol metadata and may back actor parameter defaults and generated-child transaction parameter defaults while preserving authored qualified tokens where the published artifact carries package imports, may back generated activation parameter override values while publishing resolved literal bindings, may back static transaction wait counts while publishing the authored qualified token in transaction_waits[], may back static repeat counts, with zero counts lowering as no-op repeat regions, static-zero repeat-body do/spawn activations including syntactically valid parameterized, bound, or domain-annotated variants pruning child/top artifacts when their targets are not otherwise live, and positive counts preserving the authored qualified token in scheduled .fsm repeat-counter loads, and may back positive actor-level and await-local watchdog limits while reporting resolved integers; clock_domains is null for legacy one-clock actors or an optional live metadata hash for accepted clock-domain declarations; crossings is an optional array reference for accepted clock-domain event crossing declarations; actor_network is null when omitted or a bounded static_declaration metadata hash for the current ATL subset, including direct static actor instance metadata from verbose instances or compact instance aliases, resolved library-qualified actor type metadata and child artifact names, report-only static group metadata from verbose groups or compact concurrent aliases, selected parent-handoff event waits, selected parent-handoff transaction triggers, selected temporary trigger batches, selected generated ATL tops, and selected scalar or exact-width vector actor-to-actor data movements including the bounded generated-child reader-to-writer handoff route when present; unsupported qualified ATL trigger and endpoint-aware drive movement variants fail closed before scheduled emission when the qualifier names a static actor instance';
}

sub isf_public_interface_actor_shell_actor_name_shape {
    return 'actor_name is a non-empty scalar actor identifier preserved from the ISF actor root';
}

sub isf_public_interface_actor_shell_timing_shape {
    return 'clock is a non-empty scalar; legacy single-clock actors omitted clock default to clk, and clock is the default-domain clock when clock_domains is present; legacy single-clock actors omitted reset default to async active-low rst_n, while reset is null only when the selected default clock-domain reset is omitted or is a hash with scalar name, kind, and polarity for the default domain; watchdog is a positive integer, omitted watchdog defaults to 65535 (2^16 - 1), and actor-level positive actor constants, actor scalar parameters, or qualified imported package scalar constants resolve to the same scalar; source clock, reset, watchdog, interface, resources, storage, clock-domains, and crossings clauses are singleton actor clauses; multi-domain scheduler lower emits domain-specific scheduled .fsm artifacts plus a generated multi-domain top, and report calls expose bounded domain and crossing metadata';
}

sub isf_public_interface_actor_shell_interface_shape {
    return 'interface has inputs and outputs arrays; each public port entry has unique non-empty scalar name and positive integer width, defaulting omitted source widths to 1; actor top-level interface width parameters, constants, and qualified imported package scalar constants are accepted when they resolve to positive integers, and the public port entry carries the resolved integer width; output entries may carry parser-validated reset_value/default_value non-negative integer literals when the output width is a resolved positive integer and the value fits that width; accepted clock-domain sources may include scalar domain ownership metadata on port entries; declared input/output roles survive ordinary and domain lowering even when unused or undriven, without invented drive values; source options are closed to width/type/domain and output-only reset/default; unknown names and malformed option shapes fail in default and strict modes';
}

sub isf_public_interface_actor_shell_transaction_shape {
    return 'transactions is an array of public transaction shell entries; each entry has unique non-empty scalar name, ports hash with inputs/outputs arrays whose entries carry resolved positive integer widths, clauses array, and optional scalar domain ownership metadata; same-transaction port width parameters, actor constants, actor-local scalar parameters, and qualified imported package scalar constants are accepted when they resolve to positive integers, while clause payload contents remain private scheduler input';
}

sub isf_public_interface_actor_shell_rule_shape {
    return 'rules is an array of public rule shell entries; each entry has unique non-empty scalar name, optional normalized when clause, actions array, and optional scalar domain ownership metadata; scalar or expression shorthand rule guards normalize into when while rule payload contents remain private scheduler input';
}

sub isf_public_interface_actor_shell_drive_shape {
    return 'drives is a hash of public drive shell entries keyed by unique non-empty drive name; each entry has unique scalar params and body arrays; body entries are scalar (port value) pairs while detailed drive semantics remain private scheduler input';
}

sub isf_public_interface_facade_failure_diagnostic_shape {
    return 'public facade boundary failures die with bounded scalar diagnostics before object creation, private parsing, or private lowering/reporting';
}

sub isf_public_interface_parse_file_return_shape {
    return 'scheduler-consumable actor hash reference with actor_shell_required_keys';
}

sub isf_public_interface_parse_source_return_shape {
    return 'scheduler-consumable actor hash reference with actor_shell_required_keys';
}

sub isf_public_interface_lower_return_shape {
    return 'hash reference with lower_result_presence_keys; files map is the bounded public lower-result surface';
}

sub isf_public_interface_report_return_shape {
    return 'JSON string encoding a schedule report with schedule_report_top_level_keys';
}

sub isf_public_interface_lower_result_presence_keys {
    return [
        qw(
            files
        ),
    ];
}

sub isf_public_interface_lower_result_file_name_shape {
    return '.fsm basename with no directory components';
}

sub isf_public_interface_lower_result_file_text_shape {
    return 'scheduled module, resolved ATL child module, generated ATL top, multi-domain domain scheduled module, or specialized library-child .fsm source text rooted at (?fsm:<basename-stem> ...) or generated top .fsm text rooted at (?top:<basename-stem> ...), optionally followed by embedded (?rtlif:...) interface declarations for explicit CDC children';
}

sub isf_public_interface_dt_assignment_operator_family_map {
    return {
        combinational => ['='],
        sequential    => ['<-', '<=', '<1'],
    };
}

sub isf_public_interface_dt_ordering_policy {
    return join(
        '',
        'deterministic_lowering_order: ',
        'transaction_and_rule_dt_blocks_keep_construction_order; ',
        'generated_rule_trigger_fanin_dt_blocks_follow_rule_dt_blocks_by_transaction_name; ',
        'hash_backed_drive_dt_blocks_are_sorted_lexically_by_drive_name',
    );
}

sub isf_public_interface_schedule_report_top_level_keys {
    return [
        qw(
            schema_version
            source
            scheduled_fsm
            clock
            reset
            reset_provenance
            interface_ports
            watchdog
            actor_phases
            actor_stages
            verification_observations
            verification_bridge
            actor_params
            actor_constants
            port_count
            inputs
            outputs
            state_count
            inferred_storage
            transactions
            transaction_waits
            transaction_loops
            loop_early_exits
            transaction_stages
            temporal_contracts
            bank_accesses
            transaction_port_bindings
            dt_blocks
            actor_network
            generated_composition
            library_uses
            compatible_fanin_groups
            priority_resolutions
            resource_arbitration
            compile_issues
            clock_domains
            crossings
        ),
    ];
}

sub isf_public_interface_schedule_report_compile_issues_success_shape {
    return 'array reference; empty when a successful schedule report has no nonfatal compile issues';
}

sub isf_public_interface_schedule_report_compile_issue_keys {
    return [
        qw(
            code
            severity
            target
            domain
            proof_status
            reason
            sources
        ),
    ];
}

sub isf_public_interface_schedule_report_compile_issue_source_keys {
    return [
        qw(
            owner
            owner_kind
            source_kind
            target
            operator
            rhs
            domain
        ),
    ];
}

sub isf_public_interface_schedule_report_bank_access_keys {
    return [
        qw(
            kind
            owner
            owner_kind
            container_kind
            container_name
            bank
            index
            width
            depth
            scalar_entries
            same_cycle_policy
            value
            target
        ),
    ];
}

sub isf_public_interface_schedule_report_bank_access_kind_values {
    return [
        qw(
            store
            load
        ),
    ];
}

sub isf_public_interface_schedule_report_bank_access_policy_values {
    return [
        qw(
            read_before_write
        ),
    ];
}

sub isf_public_interface_schedule_report_transaction_port_binding_keys {
    return [
        qw(
            site_kind
            owner
            owner_kind
            target_transaction
            role
            port
            actor_signal
            actor_expression
            actor_endpoint_kind
            binding_timing
            authored_timing_mode
            width
            instance
            parent_port
            child_port
            start_signal
            done_signal
            trigger_source
            payload_source
        ),
    ];
}

sub isf_public_interface_schedule_report_transaction_port_binding_actor_endpoint_kind_values {
    return [
        qw(
            signal
            literal
            expression
        ),
    ];
}

sub isf_public_interface_schedule_report_transaction_port_binding_timing_values {
    return [
        qw(
            activation_region
            generated_live_handoff
            trigger_payload
            done_guarded
        ),
    ];
}

sub isf_public_interface_schedule_report_transaction_port_binding_authored_timing_mode_values {
    return [
        qw(
            snapshot
            live
        ),
    ];
}

sub isf_public_interface_schedule_report_transaction_port_binding_site_kind_values {
    return [
        qw(
            do
            spawn
            rule_trigger
        ),
    ];
}

sub isf_public_interface_schedule_report_compile_issue_severity_values {
    return [
        qw(
            warning
        ),
    ];
}

sub isf_public_interface_schedule_report_compile_issue_proof_status_values {
    return [
        qw(
            not_doable
        ),
    ];
}

sub isf_public_interface_schedule_report_fanin_group_required_keys {
    return [
        qw(
            kind
            domain
            sources
        ),
    ];
}

sub isf_public_interface_schedule_report_fanin_group_optional_keys {
    return [
        qw(
            target
            target_transaction
            fanin_target
            operator
            rhs
        ),
    ];
}

sub isf_public_interface_schedule_report_fanin_group_kind_values {
    return [
        qw(
            same_target_value
            request
            pulse
            rule_trigger_fanin
        ),
    ];
}

sub isf_public_interface_schedule_report_priority_resolution_keys {
    return [
        qw(
            target
            winner
            winner_kind
            loser
            loser_kind
        ),
    ];
}

sub isf_public_interface_schedule_report_resource_arbitration_keys {
    return [
        qw(
            resource
            kind
            arbiter
            user
            user_kind
            members
            suppressed_by
        ),
    ];
}

sub isf_public_interface_schedule_report_generated_composition_required_keys {
    return [
        qw(
            kind
            top_module
            top_fsm
            parent
            children
            instances
        ),
    ];
}

sub isf_public_interface_schedule_report_generated_composition_kind_values {
    return [
        qw(
            activation_generated_top
            spawn_generated_top
        ),
    ];
}

sub isf_public_interface_schedule_report_generated_composition_parent_keys {
    return [
        qw(
            module
            scheduled_fsm
        ),
    ];
}

sub isf_public_interface_schedule_report_generated_composition_child_keys {
    return [
        qw(
            transaction
            module
            scheduled_fsm
            parameters
        ),
    ];
}

sub isf_public_interface_schedule_report_generated_composition_child_parameter_keys {
    return [
        qw(
            name
            default
        ),
    ];
}

sub isf_public_interface_schedule_report_generated_composition_instance_keys {
    return [
        qw(
            instance
            child
            activation_kind
            start
            done
            parameter_bindings
            drive_handoffs
        ),
    ];
}

sub isf_public_interface_schedule_report_generated_composition_link_keys {
    return [
        qw(
            parent_port
            child_port
        ),
    ];
}

sub isf_public_interface_schedule_report_generated_composition_binding_keys {
    return [
        qw(
            name
            source
            value
        ),
    ];
}

sub isf_public_interface_schedule_report_generated_composition_drive_handoff_keys {
    return [
        qw(
            drive
            request
            payloads
        ),
    ];
}

sub isf_public_interface_schedule_report_generated_composition_payload_keys {
    return [
        qw(
            parameter
            child_port
            parent_port
            width
        ),
    ];
}

sub isf_public_interface_schedule_report_library_use_keys {
    return [
        qw(
            library
            alias
            export
            kind
            instance
            module
            scheduled_fsm
            parameters
            bindings
        ),
    ];
}

sub isf_public_interface_schedule_report_library_use_parameter_keys {
    return [
        qw(
            name
            source
            value
        ),
    ];
}

sub isf_public_interface_schedule_report_library_use_binding_keys {
    return [
        qw(
            role
            library_name
            parent_name
            width
        ),
    ];
}

sub isf_public_interface_schedule_report_source_shape {
    return 'scheduled report source basename derived from the actor name with .isf suffix';
}

sub isf_public_interface_schedule_report_scheduled_fsm_shape {
    return 'scheduled .fsm basename for the current report scope; multi-domain reports use the generated <actor>_top.fsm artifact';
}

sub isf_public_interface_schedule_report_clock_shape {
    return 'scalar clock signal name from the ISF actor clock declaration, or the default-domain clock when clock_domains is present';
}

sub isf_public_interface_schedule_report_watchdog_shape {
    return 'scalar watchdog limit; omitted watchdog clauses default to 65535 (2^16 - 1), and actor-level actor constants, actor scalar parameters, or qualified imported package scalar constants report as resolved integers; await-local watchdog overrides do not change this actor-level report scalar';
}

sub isf_public_interface_schedule_report_actor_constant_keys {
    return [
        qw(
            name
            value
        ),
    ];
}

sub isf_public_interface_schedule_report_actor_phase_keys {
    return [
        qw(
            name
            body
        ),
    ];
}

sub isf_public_interface_schedule_report_actor_stage_keys {
    return [
        qw(
            name
            body
        ),
    ];
}

sub isf_public_interface_schedule_report_verification_observation_keys {
    return [
        qw(
            name
            role
            clock
            reset
            signals
        ),
    ];
}

sub isf_public_interface_schedule_report_verification_observation_signal_keys {
    return [
        qw(
            name
            direction
            width
        ),
    ];
}

sub isf_public_interface_schedule_report_verification_observation_role_values {
    return [
        qw(
            passive_monitor
        ),
    ];
}

sub isf_public_interface_schedule_report_verification_bridge_keys {
    return [qw(domain protocol transaction probes residues)];
}

sub isf_public_interface_schedule_report_verification_bridge_protocol_keys {
    return [qw(name profile revision role facts)];
}

sub isf_public_interface_schedule_report_verification_bridge_fact_keys {
    return [qw(name value)];
}

sub isf_public_interface_schedule_report_verification_bridge_transaction_keys {
    return [qw(name fields events)];
}

sub isf_public_interface_schedule_report_verification_bridge_field_keys {
    return [qw(name source direction phase_role)];
}

sub isf_public_interface_schedule_report_verification_bridge_source_keys {
    return [qw(kind name direction width signed)];
}

sub isf_public_interface_schedule_report_verification_bridge_event_keys {
    return [qw(name kind phase expression)];
}

sub isf_public_interface_schedule_report_verification_bridge_probe_keys {
    return [qw(name access source)];
}

sub isf_public_interface_schedule_report_actor_network_keys {
    return [
        qw(
            data_movements
            event_waits
            generated_tops
            groups
            association_schedules
            group_schedules
            kind
            instances
            transaction_triggers
        ),
    ];
}

sub isf_public_interface_schedule_report_actor_network_instance_keys {
    return [
        qw(
            name
            actor_type
            declaration
        ),
    ];
}

sub isf_public_interface_schedule_report_actor_network_resolved_instance_keys {
    return [
        @{isf_public_interface_schedule_report_actor_network_instance_keys()},
        qw(
            type_resolution
            library
            alias
            export
            module
            scheduled_fsm
        ),
    ];
}

sub isf_public_interface_schedule_report_actor_network_group_keys {
    return [
        qw(
            declaration
            members
            mode
            name
            scheduling
            source
        ),
    ];
}

sub isf_public_interface_schedule_report_actor_network_generated_top_keys {
    return [
        qw(
            child_module
            child_scheduled_fsm
            clock
            event
            event_child_port
            event_parent_port
            instance
            kind
            parent_module
            parent_scheduled_fsm
            reset
            target_transaction
            top_fsm
            top_module
            trigger_child_port
            trigger_parent_port
        ),
    ];
}

sub isf_public_interface_schedule_report_actor_network_generated_top_multi_child_keys {
    return [
        qw(
            children
            clock
            kind
            parent_module
            parent_scheduled_fsm
            reset
            top_fsm
            top_module
        ),
    ];
}

sub isf_public_interface_schedule_report_actor_network_generated_top_child_keys {
    return [
        qw(
            child_module
            child_scheduled_fsm
            event
            event_child_port
            event_parent_port
            instance
            target_transaction
            trigger_child_port
            trigger_parent_port
        ),
    ];
}

sub isf_public_interface_schedule_report_actor_network_group_schedule_keys {
    return [
        qw(
            context
            dependency_policy
            group
            members
            owner_transaction
            schedule
            signals
            sink
            source
            storage
            target_transactions
        ),
    ];
}

sub isf_public_interface_schedule_report_actor_network_association_schedule_keys {
    return [
        qw(
            association
            context
            dependency_policy
            kind
            lifetime
            members
            owner_transaction
            schedule
            signals
            sink
            source
            storage
            target_transactions
        ),
    ];
}

sub isf_public_interface_schedule_report_actor_network_data_movement_keys {
    return [
        qw(
            context
            drive
            kind
            route_lifetime
            sink
            sink_endpoint
            sink_instance
            sink_signal
            source
            source_endpoint
            source_instance
            source_signal
            storage
            transaction
            width
            width_source
        ),
    ];
}

sub isf_public_interface_schedule_report_actor_network_event_wait_keys {
    return [
        qw(
            context
            event
            instance
            signal
            source
            transaction
        ),
    ];
}

sub isf_public_interface_schedule_report_actor_network_transaction_trigger_keys {
    return [
        qw(
            context
            instance
            owner_transaction
            signal
            sink
            target_transaction
        ),
    ];
}

sub isf_public_interface_schedule_report_actor_param_keys {
    return [
        qw(
            name
            value
        ),
    ];
}

sub isf_public_interface_schedule_report_clock_domain_keys {
    return [
        qw(
            name
            default
            clock
            reset
            scheduled_fsm
            ports
            storage
            transactions
            rules
            library_uses
            child_instances
            crossings
            state_count
            dt_block_count
            inferred_storage
            interface_ports
        ),
    ];
}

sub isf_public_interface_schedule_report_clock_domain_child_instance_keys {
    return [
        qw(
            kind
            owner
            child
            instance
        ),
    ];
}

sub isf_public_interface_schedule_report_clock_domain_crossing_endpoint_keys {
    return [
        qw(
            event
            role
            signal
            ready
        ),
    ];
}

sub isf_public_interface_schedule_report_crossing_keys {
    return [
        qw(
            name
            kind
            source_domain
            source_signal
            destination_domain
            destination_signal
            ready_signal
            instance
            module
            outstanding_policy
            payload
            top_fsm
        ),
    ];
}

sub isf_public_interface_schedule_report_multi_file_scope {
    return 'single-clock multi-file report transaction/state/dt/storage summaries describe the parent module; actor_network summarizes static ATL actor declarations from verbose instances or compact instance aliases, resolved library-qualified type metadata and child artifact names, report-only group metadata from verbose groups or compact concurrent aliases, selected parent-handoff event waits, transaction triggers, temporary trigger batches, scalar or exact-width vector data movements, and selected generated ATL tops without embedding child reports or HDL event wiring; the bounded generated-child actor-to-actor route set reports each same-source same-sink scalar or same-width vector route through data_movements[] and its generated top through generated_tops[]; generated_composition summarizes generated top, child files, spawned instances, handoffs, and bindings; library_uses summarizes resolved reusable library actor instances and their child scheduled .fsm artifacts; multi-domain reports describe the generated top at the top level and expose per-domain scheduled artifacts plus crossing metadata through clock_domains and crossings; each realized clock_domains entry carries inferred_storage using the same normalized storage entry schema as a single-clock report, preserving domain ownership while top-level inferred_storage stays empty; child and domain scheduled .fsm text remains available through lower_result files';
}

sub isf_public_interface_schedule_report_interface_count_shape {
    return 'non-negative integer counts: single-clock reports count interface ports by direction; multi-domain reports count generated-top public ports including domain clocks/resets and actor interface ports; port_count equals inputs plus outputs';
}

sub isf_public_interface_schedule_report_state_count_shape {
    return 'non-negative integer count of scheduled .fsm state blocks in the current report scope; multi-domain generated-top reports use zero and expose domain-local counts in clock_domains entries';
}

sub isf_public_interface_schedule_report_reset_keys {
    return [
        qw(
            name
            kind
            polarity
        ),
    ];
}

sub isf_public_interface_schedule_report_reset_shape {
    return 'hash reference with schedule_report_reset_keys for configured or defaulted legacy single-clock reset; null only when the selected default clock-domain reset is omitted';
}

sub isf_public_interface_schedule_report_reset_kind_values {
    return [
        qw(
            async
            sync
        ),
    ];
}

sub isf_public_interface_schedule_report_reset_polarity_values {
    return [
        qw(
            active_high
            active_low
        ),
    ];
}

sub isf_public_interface_schedule_report_storage_required_keys {
    return [
        qw(
            name
            kind
        ),
    ];
}

sub isf_public_interface_schedule_report_storage_optional_keys {
    return [
        qw(
            role
            type
            type_kind
            width
            fields
            access
        ),
    ];
}

sub isf_public_interface_schedule_report_storage_kind_values {
    return [
        qw(
            counter
            register
        ),
    ];
}

sub isf_public_interface_schedule_report_storage_role_values {
    return [
        qw(
            activation_done_handoff
            activation_start_handoff
            atl_trigger_start_handoff
            child_completion_output_handoff
            child_completion_seen
            child_completion_view
            completion_pulse
            data_register
            dynamic_wait_counter
            drive_payload
            drive_request
            extract_field
            latency_counter
            local_completion_pulse
            repeat_counter
            resource_round_robin_pointer
            rule_trigger_payload_source
            rule_trigger_source
            sample_alias
            scheduler_error_status
            temporal_contract_monitor
            transaction_port
            transaction_port_binding
            trigger_done_observe
            watchdog_counter
            actor_storage
        ),
    ];
}

sub isf_public_interface_schedule_report_storage_width_shape {
    return 'positive integer bit width when present; currently present for declared actor-owned storage, inferred scheduler counters, and register storage with known ISF width evidence; declared typed actor-owned storage may also expose authored type and resolved type_kind without exposing raw type-spec hashes; declared scalar actor-owned storage may expose optional fields[] metadata entries with name, msb, lsb, width, and optional access, reset, and enum metadata; optional word access is independent of fields and uses ro, rw, wo, w1c, w0c, rc, rs, warl, wpri, or reserved without enforcing an RTL policy';
}

sub isf_public_interface_schedule_report_transaction_keys {
    return [
        qw(
            name
            states
            count
        ),
    ];
}

sub isf_public_interface_schedule_report_transaction_states_shape {
    return 'array reference of scheduled state names belonging to the transaction in emitted order';
}

sub isf_public_interface_schedule_report_transaction_count_shape {
    return 'non-negative integer count equal to the transaction states array length';
}

sub isf_public_interface_schedule_report_transaction_ordering {
    return 'transaction summaries are sorted lexically by transaction name; each states array keeps scheduled .fsm state emission order';
}

sub isf_public_interface_schedule_report_transaction_wait_keys {
    return [
        qw(
            transaction
            cycles
            count_kind
            count_source
            entry_state
            exit_state
            counter_signal
            counter_width
        ),
    ];
}

sub isf_public_interface_schedule_report_transaction_wait_count_kind_values {
    return [
        qw(
            static
            runtime_scalar
            runtime_expression
        ),
    ];
}

sub isf_public_interface_schedule_report_transaction_loop_keys {
    return [
        qw(
            transaction
            kind
            condition
            entry_state
            decision_states
            body_start
            body_states
            exit_state
            body_clause_count
        ),
    ];
}

sub isf_public_interface_schedule_report_transaction_stage_keys {
    return [
        qw(
            transaction
            name
            kind
            state
            ready
            valid
        ),
    ];
}

sub isf_public_interface_schedule_report_transaction_stage_kind_values {
    return [
        qw(
            ready_valid_barrier
        ),
    ];
}

sub isf_public_interface_schedule_report_temporal_contract_keys {
    return [
        qw(
            transaction
            name
            kind
            trigger
            signal
            within_cycles
            pending_signal
            counter_signal
            fail_signal
            overlap_policy
            reset_policy
            assertion_projection
        ),
    ];
}

sub isf_public_interface_schedule_report_temporal_contract_kind_values {
    return [
        qw(
            bounded_eventually
        ),
    ];
}

sub isf_public_interface_schedule_report_temporal_contract_overlap_policy_values {
    return [
        qw(
            fail
        ),
    ];
}

sub isf_public_interface_schedule_report_temporal_contract_assertion_projection_values {
    return [
        qw(
            systemverilog_sticky_fail
        ),
    ];
}

sub isf_public_interface_schedule_report_temporal_contract_reset_policy_shape {
    return 'same bounded shape as top-level reset summary when reset is configured or defaulted; null only when the selected default clock-domain reset is omitted';
}

sub isf_public_interface_schedule_report_dt_keys {
    return [
        qw(
            name
            kind
            assignments
        ),
    ];
}

sub isf_public_interface_schedule_report_dt_kind_values {
    return [
        qw(
            actor_storage_read_handoff
            actor_storage_write_handoff
            child_completion
            child_completion_output
            drive
            do_port_binding
            latency_counter
            rule
            rule_trigger_fanin
            spawn_port_binding
            temporal_contract_monitor
            trigger_generated_activation
        ),
    ];
}

sub isf_public_interface_schedule_report_dt_assignments_shape {
    return 'non-negative integer count of assignments in the matching scheduled .fsm DT block; not an assignment payload list';
}

sub isf_public_interface_schedule_report_presence_key_family_map {
    return {
        schedule_report_top_level_keys => isf_public_interface_schedule_report_top_level_keys(),
        schedule_report_reset_keys => isf_public_interface_schedule_report_reset_keys(),
        schedule_report_actor_phase_keys => isf_public_interface_schedule_report_actor_phase_keys(),
        schedule_report_actor_stage_keys => isf_public_interface_schedule_report_actor_stage_keys(),
        schedule_report_verification_observation_keys => isf_public_interface_schedule_report_verification_observation_keys(),
        schedule_report_verification_observation_signal_keys => isf_public_interface_schedule_report_verification_observation_signal_keys(),
        schedule_report_verification_bridge_keys => isf_public_interface_schedule_report_verification_bridge_keys(),
        schedule_report_verification_bridge_protocol_keys => isf_public_interface_schedule_report_verification_bridge_protocol_keys(),
        schedule_report_verification_bridge_fact_keys => isf_public_interface_schedule_report_verification_bridge_fact_keys(),
        schedule_report_verification_bridge_transaction_keys => isf_public_interface_schedule_report_verification_bridge_transaction_keys(),
        schedule_report_verification_bridge_field_keys => isf_public_interface_schedule_report_verification_bridge_field_keys(),
        schedule_report_verification_bridge_source_keys => isf_public_interface_schedule_report_verification_bridge_source_keys(),
        schedule_report_verification_bridge_event_keys => isf_public_interface_schedule_report_verification_bridge_event_keys(),
        schedule_report_verification_bridge_probe_keys => isf_public_interface_schedule_report_verification_bridge_probe_keys(),
        schedule_report_actor_network_keys => isf_public_interface_schedule_report_actor_network_keys(),
        schedule_report_actor_network_instance_keys => isf_public_interface_schedule_report_actor_network_instance_keys(),
        schedule_report_actor_network_resolved_instance_keys => isf_public_interface_schedule_report_actor_network_resolved_instance_keys(),
        schedule_report_actor_network_group_keys => isf_public_interface_schedule_report_actor_network_group_keys(),
        schedule_report_actor_network_generated_top_keys => isf_public_interface_schedule_report_actor_network_generated_top_keys(),
        schedule_report_actor_network_generated_top_multi_child_keys => isf_public_interface_schedule_report_actor_network_generated_top_multi_child_keys(),
        schedule_report_actor_network_generated_top_child_keys => isf_public_interface_schedule_report_actor_network_generated_top_child_keys(),
        schedule_report_actor_network_group_schedule_keys => isf_public_interface_schedule_report_actor_network_group_schedule_keys(),
        schedule_report_actor_network_association_schedule_keys => isf_public_interface_schedule_report_actor_network_association_schedule_keys(),
        schedule_report_actor_network_data_movement_keys => isf_public_interface_schedule_report_actor_network_data_movement_keys(),
        schedule_report_actor_network_event_wait_keys => isf_public_interface_schedule_report_actor_network_event_wait_keys(),
        schedule_report_actor_network_transaction_trigger_keys => isf_public_interface_schedule_report_actor_network_transaction_trigger_keys(),
        schedule_report_actor_param_keys => isf_public_interface_schedule_report_actor_param_keys(),
        schedule_report_actor_constant_keys => isf_public_interface_schedule_report_actor_constant_keys(),
        schedule_report_clock_domain_keys => isf_public_interface_schedule_report_clock_domain_keys(),
        schedule_report_clock_domain_child_instance_keys => isf_public_interface_schedule_report_clock_domain_child_instance_keys(),
        schedule_report_clock_domain_crossing_endpoint_keys => isf_public_interface_schedule_report_clock_domain_crossing_endpoint_keys(),
        schedule_report_crossing_keys => isf_public_interface_schedule_report_crossing_keys(),
        schedule_report_storage_required_keys => isf_public_interface_schedule_report_storage_required_keys(),
        schedule_report_storage_optional_keys => isf_public_interface_schedule_report_storage_optional_keys(),
        schedule_report_bank_access_keys => isf_public_interface_schedule_report_bank_access_keys(),
        schedule_report_transaction_port_binding_keys => isf_public_interface_schedule_report_transaction_port_binding_keys(),
        schedule_report_transaction_keys => isf_public_interface_schedule_report_transaction_keys(),
        schedule_report_transaction_loop_keys => isf_public_interface_schedule_report_transaction_loop_keys(),
        schedule_report_transaction_wait_keys => isf_public_interface_schedule_report_transaction_wait_keys(),
        schedule_report_transaction_stage_keys => isf_public_interface_schedule_report_transaction_stage_keys(),
        schedule_report_temporal_contract_keys => isf_public_interface_schedule_report_temporal_contract_keys(),
        schedule_report_dt_keys => isf_public_interface_schedule_report_dt_keys(),
        schedule_report_compile_issue_keys => isf_public_interface_schedule_report_compile_issue_keys(),
        schedule_report_compile_issue_source_keys => isf_public_interface_schedule_report_compile_issue_source_keys(),
        schedule_report_fanin_group_required_keys => isf_public_interface_schedule_report_fanin_group_required_keys(),
        schedule_report_fanin_group_optional_keys => isf_public_interface_schedule_report_fanin_group_optional_keys(),
        schedule_report_priority_resolution_keys => isf_public_interface_schedule_report_priority_resolution_keys(),
        schedule_report_resource_arbitration_keys => isf_public_interface_schedule_report_resource_arbitration_keys(),
        schedule_report_generated_composition_required_keys => isf_public_interface_schedule_report_generated_composition_required_keys(),
        schedule_report_generated_composition_parent_keys => isf_public_interface_schedule_report_generated_composition_parent_keys(),
        schedule_report_generated_composition_child_keys => isf_public_interface_schedule_report_generated_composition_child_keys(),
        schedule_report_generated_composition_child_parameter_keys => isf_public_interface_schedule_report_generated_composition_child_parameter_keys(),
        schedule_report_generated_composition_instance_keys => isf_public_interface_schedule_report_generated_composition_instance_keys(),
        schedule_report_generated_composition_link_keys => isf_public_interface_schedule_report_generated_composition_link_keys(),
        schedule_report_generated_composition_binding_keys => isf_public_interface_schedule_report_generated_composition_binding_keys(),
        schedule_report_generated_composition_drive_handoff_keys => isf_public_interface_schedule_report_generated_composition_drive_handoff_keys(),
        schedule_report_generated_composition_payload_keys => isf_public_interface_schedule_report_generated_composition_payload_keys(),
        schedule_report_library_use_keys => isf_public_interface_schedule_report_library_use_keys(),
        schedule_report_library_use_parameter_keys => isf_public_interface_schedule_report_library_use_parameter_keys(),
        schedule_report_library_use_binding_keys => isf_public_interface_schedule_report_library_use_binding_keys(),
    };
}

sub isf_public_interface_live_document_paths {
    return [
        qw(
            docs/ISF_DOWNSTREAM_INTEGRATION_SPEC.md
            docs/DOWNSTREAM_ISSUE_REPORTING.md
            docs/ISF_PUBLIC_INTERFACE_CONTRACT.md
            docs/ISF_SPEC.md
            docs/ISF_LIBRARY_CATALOG.md
            docs/book/src/13-intent-scheduling.md
            docs/book/src/13a-actor-interface.md
            docs/book/src/13b-transactions.md
            docs/book/src/13c-drive-blocks.md
            docs/book/src/13d-control-flow.md
            docs/book/src/13e-data-manipulation.md
            docs/book/src/13f-composition.md
            docs/book/src/13g-rules.md
            docs/book/src/13h-lowering-reference.md
            docs/book/src/13i-downstream-integration.md
            docs/book/src/13j-type-enum-aggregate.md
            docs/book/src/13k-isf-feature-support-matrix.md
            docs/book/src/13l-procedures.md
            docs/book/src/13m-local-variables.md
            docs/book/src/14-feature-backlog.md
            docs/book/src/90-reference-map.md
        ),
    ];
}

1;
