package FSM::Scheduler::ISF::Emitter::FSM;

use v5.20;
use strict;
use warnings;
use feature qw(signatures postderef);
no warnings 'experimental::signatures';
use FSM::Debug;

# Emits .fsm source text from LoweringIR.
# Pure emitter — no logic, just walks the IR and produces strings.

sub new($class, %args) { bless {}, $class }

sub emit($self, $ir) {
    fsm_trace_enter('Emitter::FSM emit', 2);

    $self->{reduction_samples} = _reduction_sample_declarations($ir);

    $self->{outputs} = { map { $_->{name} => 1 } grep { $_->{direction} eq 'output' } @{$ir->{ports}} };

    my @lines;

    push @lines, $self->_emit_header($ir);
    push @lines, '';
    if (@{$ir->{package_imports} || []}) {
        push @lines, $self->_emit_imports($ir);
        push @lines, '';
    }
    if (@{$ir->{enum_declarations} || []}) {
        push @lines, $self->_emit_enums($ir);
        push @lines, '';
    }
    if (@{$ir->{type_declarations} || []}) {
        push @lines, $self->_emit_types($ir);
        push @lines, '';
    }
    if (@{$ir->{constants} || []}) {
        push @lines, $self->_emit_constants($ir);
        push @lines, '';
    }
    if (@{$ir->{params} || []}) {
        push @lines, $self->_emit_params($ir);
        push @lines, '';
    }
    push @lines, $self->_emit_system($ir);
    push @lines, '';
    if (@{$ir->{explicit_interface_ports} || []} || @{$ir->{explicit_internal_signals} || []}
        || keys %{$self->{reduction_samples}}) {
        push @lines, $self->_emit_interface($ir);
        push @lines, '';
    }
    if (my $size_block = $self->_emit_size($ir)) {
        push @lines, $size_block;
        push @lines, '';
    }
    if (my $assert_block = $self->_emit_asserts($ir)) {
        push @lines, $assert_block;
        push @lines, '';
    }
    push @lines, $self->_emit_states($ir, $self->{outputs});
    push @lines, $self->_emit_dt_blocks($ir, $self->{outputs});
    push @lines, ')';
    if (@{$ir->{package_roots} || []}) {
        push @lines, '';
        push @lines, map { _format_param_value($_) } @{$ir->{package_roots}};
    }

    my $out = join("\n", @lines) . "\n";
    fsm_trace_exit('Emitter::FSM emit', 2);
    return $out;
}

sub _emit_header($self, $ir) {
    return "(?fsm:$ir->{actor_name}";
}

sub _emit_imports($self, $ir) {
    my @l;
    push @l, '  (+import';
    for my $package_name (@{$ir->{package_imports} || []}) {
        push @l, "    $package_name";
    }
    push @l, '  )';
    return join("\n", @l);
}

sub _emit_enums($self, $ir) {
    my @l;
    push @l, '  (+enums';
    for my $entry (@{$ir->{enum_declarations} || []}) {
        push @l, '    ' . _format_param_value($entry);
    }
    push @l, '  )';
    return join("\n", @l);
}

sub _emit_types($self, $ir) {
    my @l;
    push @l, '  (+types';
    for my $entry (@{$ir->{type_declarations} || []}) {
        push @l, '    ' . _format_param_value($entry);
    }
    push @l, '  )';
    return join("\n", @l);
}

sub _emit_constants($self, $ir) {
    my @l;
    push @l, '  (+constants';
    for my $constant (@{$ir->{constants} || []}) {
        push @l, "    ($constant->{name} " . _format_param_value($constant->{value}) . ")";
    }
    push @l, '  )';
    return join("\n", @l);
}

sub _emit_params($self, $ir) {
    my @l;
    push @l, '  (+params';
    for my $param (@{$ir->{params} || []}) {
        push @l, "    ($param->{name} " . _format_param_value($param->{value}) . ")";
    }
    push @l, '  )';
    return join("\n", @l);
}

sub _emit_system($self, $ir) {
    my @l;
    push @l, '  (+system';
    push @l, "    (clock $ir->{clock})";
    my $r = $ir->{reset};
    if ($r) {
        my $async = $r->{kind} eq 'async';
        my $keyword = $async ? 'areset' : 'sreset';
        my $default_polarity = $async ? 'active_low' : 'active_high';
        my $polarity = $r->{polarity} // $default_polarity;
        # Keep already strict-supported carriers unchanged. The FSM grammar's
        # legacy name convention differs from ISF's _n/_b inference, so an
        # explicit level is also needed when the name disagrees with it.
        my $name_looks_low = $r->{name} =~ /n\z/i;
        my $legacy_name_matches = $async ? $name_looks_low : !$name_looks_low;
        my $modifier = $polarity eq $default_polarity && $legacy_name_matches
            ? '' : " $polarity";
        push @l, "    ($keyword $r->{name}$modifier)";
    }
    push @l, '  )';
    return join("\n", @l);
}

sub _emit_interface($self, $ir) {
    my @l;
    push @l, '  (+interface';
    for my $port (@{$ir->{explicit_interface_ports} || []}) {
        my $direction = $port->{direction};
        next unless defined($direction) && ($direction eq 'input' || $direction eq 'output');
        push @l, "    ($direction $port->{name})";
    }
    for my $name (@{$ir->{explicit_internal_signals} || []}) {
        push @l, "    (internal $name)";
    }
    push @l, map { "    (internal $_)" } sort keys %{$self->{reduction_samples}};
    push @l, '  )';
    return join("\n", @l);
}

sub _emit_size($self, $ir) {
    my @l;
    my %declared;
    my $type_refs = $ir->{signal_type_refs} || {};
    # ISF-REGISTER-RESET-VALUES: an opt-in per-register hardware reset value, emitted in
    # `+size` as `(name width (reset V))` (the carrier the core `.fsm` parser consumes).
    my $resets = $ir->{reset_values} || {};
    for my $p (@{$ir->{ports}}) {
        $declared{$p->{name}} = 1;
        my $width_token = $p->{type} // $type_refs->{$p->{name}} // $p->{width};
        push @l, "    ($p->{name} $width_token" . _reset_suffix($resets, $p->{name}) . ")";
    }
    for my $storage (@{$ir->{declared_storage} || []}) {
        for my $signal (@{$storage->{signals} || []}) {
            my $name = $signal->{name};
            next if $declared{$name};
            $declared{$name} = 1;
            my $width_token = $signal->{type} // $type_refs->{$name} // $signal->{width};
            push @l, "    ($name $width_token" . _reset_suffix($resets, $name) . ")";
        }
    }
    my $ctrs = $ir->{counters} || {};
    for my $name (sort keys %$ctrs) {
        next if $declared{$name};
        $declared{$name} = 1;
        my $width_token = $type_refs->{$name} // $ctrs->{$name};
        push @l, "    ($name $width_token" . _reset_suffix($resets, $name) . ")";
    }
    for my $name (sort keys %{$self->{reduction_samples}}) {
        next if $declared{$name};
        $declared{$name} = 1;
        push @l, "    ($name $self->{reduction_samples}{$name})";
    }
    # Preserve the known widths of an assembled scalar and its operands.
    # Otherwise concat may infer a list or implicitly scalar input parts.
    my $widths = $ir->{signal_widths} || {};
    my %static = map { $_->{name} => 1 }
        (@{$ir->{constants} || []}, @{$ir->{params} || []});
    for my $state (@{$ir->{states} || []}) {
        for my $name (@{$state->{assembly_signals} || []}) {
            next unless $name =~ /\A[A-Za-z_][A-Za-z0-9_]*\z/;
            next if $declared{$name} || $static{$name};
            next unless defined($widths->{$name}) && $widths->{$name} > 0;
            $declared{$name} = 1;
            my $width_token = $type_refs->{$name} // $widths->{$name};
            push @l, "    ($name $width_token" . _reset_suffix($resets, $name) . ")";
        }
    }
    return '' unless @l;
    return join("\n", '  (+size', @l, '  )');
}

# A scalar source sample is an explicit private declaration. Preserve its known
# width/type before the shared frontend parses a reduction using that alias.
# Restrict this additional carrier evidence to actors using the new feature;
# ordinary legacy inferred samples retain their current carrier contract.
sub _reduction_sample_declarations {
    my ($ir) = @_;
    return {} unless ref($ir->{reductions}) eq 'ARRAY' && @{$ir->{reductions}};
    my %declared = map {$_->{name} => 1} @{$ir->{ports} || []};
    $declared{$_} = 1 for keys %{$ir->{counters} || {}}, @{$ir->{explicit_internal_signals} || []};
    my %aggregate;
    for my $storage (@{$ir->{declared_storage} || []}) {
        for my $signal (@{$storage->{signals} || []}) {
            $declared{$signal->{name}} = 1;
            my $kind = ($signal->{type_spec} || {})->{kind} // '';
            $aggregate{$signal->{name}} = 1 if $kind eq 'record' || $kind eq 'list';
        }
    }
    my $widths = $ir->{signal_widths} || {};
    my $types = $ir->{signal_type_refs} || {};
    my %samples;
    for my $block (@{$ir->{states} || []}, @{$ir->{dt_blocks} || []}) {
        for my $assignment (@{$block->{assignments} || []}) {
            next unless ($assignment->{source_kind} // '') eq 'sample_capture';
            my ($name, $source) = @{$assignment}{qw(lhs rhs)};
            next unless defined($name) && $name =~ /\A[A-Za-z_]\w*\z/ && !$declared{$name};
            next unless defined($widths->{$name}) && $widths->{$name} > 0;
            # Whole packed-storage captures (and their sample chains) retain
            # the legacy inference owner. They are not declared scalar facts
            # supplied by the reduction feature. Follow captures in IR order,
            # just as sample width inference follows source clause order.
            if ($aggregate{$source}) {
                $aggregate{$name} = 1;
                delete $samples{$name};
                next;
            }
            delete $aggregate{$name};
            # A named scalar type retains signedness/state semantics. Numeric
            # width is used only where the original declaration is width-only.
            $samples{$name} = $types->{$name} // $types->{$source} // $widths->{$name};
        }
    }
    return \%samples;
}

# `(reset V)` marker for a register with an opt-in hardware reset value; empty otherwise.
sub _reset_suffix($resets, $name) {
    return (defined $resets->{$name}) ? " (reset $resets->{$name})" : '';
}

# ISF-ASSERT / ISF-COVER-ASSUME: emit the `+assert` carrier so `(assert|cover|assume COND
# [message])` survives ISF -> `.fsm`. Each entry is `(name kind COND ["message"])`; KIND is
# emitted always (so the parser is unambiguous), COND is already rendered `.fsm` text. Empty
# string when there are no checks (caller skips the section).
sub _emit_asserts($self, $ir) {
    my $asserts = $ir->{immediate_assertions} || [];
    return '' unless @$asserts;
    my @l = ('  (+assert');
    for my $a (@$asserts) {
        my $kind = $a->{kind} // 'assert';
        my $line = "    ($a->{name} $kind $a->{condition}";
        if (defined $a->{message} && length $a->{message}) {
            my $msg = $a->{message};
            $msg =~ s/\\/\\\\/g;
            $msg =~ s/"/\\"/g;
            $line .= " \"$msg\"";
        }
        $line .= ')';
        push @l, $line;
    }
    push @l, '  )';
    return join("\n", @l);
}

sub _emit_states($self, $ir, $outputs) {
    my @lines;
    for my $s (@{$ir->{states}}) {
        my @body = ($self->_emit_assignments($s), $self->_emit_transitions($s));
        # A passive terminal state holds, but an empty state body is not a
        # legal carrier form. Express that hold without inventing completion,
        # returning to entry, or changing the source lowering graph.
        push @body, $self->_emit_simple_transition({target => $s->{name}}) unless @body;
        push @lines, "  ($s->{name}";
        push @lines, @body;
        push @lines, '  )';
        push @lines, '';
    }
    return @lines;
}

sub _emit_assignments($self, $state) {
    my @lines;

    for my $a (@{$state->{assignments}}) {
        my $guard_str = _format_guard_suffix($a->{guard});
        my $op = $a->{op};
        my $lhs = $self->_lhs_token($a->{lhs});
        if ($op eq '=') {
            push @lines, "    (= ($lhs $a->{rhs})$guard_str)";
        } elsif ($op eq '<-') {
            push @lines, "    (<- ($lhs $a->{rhs})$guard_str)";
        } elsif ($op eq '<=') {
            push @lines, "    (<= ($lhs $a->{rhs})$guard_str)";
        } elsif ($op eq '--') {
            push @lines, "    (-- $a->{lhs})";
        } else {
            push @lines, "    ($op ($lhs $a->{rhs})$guard_str)";
        }
    }
    if ($state->{fields}) {
        for my $f (@{$state->{fields}}) {
            push @lines, "    (<= ($f (slice $state->{word} $f HIGH $f LOW)))";
        }
    }
    return @lines;
}

sub _emit_transitions($self, $state) {
    my @lines;
    my $txs = $state->{transitions};

    if ($state->{kind} eq 'repeat_check') {
        # Decision tree: (=0 -> exit), (!=0 -> loop)
        my @counter_transitions = grep {
            $_->{condition}
                && $_->{condition}{signal}
                && $_->{condition}{signal} eq $state->{counter}
        } @$txs;
        my @other_transitions = grep {
            !($_->{condition}
                && $_->{condition}{signal}
                && $_->{condition}{signal} eq $state->{counter})
        } @$txs;

        if (@counter_transitions) {
            push @lines, "    (?$state->{counter}";
        }
        for my $t (@counter_transitions) {
            my $c = $t->{condition};
            if ($c->{op} eq '!=') {
                # ISF-COUNTED-REPEAT-TERMINATION: the continue edge is "counter nonzero".
                # Emit it as `(!=0 …)` (a `!= 0` test): the SV emitter renders `counter
                # != 0` as the reduction `(|counter)` — a clean, width-correct nonzero test.
                # (Emitting `(=1 …)` would mean "== 1" — wrong for a multi-bit counter still
                # counting down; emitting `(>0 …)` is correct but renders `counter > 1'b0`,
                # a WIDTHEXPAND lint that fails `--verify-hdl`.)
                push @lines, "      (!=0 (-> $t->{target}))";
            } else {
                push @lines, "      (=0 (-> $t->{target}))";
            }
        }
        push @lines, '    )' if @counter_transitions;
        for my $t (@other_transitions) {
            push @lines, $self->_emit_simple_transition($t);
        }
        return @lines;
    }

    if ($state->{kind} eq 'await') {
        # Await has both guard transition and watchdog timeout
        my %seen;
        for my $t (@$txs) {
            my $c = $t->{condition};
            if ($c->{port} && !$c->{op}) {
                # Guard transition: (<port (-> target))
                push @lines, "    (<$c->{port}";
                push @lines, "      (-> $t->{target})";
                push @lines, '    )';
            } elsif ($c->{expr}) {
                push @lines, $self->_emit_simple_transition($t);
            } elsif ($c->{signal}) {
                # Watchdog: zero test and nonzero decrement both read current Q.
                push @lines, "    (?$c->{signal}";
                push @lines, "      (=0 (-> $t->{target}))";
                push @lines, "      (>0 (-- $c->{signal}))";
                push @lines, '    )';
            }
        }
        return @lines;
    }

    # Sync transitions: await_all / await_any
    if ($state->{kind} eq 'sync_all') {
        return map { $self->_emit_simple_transition($_) } @$txs
            if grep { $_->{condition} } @$txs;

        my @ports = @{$state->{completion_ports} // $state->{done_ports}};
        my $target = $txs->[0]{target};
        if (!@ports) {
            push @lines, "    (-> $target)";
        } elsif (@ports == 1) {
            push @lines, "    (-> $target <$ports[0])";
        } else {
            push @lines, "    (-> $target <(& " . join(' ', @ports) . '))';
        }
        return @lines;
    }
    if ($state->{kind} eq 'sync_any') {
        return map { $self->_emit_simple_transition($_) } @$txs
            if grep { $_->{condition} } @$txs;

        my $target = $txs->[0]{target};
        my @ports = @{$state->{completion_ports} // $state->{done_ports}};
        for my $p (@ports) {
            push @lines, "    (<$p";
            push @lines, "      (-> $target)";
            push @lines, '    )';
        }
        push @lines, "    (-> $target)" unless @ports;
        return @lines;
    }

    # Switch transition: (?signal (=val (-> body)) ...)
    if ($state->{kind} eq 'switch') {
        return map { $self->_emit_simple_transition($_) } @$txs
            if $state->{switch_transitions_materialized};

        push @lines, "    (" . _format_switch_test_selector($state->{signal});
        for my $br (@{$state->{branches}}) {
            my $selector = _is_default_selector($br->{value}) ? 'default' : "=$br->{value}";
            push @lines, "      ($selector (-> $br->{body_start}))";
        }
        for my $t (@$txs) {
            push @lines, "      (default (-> $t->{target}))" if !$t->{condition};
        }
        push @lines, '    )';
        return @lines;
    }

    # Branch transition: ?condition (=1 -> body) (=0 -> skip)
    if ($state->{kind} eq 'branch') {
        return map { $self->_emit_simple_transition($_) } @$txs
            if grep { $_->{condition} } @$txs;

        my $cond = $state->{condition};
        push @lines, "    (" . _format_condition_selector($cond);
        push @lines, "      (=1 (-> $state->{true_target}))" if $state->{true_target};
        # =0: skip to next top-level state
        for my $t (@$txs) {
            push @lines, "      (=0 (-> $t->{target}))" if !$t->{condition};
        }
        push @lines, '    )';
        return @lines;
    }

    if ($state->{kind} eq 'loop_while' || $state->{kind} eq 'loop_until'
        || $state->{kind} eq 'loop_exit_when') {
        return map { $self->_emit_simple_transition($_) } @$txs
            if $state->{loop_transitions_materialized};

        my $cond = $state->{condition};
        push @lines, "    (" . _format_condition_selector($cond);
        for my $t (@$txs) {
            my $branch = $t->{condition}{loop_branch};
            push @lines, "      (=$branch (-> $t->{target}))" if defined $branch;
        }
        push @lines, '    )';
        return @lines;
    }

    # Simple transitions
    for my $t (@$txs) {
        push @lines, $self->_emit_simple_transition($t);
    }
    return @lines;
}

sub _emit_simple_transition($self, $transition) {
    my @lines;
    if ($transition->{condition} && _guard_value_present($transition->{condition}{port})) {
        push @lines, "    (" . _format_guard_predicate($transition->{condition}{port});
        push @lines, "      (-> $transition->{target})";
        push @lines, '    )';
    } elsif ($transition->{condition} && _guard_value_present($transition->{condition}{expr})) {
        push @lines, "    (-> $transition->{target} "
            . _format_guard_predicate($transition->{condition}{expr}) . ")";
    } elsif ($transition->{condition} && _guard_value_present($transition->{condition}{signal})) {
        my $c = $transition->{condition};
        my $op = $c->{op} // '=';
        $op = '=' if $op eq '==';
        push @lines, "    (?$c->{signal}";
        push @lines, "      ($op$c->{value} (-> $transition->{target}))";
        push @lines, '    )';
    } else {
        push @lines, "    (-> $transition->{target})";
    }
    return @lines;
}

sub _emit_dt_blocks($self, $ir, $outputs) {
    my @lines;
    for my $dt (@{$ir->{dt_blocks}}) {
        push @lines, "  (-$dt->{name}" . _format_guard_suffix($dt->{dte_guard});
        push @lines,
            $dt->{kind} eq 'rule'
                ? $self->_emit_rule_dt_assignments($dt)
                : $self->_emit_plain_dt_assignments($dt);
        push @lines, '  )';
        push @lines, '';
    }
    return @lines;
}

sub _emit_plain_dt_assignments($self, $dt) {
    return map { $self->_format_dt_assignment($_, 4) } @{$dt->{assignments}};
}

sub _emit_rule_dt_assignments($self, $dt) {
    my @lines;
    my @guard_order;
    my %by_guard;

    for my $assignment (@{$dt->{assignments}}) {
        my $guard_key = _rule_guard_key($assignment->{guard});
        push @guard_order, $guard_key unless exists $by_guard{$guard_key};
        push @{$by_guard{$guard_key}}, $assignment;
    }

    for my $guard_key (@guard_order) {
        my $assignments = $by_guard{$guard_key};
        if ($guard_key eq '') {
            push @lines, map { $self->_format_dt_assignment($_, 4) } @$assignments;
            next;
        }

        push @lines, "    (" . _format_guard_predicate($guard_key);
        push @lines, map { $self->_format_dt_assignment($_, 6, no_guard => 1) } @$assignments;
        push @lines, '    )';
    }

    return @lines;
}

sub _format_dt_assignment($self, $assignment, $indent, %options) {
    my $padding = ' ' x $indent;
    my $guard = !$options{no_guard} ? _format_guard_suffix($assignment->{guard}) : '';
    my $op = $assignment->{op};
    my $lhs = $self->_lhs_token($assignment->{lhs});

    if ($op eq '=') {
        return "$padding(= ($lhs $assignment->{rhs})$guard)";
    } elsif ($op eq '<-') {
        return "$padding(<- ($lhs $assignment->{rhs})$guard)";
    } elsif ($op eq '<=') {
        return "$padding(<= ($lhs $assignment->{rhs})$guard)";
    } elsif ($op =~ /^<[0-9]+$/) {
        return "$padding($op ($lhs $assignment->{rhs})$guard)";
    }

    return "$padding($lhs = $assignment->{rhs})$guard";
}

sub _lhs_token($self, $name) {
    return $self->{outputs}{$name} ? "$name>" : $name;
}

sub _rule_guard_key {
    my ($guard) = @_;
    return '' unless $guard && ref($guard) eq 'HASH';
    return '' if defined($guard->{port}) && $guard->{port} eq '1';
    return $guard->{port} // '';
}

sub _guard_value_present {
    my ($value) = @_;
    return defined($value) && !ref($value) && length($value);
}

sub _format_guard_predicate {
    my ($value) = @_;
    # A compact <N can be mistaken for a delayed-pulse operator in an
    # action head or DT header. A boolean expression also keeps a nested
    # guard payload distinct from the following assignment pair.
    return $value =~ /\A[0-9]+\z/ ? "< (!= $value 0)" : "<$value";
}

sub _format_guard_suffix {
    my ($guard) = @_;
    return '' unless $guard && ref($guard) eq 'HASH';
    return '' if defined($guard->{port}) && $guard->{port} eq '1';
    return " " . _format_guard_predicate($guard->{port})
        if _guard_value_present($guard->{port}) && !$guard->{op};
    if (_guard_value_present($guard->{signal}) && $guard->{op}) {
        my $value = $guard->{value};
        my $operator = $guard->{op} eq '=' ? '=' : $guard->{op};
        return " <$guard->{signal}$operator$value";
    }
    return " " . _format_guard_predicate($guard->{expr})
        if _guard_value_present($guard->{expr});
    return '';
}

sub _format_expr {
    my ($e) = @_;
    return $e unless ref($e) eq 'ARRAY';
    my $op = $e->[0];
    my @args;
    for my $i (1 .. $#$e) {
        my $a = $e->[$i];
        push @args, ref($a) ? _format_expr($a) : $a;
    }
    return "($op " . join(' ', @args) . ')';
}

sub _format_param_value {
    my ($value) = @_;
    return $value unless ref($value) eq 'ARRAY';
    return '(' . join(' ', map { _format_param_value($_) } @$value) . ')';
}

sub _is_default_selector {
    my ($value) = @_;
    return defined($value)
        && !ref($value)
        && ($value eq 'default' || $value eq '_');
}

sub _format_switch_test_selector {
    my ($signal) = @_;
    return "?$signal" if defined($signal) && $signal =~ /\A[A-Za-z_]\w*\z/;
    return "?($signal)";
}

sub _format_condition_selector {
    my ($condition) = @_;
    return '?' . _format_expr($condition) if ref($condition);
    return _format_switch_test_selector($condition);
}

1;
