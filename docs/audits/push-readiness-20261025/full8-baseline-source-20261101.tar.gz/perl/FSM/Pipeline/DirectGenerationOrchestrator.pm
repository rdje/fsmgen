package FSM::Pipeline::DirectGenerationOrchestrator;

=head1 NAME

FSM::Pipeline::DirectGenerationOrchestrator - Orchestrator for bounded direct-root generation

=head1 DESCRIPTION

Owns the bounded non-composition generation orchestration that was still inline
in C<FSM::Pipeline::HDLGenerator>. This package takes parsed direct-root
source, drives semantic module creation plus forward-IR extraction, invokes the
existing direct HDL backend path, and returns the bounded direct-generation
result surface consumed by the outer pipeline.

=cut

use v5.20;
use strict;
use warnings;
use Carp qw(confess);
use feature qw(signatures);
no warnings 'experimental::signatures';

use FSM::Backend::GeneratedModuleEmitter;
use FSM::IR::IntentHIRBuilder;
use FSM::IR::StructuralRTLIRBuilder;
use FSM::Pipeline::GeneratedModuleInfoBuilder;
use FSM::Pipeline::SourceFrontend;

sub generate_from_source ($class, %args) {
    my $pipeline = $args{pipeline}
        or confess "DirectGenerationOrchestrator requires a pipeline";
    my $raw_ast = $args{raw_ast}
        or confess "DirectGenerationOrchestrator requires a raw_ast";
    my $source_info = _clone($args{source_info}
        || FSM::Pipeline::SourceFrontend->classify_source_ast($raw_ast));

    my %frontend_context;
    my $fsm_module = FSM::Pipeline::SourceFrontend->create_fsm_module(
        raw_ast => $raw_ast,
        debug_level => ($pipeline->{debug_level} // 0),
        strict_mode => ($pipeline->{strict_mode} // 0),
        source_label => ($source_info->{header} // 'direct source'),
        fsm_file => $args{fsm_file},
        source_path_resolver => ($args{source_path_resolver} // $pipeline->{source_path_resolver}),
        frontend_context => \%frontend_context,
    );
    my $intent_hir = FSM::IR::IntentHIRBuilder->build_from_fsm_module(
        fsm_module => $fsm_module,
    );
    my $module_info = FSM::Pipeline::GeneratedModuleInfoBuilder->build_from_fsm_module(
        fsm_module => $fsm_module,
        intent_hir => $intent_hir,
    );

    my $backend_result = FSM::Backend::GeneratedModuleEmitter->emit_from_fsm_module(
        fsm_module => $fsm_module,
        target_language => ($pipeline->{target_language} // 'systemverilog'),
        debug_level => ($pipeline->{debug_level} // 0),
        structural_rtlir_enable_assignment_markers => 1,
    );
    $pipeline->{hdl_generator} = $backend_result->{hdl_generator};

    FSM::Pipeline::GeneratedModuleInfoBuilder->enrich_with_generated_analysis(
        module_info => $module_info,
        fsm_module => $fsm_module,
        target_language => ($pipeline->{target_language} // 'systemverilog'),
        hdl_generator => $pipeline->{hdl_generator},
    );
    my $structural_rtl_ir = FSM::IR::StructuralRTLIRBuilder->build_from_generated_module_info(
        module_info => $module_info,
        fsm_module => $fsm_module,
        target_language => ($pipeline->{target_language} // 'systemverilog'),
        hdl_generator => $pipeline->{hdl_generator},
    );
    $module_info->{structural_rtl_ir} = $structural_rtl_ir->as_hashref;
    my $structural_rerouted_hdl_code =
        FSM::Backend::GeneratedModuleEmitter->reroute_generated_enable_assignments_through_structural_rtl_ir(
            hdl_code => $backend_result->{hdl_code},
            structural_rtl_ir => $module_info->{structural_rtl_ir},
            target_language => ($pipeline->{target_language} // 'systemverilog'),
        );
    my $hdl_code = FSM::Backend::GeneratedModuleEmitter->augment_with_runtime_assertions(
        hdl_code => $structural_rerouted_hdl_code,
        module_info => $module_info,
        target_language => ($pipeline->{target_language} // 'systemverilog'),
    );
    my $statistics = $backend_result->{statistics};
    $source_info->{package_import_names} = [ @{$frontend_context{package_imports} || []} ];
    $source_info->{package_import_count} = scalar(@{$source_info->{package_import_names} || []});

    return {
        fsm_module => $fsm_module,
        intent_hir => _clone($intent_hir->as_hashref),
        lowered_rtl_ir => _clone($module_info->{lowered_rtl_ir}),
        structural_rtl_ir => _clone($module_info->{structural_rtl_ir}),
        module_info => $module_info,
        hdl_code => $hdl_code,
        statistics => $statistics,
        resolved_package_imports => ($frontend_context{resolved_package_imports} || {}),
        raw_ast => _clone($raw_ast),
        source_info => $source_info,
    };
}

sub _clone ($value) {
    return undef unless defined $value;
    return [map { _clone($_) } @$value] if ref($value) eq 'ARRAY';
    return {map { $_ => _clone($value->{$_}) } keys %$value} if ref($value) eq 'HASH';
    return $value;
}

1;

__END__

=head1 METHODS

=head2 generate_from_source

Builds the bounded direct-root generation result surface from parsed source
input, driving semantic module creation, forward-IR extraction, direct HDL
generation, module-info enrichment, and statistics collection.

=cut
