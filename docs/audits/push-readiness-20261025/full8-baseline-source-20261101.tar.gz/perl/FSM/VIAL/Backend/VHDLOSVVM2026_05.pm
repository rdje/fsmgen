package FSM::VIAL::Backend::VHDLOSVVM2026_05;

use v5.20;
use strict;
use warnings;
use bytes ();
use Carp qw(confess);
use Digest::SHA qw(sha256_hex);
use JSON::PP ();
use Scalar::Util qw(blessed refaddr reftype);
use feature qw(signatures postderef);
no warnings 'experimental::signatures';

use FSM::Support::VIALSemanticFamilyBackendAdapter qw(
    preflight_vial_semantic_family_backend_adapter
);
use FSM::VIAL::Backend::OSVVM2026_05Materialization;
use FSM::VIAL::Backend::VHDLOSVVMStaticValidator;
use FSM::VIAL::Backend::VHDLPortableGHDL;

my $BACKEND_PROFILE = 'vhdl_osvvm_qualified';
my $BACKEND_SCHEMA = 'fsmgen.vial_backend.vhdl_osvvm.v1';
my $EMITTER_REVISION = 4;
my $BASE = 'backends/vhdl_osvvm_qualified';
my $DEPENDENCY_ROOT = '.artifacts/cache/providers/osvvm/2026.05/source';
my $QUALIFICATION_REPORT =
    'vial/qualification/vhdl_osvvm_ghdl/osvvm-2026.05-ghdl-6.0.0-qualification.json';
my $QUALIFICATION_SHA256 =
    'd397bed3a9820fec473af8f070bb3f5b9a18e4b5ff925286c1458fab46f8b9ab';
my $JSON = JSON::PP->new->canonical(1);
my $PRETTY_JSON = JSON::PP->new->canonical(1)->pretty(1);
my $PORTABLE_SOURCE_ARTIFACT_COUNT = 6;
my $ADAPTER_SOURCE_BYTES = 4_351;
my $ADAPTER_SOURCE_MAP_ENTRY_COUNT = 7;
my $TOTAL_ARTIFACT_COUNT = 16;
my @REQUIREMENT_IDS = qw(
    advanced_coverage advanced_data_structure advanced_randomization
    advanced_reporting advanced_scoreboard advanced_synchronization
    verification_component_adapter
);
my @RESULT_KEYS = qw(
    ok status backend_profile plan_id generated_top operation_id negotiation
    provider_materialization mapping_matrix semantic_preservation source_map
    static_validation backend_manifest artifacts diagnostics
);
# The registry is deliberately lexical.  Its strong token reference prevents
# address reuse during a callback, and deletion after the callback makes every
# retained object stale without exposing verified provider evidence to callers.
my %PROVIDER_EVALUATIONS;
my $NEXT_PROVIDER_EVALUATION_ID = 0;

sub result_keys($class) {
    _exact_class($class, 'result_keys');
    return [@RESULT_KEYS];
}

sub emit($class, @args) {
    return _failure('VIAL_OSVVM_BACKEND_INVOCATION_ERROR',
        'emit requires the exact backend class invocant', '/')
        unless defined($class) && !ref($class) && $class eq __PACKAGE__;
    return _failure('VIAL_OSVVM_BACKEND_INVOCATION_ERROR',
        'emit expects one closed argument hash', '/')
        unless @args == 1 && ref($args[0]) eq 'HASH' && !blessed($args[0]);
    return _run_emit($args[0]);
}

sub with_provider_evaluation($class, @args) {
    return _failure('VIAL_OSVVM_PROVIDER_EVALUATION_ERROR',
        'with_provider_evaluation requires the exact backend class invocant',
        '/provider_evaluation')
        unless defined($class) && !ref($class) && $class eq __PACKAGE__;
    return _failure('VIAL_OSVVM_PROVIDER_EVALUATION_ERROR',
        'with_provider_evaluation expects one closed argument hash',
        '/provider_evaluation')
        unless @args == 1 && ref($args[0]) eq 'HASH' && !blessed($args[0]);
    my $result = eval { _with_provider_evaluation($args[0]) };
    return $result if defined $result;
    my $error = $@ || 'unknown OSVVM provider-evaluation error';
    $error =~ s/\s+\z//;
    return _failure('VIAL_OSVVM_PROVIDER_EVALUATION_ERROR', $error,
        '/provider_evaluation');
}

sub _with_provider_evaluation($raw) {
    _require_keys($raw, [qw(dependency_root consumer)]);
    confess "provider evaluation requires the exact repository-local OSVVM 2026.05 root\n"
        unless defined($raw->{dependency_root}) && !ref($raw->{dependency_root})
            && $raw->{dependency_root} eq $DEPENDENCY_ROOT;
    confess "provider evaluation consumer must be one callback\n"
        unless ref($raw->{consumer}) eq 'CODE';

    my $token_id = ++$NEXT_PROVIDER_EVALUATION_ID;
    my $evaluation = bless \$token_id,
        'FSM::VIAL::Backend::VHDLOSVVM2026_05::ProviderEvaluation';
    my $address = refaddr($evaluation);
    $PROVIDER_EVALUATIONS{$address} = {
        token => $evaluation,
        token_id => $token_id,
        dependency_root => $raw->{dependency_root},
        provider => undef,
        provider_identity => undef,
    };

    my $result = eval { $raw->{consumer}->($evaluation) };
    my $error = $@;
    delete $PROVIDER_EVALUATIONS{$address};
    if ($error ne '') {
        $error =~ s/\s+\z//;
        return _failure('VIAL_OSVVM_PROVIDER_EVALUATION_ERROR', $error,
            '/provider_evaluation');
    }
    return _failure('VIAL_OSVVM_PROVIDER_EVALUATION_ERROR',
        'provider evaluation consumer must return one closed backend result',
        '/provider_evaluation')
        unless ref($result) eq 'HASH' && !blessed($result)
            && join("\0", sort keys %$result)
                eq join("\0", sort @RESULT_KEYS);
    return $result;
}

sub _provider_evaluation_emit($evaluation, @args) {
    return _failure('VIAL_OSVVM_PROVIDER_EVALUATION_ERROR',
        'provider evaluation is stale or forged', '/provider_evaluation')
        unless blessed($evaluation)
            && blessed($evaluation) eq
                'FSM::VIAL::Backend::VHDLOSVVM2026_05::ProviderEvaluation'
            && (reftype($evaluation) // '') eq 'SCALAR';
    my $address = refaddr($evaluation);
    my $context = $PROVIDER_EVALUATIONS{$address};
    return _failure('VIAL_OSVVM_PROVIDER_EVALUATION_ERROR',
        'provider evaluation is stale or forged', '/provider_evaluation')
        unless defined($context)
            && refaddr($context->{token}) == $address
            && ${$evaluation} eq $context->{token_id};
    return _failure('VIAL_OSVVM_PROVIDER_EVALUATION_ERROR',
        'provider evaluation emit expects one closed argument hash',
        '/provider_evaluation')
        unless @args == 1 && ref($args[0]) eq 'HASH' && !blessed($args[0]);
    my $raw = $args[0];
    return _failure('VIAL_OSVVM_PROVIDER_EVALUATION_ERROR',
        'provider source identity does not match the sealed evaluation',
        '/provider_evaluation')
        unless defined($raw->{dependency_root}) && !ref($raw->{dependency_root})
            && $raw->{dependency_root} eq $context->{dependency_root};
    return _run_emit($raw, $context);
}

sub _run_emit($raw, $provider_context = undef) {
    my $result = eval { _emit($raw, $provider_context) };
    return $result if defined $result;
    my $error = $@ || 'unknown OSVVM backend error';
    $error =~ s/\s+\z//;
    return _failure('VIAL_OSVVM_BACKEND_HOST_ERROR', $error, '/');
}

sub _emit($raw, $provider_context = undef) {
    _require_keys($raw, [qw(
        execution_ir bridge_manifest backend_inputs artifact_root
        backend_profile dependency_root advanced_requirements
    )]);
    confess "backend_profile must be '$BACKEND_PROFILE'\n"
        unless defined($raw->{backend_profile}) && !ref($raw->{backend_profile})
            && $raw->{backend_profile} eq $BACKEND_PROFILE;
    confess "execution_ir must be an exact FSM::VIAL::ExecutionIR object\n"
        unless blessed($raw->{execution_ir})
            && ref($raw->{execution_ir}) eq 'FSM::VIAL::ExecutionIR';
    my $adapter_preflight =
        preflight_vial_semantic_family_backend_adapter({
            profile_id => $BACKEND_PROFILE,
            execution_ir => $raw->{execution_ir},
        });
    return _failure(
        'VIAL_OSVVM_BACKEND_UNSUPPORTED',
        'OSVVM backend adapter preflight rejected the typed ExecutionIR',
        '/negotiation',
        $adapter_preflight,
    ) unless $adapter_preflight->{accepted};
    confess "dependency_root must be the exact repository-local OSVVM 2026.05 root\n"
        unless defined($raw->{dependency_root}) && !ref($raw->{dependency_root})
            && $raw->{dependency_root} eq $DEPENDENCY_ROOT;
    confess "advanced_requirements must be one exact array\n"
        unless ref($raw->{advanced_requirements}) eq 'ARRAY';
    my @requirements = @{$raw->{advanced_requirements}};
    confess "advanced_requirements must contain seven unique sorted exact requirements\n"
        unless join("\0", @requirements) eq join("\0", @REQUIREMENT_IDS);

    my $portable = FSM::VIAL::Backend::VHDLPortableGHDL->emit({
        execution_ir => $raw->{execution_ir},
        bridge_manifest => $raw->{bridge_manifest},
        backend_inputs => $raw->{backend_inputs},
        artifact_root => $raw->{artifact_root},
        backend_profile => 'vhdl_portable_ghdl',
    });
    return _failure('VIAL_OSVVM_PORTABLE_FOUNDATION_ERROR',
        $portable->{diagnostics}[0]{message}, '/portable_foundation')
        unless $portable->{ok};

    my @portable_source;
    my @preserved;
    for my $artifact (grep { ($_->{language} // '') eq 'vhdl' }
        @{$portable->{artifacts}}) {
        my $portable_sha256 = sha256_hex($artifact->{content});
        my $portable_bytes = bytes::length($artifact->{content});
        my $tail = $artifact->{relpath};
        $tail =~ s{\Abackends/vhdl_portable_ghdl/src/}{} or
            confess "portable source path is outside the selected source root\n";
        my $advanced = _artifact(
            "$BASE/src/portable/$tail",
            "portable_$artifact->{role}",
            'vhdl_source',
            'vhdl',
            $artifact->{content},
            [$portable_sha256, $portable->{plan_id}],
        );
        push @portable_source, $advanced;
        push @preserved, {
            role => $artifact->{role},
            portable_relpath => $artifact->{relpath},
            advanced_relpath => $advanced->{relpath},
            byte_length => $portable_bytes,
            portable_sha256 => $portable_sha256,
            advanced_sha256 => $advanced->{sha256},
            byte_identical => JSON::PP::true,
        };
    }
    return _failure('VIAL_OSVVM_BACKEND_LIMIT_EXCEEDED',
        'OSVVM wrapper emitted an unexpected source or artifact inventory',
        '/artifacts')
        unless @portable_source == $PORTABLE_SOURCE_ARTIFACT_COUNT;

    my $adapter_text = _render_adapter();
    return _failure('VIAL_OSVVM_BACKEND_LIMIT_EXCEEDED',
        'OSVVM wrapper emitted an unexpected source or artifact inventory',
        '/artifacts')
        unless bytes::length($adapter_text) == $ADAPTER_SOURCE_BYTES;

    my $semantic_preservation = {
        schema => 'fsmgen.vial_vhdl_osvvm_semantic_preservation.v1',
        schema_version => 1,
        portable_profile => 'vhdl_portable_ghdl',
        advanced_profile => $BACKEND_PROFILE,
        portable_plan_id => $portable->{plan_id},
        portable_sources => [sort { $a->{role} cmp $b->{role} } @preserved],
        guards => {
            portable_random_replay_unchanged => JSON::PP::true,
            phase_order_unchanged => JSON::PP::true,
            comparison_semantics_unchanged => JSON::PP::true,
            coverage_semantics_unchanged => JSON::PP::true,
            closed_trace_unchanged => JSON::PP::true,
            normalized_result_unchanged => JSON::PP::true,
        },
        provider_role =>
            'isolated negotiated native services and supplementary evidence only',
    };

    my $mapping_matrix = _mapping_matrix($adapter_text);
    my $translated = _translate_portable_source_map(
        portable => $portable,
        portable_sources => \@preserved,
    );
    return _failure('VIAL_OSVVM_SOURCE_MAP_TRANSLATION_ERROR',
        $translated->{diagnostic}, '/portable_foundation/source_map')
        unless $translated->{ok};
    my $source_map_entry_count = $ADAPTER_SOURCE_MAP_ENTRY_COUNT
        + scalar(@{$translated->{entries}});

    my $provider;
    if (defined($provider_context) && defined($provider_context->{provider})) {
        return _failure('VIAL_OSVVM_PROVIDER_EVALUATION_ERROR',
            'provider evaluation evidence identity drifted',
            '/provider_evaluation')
            unless _provider_identity($provider_context->{dependency_root},
                    $provider_context->{provider})
                eq $provider_context->{provider_identity};
        $provider = _clone_json($provider_context->{provider});
    }
    else {
        $provider = FSM::VIAL::Backend::OSVVM2026_05Materialization->verify({
            dependency_root => $raw->{dependency_root},
        });
        return _failure('VIAL_OSVVM_PROVIDER_MATERIALIZATION_ERROR',
            $provider->{diagnostics}[0]{message}, '/dependency_root')
            unless $provider->{ok};
        if (defined($provider_context)) {
            $provider_context->{provider} = _clone_json($provider);
            $provider_context->{provider_identity} = _provider_identity(
                $provider_context->{dependency_root},
                $provider_context->{provider});
            $provider = _clone_json($provider_context->{provider});
        }
    }
    my $qualification = _load_qualification_report();

    my $adapter = _artifact(
        "$BASE/src/fsmgen_vial_osvvm_adapter_pkg.vhd",
        'vhdl_osvvm_adapter_package',
        'vhdl_source',
        'vhdl',
        $adapter_text,
        [$provider->{manifest}{root_commit}, $portable->{plan_id}],
    );
    my @source_artifacts = (@portable_source, $adapter);
    my $source_map = _source_map(
        plan_id => $portable->{plan_id},
        source_artifacts => \@source_artifacts,
        mapping_matrix => $mapping_matrix,
        portable_entries => $translated->{entries},
    );
    confess "OSVVM source-map preflight disagrees with materialization\n"
        unless @{$source_map->{entries}} == $source_map_entry_count;
    my $static = FSM::VIAL::Backend::VHDLOSVVMStaticValidator->validate({
        artifacts => \@source_artifacts,
        materialization => $provider->{manifest},
        mapping_matrix => $mapping_matrix,
        semantic_preservation => $semantic_preservation,
    });
    return _failure('VIAL_OSVVM_STATIC_VALIDATION_ERROR',
        $static->{diagnostics}[0]{message}, '/static_validation')
        unless $static->{ok};

    my @source_order = (
        (map { $_->{relpath} } @portable_source),
        $adapter->{relpath},
    );
    my $source_order = {
        schema => 'fsmgen.vial_vhdl_osvvm_source_order.v1',
        schema_version => 1,
        provider_build_roots => [
            "$DEPENDENCY_ROOT/osvvm/osvvm.pro",
            "$DEPENDENCY_ROOT/Common/build.pro",
        ],
        generated_sources => \@source_order,
        order_digest => sha256_hex(join("\n", @source_order) . "\n"),
        status => 'executed_qualified',
    };
    my $tool_profile = {
        schema => 'fsmgen.vial_backend_tool_profile.v1',
        schema_version => 1,
        profile => $BACKEND_PROFILE,
        language => 'VHDL',
        standard => 'IEEE 1076-2008',
        standard_option => '--std=08',
        provider => 'OSVVM',
        provider_version => '2026.05',
        provider_commit => $provider->{manifest}{root_commit},
        tool => 'GHDL',
        tool_version => '6.0.0',
        tool_backend => 'llvm_jit',
        tool_commit => 'e589c698c351369ac5bcfe7abe1f1152ac5d4727',
        materialization => 'complete_recursive_verified',
        combined_execution => 'qualified_bounded_fixture_and_adapter_probe',
        qualification_report => $QUALIFICATION_REPORT,
        qualification_report_sha256 => $QUALIFICATION_SHA256,
    };

    my @support_artifacts = (
        _artifact("$BASE/backend-source-map.json", 'backend_source_map',
            'source_map', 'json', _json_text($source_map), [$portable->{plan_id}]),
        _artifact("$BASE/evidence/provider-materialization.json",
            'provider_materialization', 'provider_identity', 'json',
            _json_text($provider->{manifest}), [$provider->{manifest}{root_commit}]),
        _artifact("$BASE/evidence/advanced-mapping-matrix.json",
            'advanced_mapping_matrix', 'mapping_matrix', 'json',
            _json_text($mapping_matrix), [$portable->{plan_id}]),
        _artifact("$BASE/evidence/semantic-preservation.json",
            'semantic_preservation', 'semantic_preservation', 'json',
            _json_text($semantic_preservation), [$portable->{plan_id}]),
        _artifact("$BASE/evidence/source-order.json", 'source_order',
            'source_order', 'json', _json_text($source_order), [$portable->{plan_id}]),
        _artifact("$BASE/evidence/static-validation.json", 'static_validation',
            'static_validation', 'json', _json_text($static), [$portable->{plan_id}]),
        _artifact("$BASE/evidence/tool-profile.json", 'tool_profile',
            'tool_profile', 'json', _json_text($tool_profile),
            [$provider->{manifest}{root_commit}]),
        _artifact("$BASE/evidence/qualification-reference.json",
            'combined_qualification_reference', 'qualification_reference',
            'json', _json_text({
                schema => 'fsmgen.vial_vhdl_osvvm_qualification_reference.v1',
                schema_version => 1,
                status => 'qualified',
                qualification_id => $qualification->{qualification_id},
                report_relpath => $QUALIFICATION_REPORT,
                report_sha256 => $QUALIFICATION_SHA256,
                tool => 'GHDL 6.0.0 LLVM-JIT',
                provider => 'OSVVM 2026.05',
            }), [$qualification->{qualification_id}]),
    );

    my $operation_id = 'op-' . sha256_hex($JSON->encode({
        action => 'emit_osvvm_2026_05_adapter_gallery',
        artifact_root => $raw->{artifact_root},
        emitter_revision => $EMITTER_REVISION,
        plan_id => $portable->{plan_id},
        provider_commit => $provider->{manifest}{root_commit},
        requirements => \@requirements,
    }));
    my @referenced = sort { $a->{relpath} cmp $b->{relpath} }
        map { _artifact_ref($_) } (@source_artifacts, @support_artifacts);
    my $manifest = {
        schema => $BACKEND_SCHEMA,
        schema_version => 1,
        backend_profile => $BACKEND_PROFILE,
        plan_id => $portable->{plan_id},
        fixture_id => $portable->{backend_manifest}{fixture_id},
        generated_top => $portable->{generated_top},
        emitter_revision => $EMITTER_REVISION,
        execution_profile => $portable->{backend_manifest}{execution_profile},
        standard_profile => {
            language => 'VHDL',
            standard => 'IEEE 1076-2008',
            standard_option => '--std=08',
            methodology => 'OSVVM 2026.05',
        },
        provider_profile => $tool_profile,
        profile_state => {
            materialization => 'complete_recursive_verified',
            emission => 'emitted',
            static_review => 'passed_structural_only',
            visual_review => 'pending',
            qualification => 'qualified_bounded_fixture_and_adapter_probe',
        },
        negotiation => {
            required => \@requirements,
            satisfied => \@requirements,
            unsatisfied => [],
            semantic_authority => 'portable_vhdl_execution_and_result_oracles',
        },
        capability_evidence => {
            provider_materialization => 'passed_exact_recursive_identity',
            provider_licence_notice_inventory =>
                'passed_exact_inventory_with_documentation_absence_explicit',
            advanced_adapter_emission => 'passed',
            advanced_mapping_matrix => 'passed_seven_exact_mappings',
            portable_semantic_preservation => 'passed_six_byte_identical_sources',
            static_validation => 'passed_structural_only',
            source_map => 'passed_seven_adapter_and_complete_portable_translation',
            provider_compilation => 'passed_sixty_one_ordered_sources',
            analysis => 'passed_adapter_and_generated_fixture',
            elaboration => 'passed_fixture_and_provider_probe',
            runtime => 'passed_bounded_fixture_and_provider_probe',
            trace => 'passed_closed_seventy_seven_record_trace_v2',
            result => 'produced_normalized_pass',
            parity => 'passed_nineteen_applicable_portable_paths',
            supplementary_provider_reports =>
                'passed_four_deterministic_osvvm_reports',
            deterministic_rerun => 'passed_fixture_probe_and_reports',
            cleanup => 'passed_same_volume_exact_removal',
            product_support => 'qualified_private_fixture_profile_not_public_api',
        },
        limitations => [
            'The exact Documentation submodule has no tracked licence or notice file; no coverage is inferred.',
            'Advanced provider services cannot rerandomize portable decisions, move phase barriers, redefine comparison or coverage meaning, alter the closed trace, or replace normalized results.',
            'Qualification covers one bounded generated fixture and one supplementary adapter probe; it is not general VHDL or OSVVM breadth.',
            'The OSVVM Common address-bus type is analyzed through the adapter, but no provider verification-component transaction executes.',
        ],
        source_order => $source_order,
        source_map => {
            relpath => "$BASE/backend-source-map.json",
            schema => $source_map->{schema},
            entry_count => scalar(@{$source_map->{entries}}),
            sha256 => sha256_hex(_json_text($source_map)),
        },
        artifacts => \@referenced,
        result => {
            schema => 'fsmgen.verification_result_manifest.v1',
            status => 'pass',
            relpath => $QUALIFICATION_REPORT,
            result_record_sha256 => $qualification->{result}{result_record_sha256},
        },
        cleanup => {
            staging_identity => ".artifacts/tmp/vial/$operation_id",
            state => 'not_created',
        },
        diagnostics => [],
    };
    my $manifest_artifact = _artifact("$BASE/backend-manifest.json",
        'backend_manifest', 'backend_manifest', 'json', _json_text($manifest),
        [$portable->{plan_id}, $provider->{manifest}{root_commit}]);
    my @artifacts = sort { $a->{relpath} cmp $b->{relpath} }
        (@source_artifacts, @support_artifacts, $manifest_artifact);
    return _failure('VIAL_OSVVM_BACKEND_LIMIT_EXCEEDED',
        'OSVVM wrapper emitted an unexpected source or artifact inventory',
        '/artifacts')
        unless @artifacts == $TOTAL_ARTIFACT_COUNT;

    return {
        ok => JSON::PP::true,
        status => 'emitted_structurally_reviewed_qualified',
        backend_profile => $BACKEND_PROFILE,
        plan_id => $portable->{plan_id},
        generated_top => $portable->{generated_top},
        operation_id => $operation_id,
        negotiation => $manifest->{negotiation},
        provider_materialization => $provider->{manifest},
        mapping_matrix => $mapping_matrix,
        semantic_preservation => $semantic_preservation,
        source_map => $source_map,
        static_validation => $static,
        backend_manifest => $manifest,
        artifacts => \@artifacts,
        diagnostics => [],
    };
}

sub _mapping_matrix($adapter_text) {
    my @definition = (
        ['advanced_coverage', 'osvvm.CoveragePkg', 'fsmgen_osvvm_coverage_sample',
            'supplementary_provider_coverage',
            'portable VIAL coverage counters and bin meaning remain authoritative'],
        ['advanced_data_structure', 'osvvm.MemoryPkg', 'fsmgen_osvvm_memory_write',
            'negotiated_provider_memory',
            'provider storage is available only for a distinct native requirement'],
        ['advanced_randomization', 'osvvm.RandomPkg', 'fsmgen_osvvm_native_random',
            'isolated_native_decision',
            'portable keyed decisions are replayed and never rerandomized'],
        ['advanced_reporting', 'osvvm.AlertLogPkg', 'fsmgen_osvvm_affirm',
            'supplementary_provider_reporting',
            'provider reports cannot replace the normalized result oracle'],
        ['advanced_scoreboard', 'osvvm.ScoreboardGenericPkg',
            'fsmgen_osvvm_scoreboard_check', 'supplementary_provider_scoreboard',
            'portable comparison meaning and bounded scoreboard remain authoritative'],
        ['advanced_synchronization', 'osvvm.TbUtilPkg',
            'fsmgen_osvvm_wait_for_barrier', 'provider_component_coordination',
            'provider synchronization cannot move the generated phase barrier'],
        ['verification_component_adapter',
            'osvvm_common.AddressBusTransactionPkg',
            'fsmgen_vial_osvvm_address_bus_t', 'negotiated_mit_adapter',
            'component completion projects into unchanged generated plan ranks'],
    );
    my @mappings;
    for my $definition (@definition) {
        my ($mapping_id, $provider_package, $symbol, $mode, $guard) = @$definition;
        my ($start, $end) = _line_span($adapter_text, $symbol);
        push @mappings, {
            mapping_id => $mapping_id,
            provider_package => $provider_package,
            provider_symbol => $symbol,
            mode => $mode,
            generated_role => 'vhdl_osvvm_adapter_package',
            source_map_id => "osvvm-map-$mapping_id",
            generated_start_line => $start,
            generated_end_line => $end,
            emission_status => 'emitted',
            static_status => 'passed',
            qualification_status => $mapping_id eq 'verification_component_adapter'
                ? 'passed_analysis_only' : 'passed_runtime_probe',
            semantic_guard => $guard,
        };
    }
    return {
        schema => 'fsmgen.vial_vhdl_osvvm_mapping_matrix.v1',
        schema_version => 1,
        profile => $BACKEND_PROFILE,
        provider => 'OSVVM 2026.05',
        mappings => \@mappings,
        profile_state => {
            emission => 'emitted',
            static_review => 'passed_structural_only',
            qualification => 'qualified_bounded_fixture_and_adapter_probe',
        },
    };
}

sub _source_map(%args) {
    my ($adapter) = grep { $_->{role} eq 'vhdl_osvvm_adapter_package' }
        @{$args{source_artifacts}};
    my @entries = map {
        +{
            source_map_id => $_->{source_map_id},
            generated_relpath => $adapter->{relpath},
            generated_start_line => $_->{generated_start_line},
            generated_end_line => $_->{generated_end_line},
            generated_symbol => $_->{provider_symbol},
            role => $_->{generated_role},
            plan_paths => ['/advanced_requirements/' . $_->{mapping_id}],
            semantic_paths => ['/provider_mappings/' . $_->{mapping_id}],
            source_locations => [
                'docs/HIAL_VIAL_VERIFICATION_FIXTURE_ARCHITECTURE_AUDIT.md',
            ],
        }
    } @{$args{mapping_matrix}{mappings}};
    push @entries, map { _clone_json($_) } @{$args{portable_entries}};
    return {
        schema => 'fsmgen.vial_vhdl_osvvm_source_map.v1',
        schema_version => 1,
        plan_id => $args{plan_id},
        artifacts => [map { _artifact_ref($_) }
            sort { $a->{relpath} cmp $b->{relpath} } @{$args{source_artifacts}}],
        entries => \@entries,
    };
}

sub _translate_portable_source_map(%args) {
    my $portable = $args{portable};
    my $preserved = $args{portable_sources};
    return _translation_failure('portable emission result is absent')
        unless ref($portable) eq 'HASH' && !blessed($portable);
    return _translation_failure('portable source translation set is absent')
        unless ref($preserved) eq 'ARRAY';
    my $source_map = $portable->{source_map};
    return _translation_failure('portable source map is absent')
        unless ref($source_map) eq 'HASH' && !blessed($source_map);
    return _translation_failure('portable source-map key set is not closed')
        unless _keys_match($source_map,
            FSM::VIAL::Backend::VHDLPortableGHDL->source_map_keys);
    return _translation_failure('portable source-map identity is inconsistent')
        unless ($source_map->{schema} // '')
                eq 'fsmgen.vial_vhdl_backend_source_map.v1'
            && ($source_map->{schema_version} // '') eq '1'
            && ($source_map->{plan_id} // '') eq ($portable->{plan_id} // '');
    return _translation_failure('portable source-map collections are absent')
        unless ref($source_map->{artifacts}) eq 'ARRAY'
            && ref($source_map->{entries}) eq 'ARRAY';

    return _translation_failure('portable artifact collection is absent')
        unless ref($portable->{artifacts}) eq 'ARRAY';
    my %portable_artifact;
    for my $artifact (grep {
        ref($_) eq 'HASH' && (($_->{language} // '') eq 'vhdl')
    } @{$portable->{artifacts}}) {
        return _translation_failure('portable source artifact is malformed')
            unless ref($artifact) eq 'HASH' && !blessed($artifact)
                && defined($artifact->{relpath}) && !ref($artifact->{relpath})
                && defined($artifact->{content}) && !ref($artifact->{content})
                && defined($artifact->{kind}) && !ref($artifact->{kind})
                && defined($artifact->{role}) && !ref($artifact->{role});
        return _translation_failure('portable source artifact path is duplicated')
            if exists $portable_artifact{$artifact->{relpath}};
        $portable_artifact{$artifact->{relpath}} = $artifact;
    }
    return _translation_failure('portable source artifact census is not six')
        unless keys(%portable_artifact) == 6;

    my (%wrapper_path, %wrapper_seen);
    for my $translation (@{$preserved}) {
        return _translation_failure('portable source translation is malformed')
            unless ref($translation) eq 'HASH' && !blessed($translation)
                && defined($translation->{portable_relpath})
                && !ref($translation->{portable_relpath})
                && defined($translation->{advanced_relpath})
                && !ref($translation->{advanced_relpath});
        my $portable_relpath = $translation->{portable_relpath};
        my $advanced_relpath = $translation->{advanced_relpath};
        return _translation_failure('portable source translation is duplicated')
            if exists($wrapper_path{$portable_relpath})
                || $wrapper_seen{$advanced_relpath}++;
        return _translation_failure('portable source translation is unbound')
            unless exists $portable_artifact{$portable_relpath};
        $wrapper_path{$portable_relpath} = $advanced_relpath;
    }
    return _translation_failure('portable source translation is incomplete')
        unless keys(%wrapper_path) == 6;

    my @expected_artifact = map {
        my $artifact = $portable_artifact{$_};
        +{
            relpath => $artifact->{relpath},
            kind => $artifact->{kind},
            role => $artifact->{role},
            sha256 => sha256_hex($artifact->{content}),
            bytes => bytes::length($artifact->{content}),
        }
    } sort keys %portable_artifact;
    return _translation_failure('portable source-map artifact closure drifted')
        unless $JSON->encode($source_map->{artifacts})
            eq $JSON->encode(\@expected_artifact);

    my %source_shape = map {
        $_ => _source_shape($portable_artifact{$_}{content})
    } keys %portable_artifact;
    my $entry_keys =
        FSM::VIAL::Backend::VHDLPortableGHDL->source_map_entry_keys;
    my (%source_seen, @translated);
    for my $entry (@{$source_map->{entries}}) {
        return _translation_failure('portable source-map entry is malformed')
            unless ref($entry) eq 'HASH' && !blessed($entry)
                && _keys_match($entry, $entry_keys);
        my $relpath = $entry->{generated_relpath};
        return _translation_failure('portable source-map entry is unbound')
            unless defined($relpath) && !ref($relpath)
                && exists($wrapper_path{$relpath});
        for my $key (qw(generated_symbol role)) {
            return _translation_failure(
                "portable source-map entry $key is malformed")
                unless defined($entry->{$key}) && !ref($entry->{$key})
                    && length($entry->{$key});
        }
        for my $key (qw(
            generated_start_line generated_end_line
            generated_start_column generated_end_column
        )) {
            return _translation_failure(
                "portable source-map entry $key is malformed")
                unless defined($entry->{$key}) && !ref($entry->{$key})
                    && $entry->{$key} =~ /\A[0-9]+\z/ && $entry->{$key} >= 1;
        }
        return _translation_failure('portable source-map span is reversed')
            if $entry->{generated_end_line} < $entry->{generated_start_line};
        my $shape = $source_shape{$relpath};
        return _translation_failure('portable source-map span is outside its artifact')
            unless $entry->{generated_start_line} <= $shape->{line_count}
                && $entry->{generated_end_line} <= $shape->{line_count}
                && $entry->{generated_start_column} == 1
                && $entry->{generated_end_column}
                    == $shape->{end_columns}[$entry->{generated_end_line}];
        for my $key (qw(
            plan_paths semantic_paths bridge_fact_paths source_locations
        )) {
            return _translation_failure(
                "portable source-map entry $key is malformed")
                unless ref($entry->{$key}) eq 'ARRAY';
        }
        my $expected_id = 'source-map/' . sha256_hex($JSON->encode({
            relpath => $relpath,
            symbol => $entry->{generated_symbol},
            role => $entry->{role},
        }));
        return _translation_failure('portable source-map identity drifted')
            unless ($entry->{source_map_id} // '') eq $expected_id
                && !$source_seen{$expected_id}++;

        my $translated = _clone_json($entry);
        $translated->{generated_relpath} = $wrapper_path{$relpath};
        $translated->{source_map_id} = 'source-map/' . sha256_hex($JSON->encode({
            relpath => $translated->{generated_relpath},
            symbol => $translated->{generated_symbol},
            role => $translated->{role},
        }));
        push @translated, $translated;
    }
    return _translation_failure('portable source-map entry set is empty')
        unless @translated;
    my %covered = map { $_->{generated_relpath} => 1 } @translated;
    return _translation_failure('portable source-map artifact coverage is incomplete')
        unless keys(%covered) == 6
            && !(grep { !$covered{$_} } values %wrapper_path);
    return {ok => JSON::PP::true, entries => \@translated, diagnostic => undef};
}

sub _source_shape($content) {
    my @line = split /\n/, $content, -1;
    pop @line if @line && $line[-1] eq '';
    return {
        line_count => scalar(@line),
        end_columns => [undef, map { bytes::length($_) + 1 } @line],
    };
}

sub _translation_failure($diagnostic) {
    return {ok => JSON::PP::false, entries => [], diagnostic => $diagnostic};
}

sub _keys_match($value, $expected) {
    return 0 unless ref($value) eq 'HASH' && !blessed($value);
    return join("\0", sort keys %{$value}) eq join("\0", sort @{$expected});
}

sub _render_adapter() {
    return <<'VHDL';
-- Generated by FSM::VIAL::Backend::VHDLOSVVM2026_05 revision 1.
-- OSVVM services are isolated native/supplementary mappings. Portable VIAL
-- scheduling, replay, comparison, coverage, trace, and result meaning remain
-- authoritative and are byte-identical to vhdl_portable_ghdl.
library ieee;
use ieee.std_logic_1164.all;

library osvvm;
context osvvm.OsvvmContext;

library osvvm_common;

package fsmgen_vial_osvvm_adapter_pkg is
  constant FSMGEN_VIAL_OSVVM_VERSION : string := "2026.05";
  constant FSMGEN_VIAL_OSVVM_SCOREBOARD_BASIS : string :=
    "osvvm.ScoreboardGenericPkg via osvvm.ScoreboardPkg_slv";

  subtype fsmgen_vial_osvvm_scoreboard_id_t is
    osvvm.ScoreboardPkg_slv.ScoreboardIDType;
  subtype fsmgen_vial_osvvm_coverage_id_t is
    osvvm.CoveragePkg.CoverageIDType;
  subtype fsmgen_vial_osvvm_barrier_t is
    osvvm.TbUtilPkg.BarrierType;
  subtype fsmgen_vial_osvvm_memory_id_t is
    osvvm.MemoryPkg.MemoryIDType;
  subtype fsmgen_vial_osvvm_address_bus_t is
    osvvm_common.AddressBusTransactionPkg.AddressBusRecType;

  procedure fsmgen_osvvm_native_random(
    variable generator : inout osvvm.RandomPkg.RandomPType;
    constant minimum : in integer;
    constant maximum : in integer;
    variable value : out integer
  );

  procedure fsmgen_osvvm_coverage_sample(
    constant coverage_id : in fsmgen_vial_osvvm_coverage_id_t;
    constant point : in integer
  );

  procedure fsmgen_osvvm_scoreboard_expect(
    constant scoreboard_id : in fsmgen_vial_osvvm_scoreboard_id_t;
    constant expected : in std_logic_vector
  );

  procedure fsmgen_osvvm_scoreboard_check(
    constant scoreboard_id : in fsmgen_vial_osvvm_scoreboard_id_t;
    constant actual : in std_logic_vector
  );

  procedure fsmgen_osvvm_affirm(
    constant condition : in boolean;
    constant message : in string
  );

  procedure fsmgen_osvvm_wait_for_barrier(
    signal barrier : inout fsmgen_vial_osvvm_barrier_t
  );

  impure function fsmgen_osvvm_new_memory(
    constant name : in string;
    constant address_width : in positive;
    constant data_width : in positive
  ) return fsmgen_vial_osvvm_memory_id_t;

  procedure fsmgen_osvvm_memory_write(
    constant memory_id : in fsmgen_vial_osvvm_memory_id_t;
    constant address_value : in std_logic_vector;
    constant data_value : in std_logic_vector
  );
end package;

package body fsmgen_vial_osvvm_adapter_pkg is
  procedure fsmgen_osvvm_native_random(
    variable generator : inout osvvm.RandomPkg.RandomPType;
    constant minimum : in integer;
    constant maximum : in integer;
    variable value : out integer
  ) is
  begin
    value := generator.Uniform(minimum, maximum);
  end procedure;

  procedure fsmgen_osvvm_coverage_sample(
    constant coverage_id : in fsmgen_vial_osvvm_coverage_id_t;
    constant point : in integer
  ) is
  begin
    osvvm.CoveragePkg.ICover(coverage_id, point);
  end procedure;

  procedure fsmgen_osvvm_scoreboard_expect(
    constant scoreboard_id : in fsmgen_vial_osvvm_scoreboard_id_t;
    constant expected : in std_logic_vector
  ) is
  begin
    osvvm.ScoreboardPkg_slv.Push(scoreboard_id, expected);
  end procedure;

  procedure fsmgen_osvvm_scoreboard_check(
    constant scoreboard_id : in fsmgen_vial_osvvm_scoreboard_id_t;
    constant actual : in std_logic_vector
  ) is
  begin
    osvvm.ScoreboardPkg_slv.Check(scoreboard_id, actual);
  end procedure;

  procedure fsmgen_osvvm_affirm(
    constant condition : in boolean;
    constant message : in string
  ) is
  begin
    osvvm.AlertLogPkg.AffirmIf(condition, message);
  end procedure;

  procedure fsmgen_osvvm_wait_for_barrier(
    signal barrier : inout fsmgen_vial_osvvm_barrier_t
  ) is
  begin
    osvvm.TbUtilPkg.WaitForBarrier(barrier);
  end procedure;

  impure function fsmgen_osvvm_new_memory(
    constant name : in string;
    constant address_width : in positive;
    constant data_width : in positive
  ) return fsmgen_vial_osvvm_memory_id_t is
  begin
    return osvvm.MemoryPkg.NewID(name, address_width, data_width);
  end function;

  procedure fsmgen_osvvm_memory_write(
    constant memory_id : in fsmgen_vial_osvvm_memory_id_t;
    constant address_value : in std_logic_vector;
    constant data_value : in std_logic_vector
  ) is
  begin
    osvvm.MemoryPkg.MemWrite(memory_id, address_value, data_value);
  end procedure;
end package body;
VHDL
}

sub _line_span($text, $symbol) {
    my $offset = index($text, $symbol);
    confess "generated adapter lacks mapped symbol '$symbol'\n" if $offset < 0;
    my $prefix = substr($text, 0, $offset);
    my $line = 1 + (() = $prefix =~ /\n/g);
    return ($line, $line);
}

sub _load_qualification_report() {
    open my $fh, '<:raw', $QUALIFICATION_REPORT
        or confess "checked OSVVM/GHDL qualification report is absent\n";
    local $/;
    my $content = <$fh>;
    close $fh
        or confess "cannot close checked OSVVM/GHDL qualification report\n";
    confess "checked OSVVM/GHDL qualification report digest drifted\n"
        unless sha256_hex($content) eq $QUALIFICATION_SHA256;
    my $report = eval { JSON::PP->new->decode($content) };
    confess "checked OSVVM/GHDL qualification report is malformed\n"
        unless defined($report) && !$@ && ref($report) eq 'HASH'
            && !blessed($report);
    confess "checked OSVVM/GHDL qualification identity drifted\n"
        unless ($report->{schema} // '')
                eq 'fsmgen.vial_vhdl_osvvm_ghdl_qualification.v1'
            && ($report->{status} // '') eq 'qualified'
            && ($report->{backend_profile} // '') eq $BACKEND_PROFILE
            && ($report->{tool_profile}{qualified_version} // '') eq '6.0.0'
            && ($report->{provider_profile}{version} // '') eq '2026.05'
            && ($report->{result}{status} // '') eq 'pass'
            && $report->{portable_result_parity}{equivalent}
            && ($report->{supplementary_provider_reports}{report_count} // 0) == 4
            && $report->{cleanup}{removed}
            && $report->{cleanup}{same_volume};
    return $report;
}

sub _artifact($relpath, $role, $kind, $language, $content, $source_ids) {
    return {
        relpath => $relpath,
        role => $role,
        kind => $kind,
        language => $language,
        content => $content,
        byte_length => bytes::length($content),
        sha256 => sha256_hex($content),
        source_ids => [@$source_ids],
    };
}

sub _artifact_ref($artifact) {
    return {
        relpath => $artifact->{relpath},
        role => $artifact->{role},
        kind => $artifact->{kind},
        language => $artifact->{language},
        byte_length => $artifact->{byte_length},
        sha256 => $artifact->{sha256},
        source_ids => [@{$artifact->{source_ids}}],
    };
}

sub _json_text($value) {
    return $PRETTY_JSON->encode($value);
}

sub _clone_json($value) {
    return $JSON->decode($JSON->encode($value));
}

sub _provider_identity($dependency_root, $provider) {
    return sha256_hex($JSON->encode({
        dependency_root => $dependency_root,
        provider => $provider,
    }));
}

sub _require_keys($value, $expected) {
    confess "backend invocation key set is not closed\n"
        unless join("\0", sort keys %$value) eq join("\0", sort @$expected);
}

sub _failure($code, $message, $path, $negotiation = undef) {
    return {
        ok => JSON::PP::false,
        status => 'failed',
        backend_profile => $BACKEND_PROFILE,
        plan_id => undef,
        generated_top => undef,
        operation_id => undef,
        negotiation => defined($negotiation)
            ? _clone_json($negotiation) : undef,
        provider_materialization => undef,
        mapping_matrix => undef,
        semantic_preservation => undef,
        source_map => undef,
        static_validation => undef,
        backend_manifest => undef,
        artifacts => [],
        diagnostics => [{code => $code, message => $message, path => $path}],
    };
}

sub _exact_class($class, $method) {
    confess __PACKAGE__ . "->$method requires the exact class invocant\n"
        unless defined($class) && !ref($class) && $class eq __PACKAGE__;
}

1;

package FSM::VIAL::Backend::VHDLOSVVM2026_05::ProviderEvaluation;

use v5.20;
use strict;
use warnings;
use feature qw(signatures);
no warnings 'experimental::signatures';

sub emit($evaluation, @args) {
    return FSM::VIAL::Backend::VHDLOSVVM2026_05::_provider_evaluation_emit(
        $evaluation, @args);
}

1;
