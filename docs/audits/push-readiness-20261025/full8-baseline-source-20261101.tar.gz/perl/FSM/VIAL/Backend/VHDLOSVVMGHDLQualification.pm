package FSM::VIAL::Backend::VHDLOSVVMGHDLQualification;

use v5.20;
use strict;
use warnings;
use bytes ();
use Carp qw(confess);
use Cwd qw(abs_path);
use Digest::SHA qw(sha256_hex);
use File::Spec;
use JSON::PP ();
use Scalar::Util qw(blessed);
use feature qw(signatures postderef);
no warnings 'experimental::signatures';

use FSM::VIAL::Backend::VHDLPortableTraceValidator;

use FSM::VIAL::Backend::GHDLLifecycle;
use FSM::VIAL::Backend::OSVVM2026_05Materialization;
use FSM::VIAL::ArchitectureScaleOSVVMRuntimeExecutionPlan;

my $JSON = JSON::PP->new->canonical(1);
my $SCHEMA = 'fsmgen.vial_vhdl_osvvm_ghdl_qualification.v1';
my $PROFILE = 'vhdl_osvvm_qualified';
my $TASK_ID = 'HIAL-VIAL-VERIFICATION-FIXTURE-ARCHITECTURE.17.3.6.1';
my $EXECUTION_PLAN_AUTHORITY =
    FSM::VIAL::ArchitectureScaleOSVVMRuntimeExecutionPlan
        ->_qualification_authority;
my $GHDL_ROOT = $EXECUTION_PLAN_AUTHORITY->{ghdl_root};
my $GHDL_ARCHIVE = $EXECUTION_PLAN_AUTHORITY->{ghdl_archive};
my $GHDL_BINARY = $EXECUTION_PLAN_AUTHORITY->{ghdl_binary};
my $OSVVM_ROOT = $EXECUTION_PLAN_AUTHORITY->{osvvm_root};
my $ARCHIVE_BYTES = $EXECUTION_PLAN_AUTHORITY->{archive_bytes};
my $ARCHIVE_SHA256 = $EXECUTION_PLAN_AUTHORITY->{archive_sha256};
my $BINARY_SHA256 = $EXECUTION_PLAN_AUTHORITY->{binary_sha256};
my $VERSION_OUTPUT = $EXECUTION_PLAN_AUTHORITY->{version_output};
my $TRACE_AUTHORITY =
    FSM::VIAL::Backend::VHDLPortableTraceValidator->checked_reference_authority;

my @GENERATED_SOURCE = @{$EXECUTION_PLAN_AUTHORITY->{generated_source}};
my @OSVVM_SOURCE = @{$EXECUTION_PLAN_AUTHORITY->{osvvm_source}};
my @COMMON_SOURCE = @{$EXECUTION_PLAN_AUTHORITY->{common_source}};
my @PROVIDER_REPORT = @{$EXECUTION_PLAN_AUTHORITY->{provider_report}};

my @RESULT_KEYS = qw(ok status report content diagnostics cleanup);
my @REPORT_KEYS = qw(
    schema schema_version qualification_id task_id status backend_profile
    tool_profile provider_profile source_set provider_compilation commands
    execution trace result deterministic_rerun portable_result_parity
    supplementary_provider_reports capability_support resource_controls
    cleanup limitations
);

sub result_keys($class) {
    _exact_class($class, 'result_keys');
    return [@RESULT_KEYS];
}

sub report_keys($class) {
    _exact_class($class, 'report_keys');
    return [@REPORT_KEYS];
}

sub default_ghdl_provider_root($class) {
    _exact_class($class, 'default_ghdl_provider_root');
    return $GHDL_ROOT;
}

sub default_osvvm_dependency_root($class) {
    _exact_class($class, 'default_osvvm_dependency_root');
    return $OSVVM_ROOT;
}

sub qualify($class, @args) {
    return _failure('VIAL_OSVVM_GHDL_QUALIFICATION_INVOCATION_ERROR',
        'qualify requires the exact qualification class invocant', '/')
        unless defined($class) && !ref($class) && $class eq __PACKAGE__;
    return _failure('VIAL_OSVVM_GHDL_QUALIFICATION_INVOCATION_ERROR',
        'qualify expects one closed argument hash', '/')
        unless @args == 1 && ref($args[0]) eq 'HASH' && !blessed($args[0]);
    my $result = eval { _qualify($args[0]) };
    return $result if defined $result;
    my $error = $@;
    return _failure($error->{code}, $error->{message}, $error->{path})
        if blessed($error)
            && $error->isa('FSM::VIAL::Backend::VHDLOSVVMGHDLQualification::Failure');
    return _failure('VIAL_OSVVM_GHDL_QUALIFICATION_HOST_ERROR',
        _sanitize_exception($error), '/');
}

sub _qualify($raw) {
    _require_exact_keys($raw,
        [qw(repo_root ghdl_provider_root osvvm_dependency_root)],
        'qualification invocation');
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_INVOCATION_ERROR',
        'repo_root must be a scalar directory path', '/repo_root')
        unless defined($raw->{repo_root}) && !ref($raw->{repo_root});
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_PATH_ERROR',
        'ghdl_provider_root must be the exact repository-relative qualified root',
        '/ghdl_provider_root')
        unless defined($raw->{ghdl_provider_root})
            && !ref($raw->{ghdl_provider_root})
            && $raw->{ghdl_provider_root} eq $GHDL_ROOT;
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_PATH_ERROR',
        'osvvm_dependency_root must be the exact repository-relative provider root',
        '/osvvm_dependency_root')
        unless defined($raw->{osvvm_dependency_root})
            && !ref($raw->{osvvm_dependency_root})
            && $raw->{osvvm_dependency_root} eq $OSVVM_ROOT;

    my $repo_root = abs_path($raw->{repo_root});
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_PATH_ERROR',
        'repository root is not a readable directory', '/repo_root')
        unless defined($repo_root) && -d $repo_root && !-l $repo_root;
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_PATH_ERROR',
        'qualification must execute with the repository root as current directory',
        '/repo_root')
        unless abs_path('.') eq $repo_root;
    my @root_stat = stat($repo_root);
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_PATH_ERROR',
        'repository filesystem identity is unavailable', '/repo_root')
        unless @root_stat;

    my $archive_abs = _repo_path($repo_root, $GHDL_ARCHIVE);
    my $binary_abs = _repo_path($repo_root, $GHDL_BINARY);
    my $osvvm_abs = _repo_path($repo_root, $OSVVM_ROOT);
    _regular_same_volume($archive_abs, $GHDL_ARCHIVE, $root_stat[0]);
    _regular_same_volume($binary_abs, $GHDL_BINARY, $root_stat[0]);
    _directory_same_volume($osvvm_abs, $OSVVM_ROOT, $root_stat[0]);
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_TOOL_ERROR',
        'qualified GHDL binary is not executable', '/tool_profile/binary')
        unless -x $binary_abs;
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_TOOL_ERROR',
        'official GHDL archive byte size differs from the selected release asset',
        '/tool_profile/archive_bytes')
        unless (-s $archive_abs) == $ARCHIVE_BYTES;
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_TOOL_ERROR',
        'official GHDL archive digest differs from the selected release asset',
        '/tool_profile/archive_sha256')
        unless _file_sha256($archive_abs) eq $ARCHIVE_SHA256;
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_TOOL_ERROR',
        'materialized GHDL binary digest differs from the qualified profile',
        '/tool_profile/binary_sha256')
        unless _file_sha256($binary_abs) eq $BINARY_SHA256;

    my $materialization =
        FSM::VIAL::Backend::OSVVM2026_05Materialization->verify({
            dependency_root => $OSVVM_ROOT,
        });
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_PROVIDER_ERROR',
        $materialization->{diagnostics}[0]{message}, '/provider_profile')
        unless $materialization->{ok};
    my $materialization_digest =
        sha256_hex($JSON->encode($materialization->{manifest}));

    my @source_set;
    for my $rel (@GENERATED_SOURCE) {
        my $abs = _repo_path($repo_root, $rel);
        _regular_same_volume($abs, $rel, $root_stat[0]);
        push @source_set, {
            relpath => $rel,
            bytes => 0 + (-s $abs),
            sha256 => _file_sha256($abs),
        };
    }
    my $identity_input = {
        schema => $SCHEMA,
        backend_profile => $PROFILE,
        archive_sha256 => $ARCHIVE_SHA256,
        binary_sha256 => $BINARY_SHA256,
        version_output => $VERSION_OUTPUT,
        osvvm_root_commit => $materialization->{manifest}{root_commit},
        osvvm_root_tree => $materialization->{manifest}{root_tree},
        materialization_digest => $materialization_digest,
        osvvm_source_order => \@OSVVM_SOURCE,
        common_source_order => \@COMMON_SOURCE,
        source_set => \@source_set,
    };
    my $digest = sha256_hex($JSON->encode($identity_input));
    my $qualification_id = "qualification/$digest";
    my $stage_rel = ".artifacts/tmp/vial-osvvm-ghdl-qualification/$digest";
    my $stage_abs = _repo_path($repo_root, $stage_rel);
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_COLLISION',
        "qualification staging root '$stage_rel' already exists",
        '/cleanup/staging_identity')
        if -e $stage_abs || -l $stage_abs;

    my $execution_plan =
        FSM::VIAL::ArchitectureScaleOSVVMRuntimeExecutionPlan
            ->_qualification_plan({staging_identity => $stage_rel});
    my $reports_rel = "$stage_rel/provider_reports";
    my $settings_rel = $execution_plan->{generated_settings_relpath};
    my $resource = $execution_plan->{resource_controls};
    my @provider_commands = map { [@$_] }
        @{$execution_plan->{commands}{provider_analyze}};
    my @version_command = @{$execution_plan->{commands}{version}};
    my @analyze_generated =
        @{$execution_plan->{commands}{analyze_generated}};
    my @elaborate_fixture =
        @{$execution_plan->{commands}{elaborate_fixture}};
    my @run_fixture = @{$execution_plan->{commands}{run_fixture}};
    my @elaborate_probe =
        @{$execution_plan->{commands}{elaborate_provider_probe}};
    my @run_probe = @{$execution_plan->{commands}{run_provider_probe}};

    my @lifecycle_source_relpaths = (
        (map { $_->[-1] }
            grep { $_->[-1] ne $settings_rel } @provider_commands),
        @GENERATED_SOURCE,
    );
    my @lifecycle_source_set;
    for my $rel (@lifecycle_source_relpaths) {
        my $abs = _repo_path($repo_root, $rel);
        _regular_same_volume($abs, $rel, $root_stat[0]);
        push @lifecycle_source_set, {
            relpath => $rel,
            bytes => 0 + (-s $abs),
            sha256 => _file_sha256($abs),
        };
    }
    my $lifecycle_source_identity = 'source/'
        . sha256_hex($JSON->encode(\@lifecycle_source_set));
    my $lifecycle_commands = {
        schema => 'fsmgen.vial_ghdl_lifecycle_osvvm_command_plan.v2',
        schema_version => 2,
        version => \@version_command,
        provider_analyze => \@provider_commands,
        analyze_generated => \@analyze_generated,
        elaborate_fixture => \@elaborate_fixture,
        elaborate_provider_probe => \@elaborate_probe,
        run_fixture => \@run_fixture,
        run_provider_probe => \@run_probe,
        generated_settings => {
            relpath => $settings_rel,
            content => $execution_plan->{generated_settings_content},
            bytes => bytes::length(
                $execution_plan->{generated_settings_content},
            ),
            sha256 => sha256_hex(
                $execution_plan->{generated_settings_content},
            ),
        },
        libraries => _clone($execution_plan->{libraries}),
        provider_reports => [map {{
            name => $_, relpath => "$reports_rel/$_",
        }} @PROVIDER_REPORT],
        resource_controls => _clone($resource),
    };
    my $lifecycle_request = {
        repo_root => $repo_root,
        provider => {
            root => $GHDL_ROOT,
            archive => $GHDL_ARCHIVE,
            archive_bytes => $ARCHIVE_BYTES,
            archive_sha256 => $ARCHIVE_SHA256,
            binary => $GHDL_BINARY,
            binary_sha256 => $BINARY_SHA256,
            version_output => $VERSION_OUTPUT,
        },
        source_set => \@lifecycle_source_set,
        source_identity => $lifecycle_source_identity,
        emission_identity => 'emission/' . sha256_hex($JSON->encode({
            qualification_id => $qualification_id,
            source_identity => $lifecycle_source_identity,
            commands => $lifecycle_commands,
        })),
        commands => $lifecycle_commands,
        validation => {
            expected_record_counts => {
                header => 1, scenario_start => 2, events => 2, samples => 35,
                expectations => 2, scoreboards => 2, coverage => 28, faults => 2,
                scenario_end => 2, footer => 1,
            },
            %$TRACE_AUTHORITY,
            run_repetitions => 2,
        },
        storage_context => {
            schema => 'fsmgen.vial_ghdl_lifecycle_storage.v1',
            schema_version => 1,
            mode => 'osvvm_qualification',
            staging_identity => $stage_rel,
            containment => 'lifecycle_process_group',
        },
    };
    my $current = FSM::VIAL::Backend::GHDLLifecycle->begin_session(
        $lifecycle_request,
    );
    _lifecycle_succeeded($current, 'admission');
    for my $target (qw(
        prepared tool_verified analyzed elaborated ran trace_validated
        result_produced assembled
    )) {
        $current = FSM::VIAL::Backend::GHDLLifecycle->advance_session({
            %$lifecycle_request, handle => $current->{handle},
        });
        _lifecycle_succeeded($current, $target);
    }
    my $finished = FSM::VIAL::Backend::GHDLLifecycle->finish_session({
        %$lifecycle_request, handle => $current->{handle},
    });
    _lifecycle_succeeded($finished, 'cleaned');
    my $assembled = $finished->{assembled_result};
    my ($fixture_one, $fixture_two) = map {{output => $_}}
        @{$assembled->{fixture_runtime_outputs}};
    my ($probe_one, $probe_two) = map {{output => $_}}
        @{$assembled->{provider_runtime_outputs}};
    my ($reports_one, $reports_two) = @{$assembled->{provider_reports}};
    my $provider_output_bytes =
        $assembled->{provider_compiler_output_bytes};
    my $settings_sha256 = $assembled->{generated_settings_sha256};
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_CLEANUP_ERROR',
        "qualification staging root '$stage_rel' remains after execution", '/cleanup')
        if -e $stage_abs || -l $stage_abs;

    my $post_materialization =
        FSM::VIAL::Backend::OSVVM2026_05Materialization->verify({
            dependency_root => $OSVVM_ROOT,
        });
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_PROVIDER_ERROR',
        $post_materialization->{diagnostics}[0]{message}, '/provider_profile')
        unless $post_materialization->{ok};
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_PROVIDER_ERROR',
        'provider materialization identity changed during qualification',
        '/provider_profile/materialization_manifest_sha256')
        unless sha256_hex($JSON->encode($post_materialization->{manifest}))
            eq $materialization_digest;

    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_DETERMINISM_ERROR',
        'fixture runtime output differs across identical executions',
        '/deterministic_rerun/fixture_stdout_identical')
        unless $fixture_one->{output} eq $fixture_two->{output};
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_DETERMINISM_ERROR',
        'provider runtime output differs across identical executions',
        '/deterministic_rerun/provider_stdout_identical')
        unless $probe_one->{output} eq $probe_two->{output};
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_DETERMINISM_ERROR',
        'supplementary OSVVM reports differ across identical executions',
        '/deterministic_rerun/provider_reports_identical')
        unless $JSON->encode($reports_one) eq $JSON->encode($reports_two);

    my $runtime = _validate_runtime_output($fixture_one->{output});
    my $provider_reports = _validate_provider_evidence(
        $probe_one->{output}, $reports_one);
    my $report = {
        schema => $SCHEMA,
        schema_version => 1,
        qualification_id => $qualification_id,
        task_id => $TASK_ID,
        status => 'qualified',
        backend_profile => $PROFILE,
        tool_profile => {
            tool_name => 'ghdl',
            qualified_version => '6.0.0',
            backend => 'llvm_jit',
            build_commit => 'e589c698c351369ac5bcfe7abe1f1152ac5d4727',
            language_standard => 'IEEE 1076-2008',
            standard_option => '--std=08',
            binary => $GHDL_BINARY,
            binary_sha256 => $BINARY_SHA256,
            archive => $GHDL_ARCHIVE,
            archive_bytes => $ARCHIVE_BYTES,
            archive_sha256 => $ARCHIVE_SHA256,
            version_output => $VERSION_OUTPUT,
            selection_status => 'executed_qualified',
        },
        provider_profile => {
            provider => 'OSVVM',
            version => '2026.05',
            release_tag => '2026.05',
            dependency_root => $OSVVM_ROOT,
            root_commit => $materialization->{manifest}{root_commit},
            root_tree => $materialization->{manifest}{root_tree},
            repository_count => $materialization->{manifest}{materialization}{repository_count},
            recursive_gitlink_count => $materialization->{manifest}{materialization}{gitlink_count},
            licence_file_count => $materialization->{manifest}{license_notice_summary}{license_file_count},
            notice_file_count => $materialization->{manifest}{license_notice_summary}{notice_file_count},
            documentation_licence_notice_absence_explicit => JSON::PP::true,
            materialization_manifest_sha256 => $materialization_digest,
            selection_status => 'executed_qualified',
        },
        source_set => \@source_set,
        provider_compilation => {
            status => 'passed',
            basis => 'exact OSVVM 2026.05 project-file order resolved for GHDL VHDL-2008',
            osvvm_library => 'osvvm',
            common_library => 'osvvm_common',
            osvvm_source_order => \@OSVVM_SOURCE,
            common_source_order => \@COMMON_SOURCE,
            osvvm_analyzed_source_count => scalar(@OSVVM_SOURCE),
            common_analyzed_source_count => scalar(@COMMON_SOURCE),
            total_analyzed_source_count => scalar(@provider_commands),
            generated_settings_sha256 => $settings_sha256,
            compiler_output_bytes => 0 + $provider_output_bytes,
        },
        commands => {
            provider_analyze => [map { _command_record($_) } @provider_commands],
            analyze_generated => _command_record(\@analyze_generated),
            elaborate_fixture => _command_record(\@elaborate_fixture),
            run_fixture => _command_record(\@run_fixture),
            elaborate_provider_probe => _command_record(\@elaborate_probe),
            run_provider_probe => _command_record(\@run_probe),
        },
        execution => {
            provider_analysis => 'passed',
            adapter_analysis => 'passed',
            generated_fixture_analysis => 'passed',
            fixture_elaboration => 'passed',
            fixture_execution => 'passed',
            provider_probe_elaboration => 'passed',
            provider_probe_execution => 'passed',
        },
        trace => $runtime->{trace},
        result => $runtime->{result},
        deterministic_rerun => {
            status => 'passed',
            fixture_stdout_identical => JSON::PP::true,
            provider_stdout_identical => JSON::PP::true,
            provider_reports_identical => JSON::PP::true,
            fixture_stdout_sha256 => sha256_hex($fixture_one->{output}),
            provider_stdout_sha256 => sha256_hex($probe_one->{output}),
        },
        portable_result_parity => $runtime->{portable_result_parity},
        supplementary_provider_reports => $provider_reports,
        capability_support => {
            status => 'qualified_private_fixture_profile_not_public_api',
            profile => $PROFILE,
            exercised_runtime_mappings => [qw(
                advanced_coverage advanced_data_structure advanced_randomization
                advanced_reporting advanced_scoreboard advanced_synchronization
            )],
            analysis_only_mappings => ['verification_component_adapter'],
            portable_semantic_authority => 'unchanged',
            normalized_result_authority => 'fsmgen.verification_result_manifest.v1',
            product_support => 'qualified_private_fixture_profile_not_public_api',
        },
        resource_controls => {
            outer_guard => $resource->{outer_guard},
            descendant_rss_limit_mib =>
                $resource->{descendant_rss_limit_mib},
            host_occupied_cutoff_percent =>
                $resource->{host_occupied_cutoff_percent},
            version_timeout_seconds => $resource->{version_timeout_seconds},
            provider_analysis_timeout_seconds_per_source =>
                $resource->{provider_analysis_timeout_seconds_per_source},
            generated_analysis_timeout_seconds =>
                $resource->{generated_analysis_timeout_seconds},
            elaboration_timeout_seconds =>
                $resource->{elaboration_timeout_seconds},
            execution_timeout_seconds =>
                $resource->{execution_timeout_seconds},
            maximum_fixture_output_bytes =>
                $resource->{fixture_capture_limit_bytes},
            maximum_provider_output_bytes =>
                $resource->{provider_capture_limit_bytes},
        },
        cleanup => {
            staging_identity => $stage_rel,
            state => 'completed_removed',
            removed => JSON::PP::true,
            same_volume => JSON::PP::true,
            provider_tree_clean => JSON::PP::true,
        },
        limitations => [
            'qualification covers one bounded generated single-unit single-clock fixture and one supplementary adapter probe',
            'the OSVVM Common address-bus transaction type is analyzed through the adapter but no OSVVM verification-component transaction executes',
            'OSVVM reports are supplementary evidence and do not redefine portable scheduling, comparison, coverage meaning, trace, normalized results, or parity',
            'the pinned Documentation repository has no tracked licence or notice file; no licence coverage is inferred',
            'UVVM, PSL, complete VHDL-2008, another simulator, mixed-language execution, legacy observation-package analysis, general parity, and scale are not inferred',
        ],
    };
    _closed_record($report, \@REPORT_KEYS, 'qualification report');
    my $content = _json_text($report);
    return _result({
        ok => JSON::PP::true,
        status => 'qualified',
        report => $report,
        content => $content,
        diagnostics => [],
        cleanup => _clone($report->{cleanup}),
    });
}

sub _validate_provider_evidence($output, $reports) {
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_PROVIDER_RUNTIME_ERROR',
        'provider probe did not produce its exact deterministic pass marker',
        '/supplementary_provider_reports/runtime_marker')
        unless $output =~ /FSMGEN_VIAL_OSVVM_PROVIDER_PROBE_V1 pass random=3/;
    my %by_name = map { $_->{name} => $_ } @$reports;
    my $run = $by_name{'OsvvmRun.yml'}{content};
    my $alerts = $by_name{'AlertLogTop_alerts.yml'}{content};
    my $coverage = $by_name{'AlertLogTop_cov.yml'}{content};
    my $scoreboard = $by_name{'AlertLogTop_sb_slv.yml'}{content};
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_PROVIDER_REPORT_ERROR',
        'OSVVM run summary does not record the exact passing result',
        '/supplementary_provider_reports/run_summary')
        unless $run =~ /FunctionalCoverage: 25\.00/
            && $run =~ /Status: PASSED/
            && $run =~ /TotalErrors: 0/
            && $run =~ /PassedCount: 3/
            && $run =~ /AffirmCount: 3/;
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_PROVIDER_REPORT_ERROR',
        'OSVVM alert report does not record three clean affirmations',
        '/supplementary_provider_reports/alerts')
        unless $alerts =~ /Status: PASSED/
            && $alerts =~ /TotalErrors: 0/
            && $alerts =~ /PassedCount: 3/
            && $alerts =~ /AffirmCount: 3/;
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_PROVIDER_REPORT_ERROR',
        'OSVVM coverage report does not record the deterministic four-bin sample',
        '/supplementary_provider_reports/coverage')
        unless $coverage =~ /Coverage: 25\.00/
            && $coverage =~ /Name: "fsmgen_adapter_coverage"/
            && $coverage =~ /TotalCovCount: 1/
            && $coverage =~ /TotalCovGoal: 4/;
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_PROVIDER_REPORT_ERROR',
        'OSVVM scoreboard report does not record one clean checked item',
        '/supplementary_provider_reports/scoreboard')
        unless $scoreboard =~ /Name:\s+"fsmgen_adapter_scoreboard"/
            && $scoreboard =~ /ErrorCount:\s+0/
            && $scoreboard =~ /ItemsChecked:\s+1/
            && $scoreboard =~ /FifoCount:\s+0/;
    return {
        status => 'passed_supplementary_only',
        runtime_marker => 'FSMGEN_VIAL_OSVVM_PROVIDER_PROBE_V1 pass random=3',
        report_count => scalar(@$reports),
        reports => [map {
            +{name => $_->{name}, bytes => $_->{bytes}, sha256 => $_->{sha256}}
        } @$reports],
        alert_status => 'passed_three_affirmations_zero_errors',
        coverage_status => 'passed_one_of_four_bins_25_percent',
        scoreboard_status => 'passed_one_checked_item_zero_errors',
        semantic_authority => 'supplementary_not_normalized_result',
    };
}

sub _validate_runtime_output($output) {
    my @trace;
    my @result;
    for my $line (split /\r?\n/, $output) {
        push @trace, $line
            if index($line, "FSMGEN_VIAL_TRACE_V2\t") == 0;
        push @result, substr($line, length("FSMGEN_VIAL_RESULT_V1\t"))
            if index($line, "FSMGEN_VIAL_RESULT_V1\t") == 0;
    }
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_TRACE_ERROR',
        'runtime must emit exactly one normalized result record', '/result')
        unless @result == 1;
    my $decoded_result = _decode_json($result[0], '/result');
    my $validated = FSM::VIAL::Backend::VHDLPortableTraceValidator->validate({
        trace_text => join("\n", @trace) . "\n",
        expected_plan_id => $TRACE_AUTHORITY->{expected_plan_id},
        expected_run_ids => $TRACE_AUTHORITY->{expected_run_ids},
        expected_observation_catalog =>
            $TRACE_AUTHORITY->{expected_observation_catalog},
        expected_record_counts => {
            header => 1, scenario_start => 2, events => 2, samples => 35,
            expectations => 2, scoreboards => 2, coverage => 28, faults => 2,
            scenario_end => 2, footer => 1,
        },
    });
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_TRACE_ERROR',
        $validated->{diagnostics}[0]{message}, $validated->{diagnostics}[0]{path})
        unless $validated->{ok};
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_RESULT_ERROR',
        'runtime normalized result did not pass', '/result/status')
        unless ($decoded_result->{schema} // '') eq 'fsmgen.verification_result_manifest.v1'
            && ($decoded_result->{schema_version} // 0) == 1
            && ($decoded_result->{status} // '') eq 'pass';
    my $projection = $decoded_result->{parity_projection};
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_PARITY_ERROR',
        'runtime result has no exact two-scenario VHDL outcome projection',
        '/result/parity_projection')
        unless ref($projection) eq 'HASH'
            && ($projection->{schema} // '') eq 'fsmgen.vial_vhdl_portable_outcomes.v1'
            && ref($projection->{outcomes}) eq 'ARRAY'
            && @{$projection->{outcomes}} == 2;
    my @expected = (
        {
            scenario => 'success', bus_accepts => 1, ready_low_cycles => 15,
            response_error_cycles => 0, nonzero_read_data_cycles => 0,
            final_ready => 1, final_response => 0,
            final_read_data_bits => '0' x 32,
            storage_bits => '11001010111111101011101010111110', status => 'pass',
        },
        {
            scenario => 'unsupported_size', bus_accepts => 1,
            response_error_cycles => 2, nonzero_read_data_cycles => 0,
            final_ready => 1, final_response => 0,
            final_read_data_bits => '0' x 32, storage_bits => '0' x 32,
            status => 'pass',
        },
    );
    my @compared;
    for my $index (0, 1) {
        my $actual = $projection->{outcomes}[$index];
        for my $key (sort keys %{$expected[$index]}) {
            my $actual_value = $key eq 'scenario'
                ? (($actual->{scenario_id} // '') =~ /::scenario::([^:]+)\z/)[0]
                : $actual->{$key};
            _throw('VIAL_OSVVM_GHDL_QUALIFICATION_PARITY_ERROR',
                "OSVVM-qualified VHDL outcome differs from the portable-SystemVerilog oracle at scenario $index field $key",
                "/portable_result_parity/outcomes/$index/$key")
                unless defined($actual_value)
                    && $JSON->encode($actual_value)
                        eq $JSON->encode($expected[$index]{$key});
            push @compared, "/outcomes/$index/$key";
        }
    }
    return {
        trace => {
            schema => $validated->{trace}{schema},
            schema_version => $validated->{trace}{schema_version},
            status => 'closed_validated',
            record_count => $validated->{trace}{record_count},
            record_counts => _clone($validated->{trace}{record_counts}),
            header_count => 1,
            footer_count => 1,
            scenario_start_count => $validated->{trace}{record_counts}{scenario_start},
            scenario_end_count => $validated->{trace}{record_counts}{scenario_end},
            sample_count => $validated->{trace}{record_counts}{samples},
            observation_catalog => _clone($validated->{trace}{observation_catalog}),
            trace_sha256 => $validated->{trace}{trace_sha256},
            stdout_sha256 => sha256_hex($output),
        },
        result => {
            schema => $decoded_result->{schema},
            schema_version => 0 + $decoded_result->{schema_version},
            status => $decoded_result->{status},
            plan_id => $decoded_result->{plan_id},
            outcomes => _clone($projection->{outcomes}),
            result_record_sha256 => sha256_hex($result[0]),
        },
        portable_result_parity => {
            status => 'equivalent',
            eligible => JSON::PP::true,
            equivalent => JSON::PP::true,
            oracle => 't/1559-vial-ahb-runtime-parity.t',
            oracle_profile => 'sv_portable_verilator/5.046',
            portable_vhdl_qualification =>
                'vial/qualification/vhdl_portable_ghdl/ghdl-6.0.0-qualification.json',
            compared_paths => \@compared,
            mismatches => [],
            exclusions => [
                'unsupported_size.ready_low_cycles is not part of the qualified handwritten AHB oracle',
                'supplementary OSVVM reports have no portable-SystemVerilog parity meaning',
            ],
        },
    };
}

sub _command_record($argv) {
    return {
        working_directory => '.',
        argv => _clone($argv),
        command_digest => sha256_hex($JSON->encode($argv)),
        execution_status => 'passed',
    };
}

sub _lifecycle_succeeded($result, $phase) {
    return 1 if $result->{ok};
    my $diagnostic = $result->{diagnostics}[0] // {};
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_LIFECYCLE_ERROR',
        "GHDL lifecycle $phase failed: "
            . ($diagnostic->{message} // 'unknown lifecycle failure'),
        $diagnostic->{path} // "/execution/$phase");
}

sub _regular_same_volume($path, $identity, $root_device) {
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_PATH_ERROR',
        "required path '$identity' is not one regular non-symlink file", '/path')
        unless -f $path && !-l $path;
    my @stat = stat($path);
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_PATH_ERROR',
        "required path '$identity' is not on the repository filesystem volume", '/path')
        unless @stat && $stat[0] == $root_device;
}

sub _directory_same_volume($path, $identity, $root_device) {
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_PATH_ERROR',
        "required path '$identity' is not one non-symlink directory", '/path')
        unless -d $path && !-l $path;
    my @stat = stat($path);
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_PATH_ERROR',
        "required path '$identity' is not on the repository filesystem volume", '/path')
        unless @stat && $stat[0] == $root_device;
}

sub _repo_path($root, $relative) {
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_PATH_ERROR',
        'qualification path is not a safe repository-relative identity', '/path')
        unless _safe_relpath($relative);
    return File::Spec->catfile($root, split m{/}, $relative);
}

sub _safe_relpath($value) {
    return 0 unless defined($value) && !ref($value) && length($value)
        && $value !~ m{(?:\A/|\A~|\A[A-Za-z]:|://|\\|\x00)};
    return 0 if grep { $_ eq '' || $_ eq '.' || $_ eq '..' }
        split m{/}, $value, -1;
    return 1;
}

sub _file_sha256($path) {
    open my $fh, '<:raw', $path
        or _throw('VIAL_OSVVM_GHDL_QUALIFICATION_HOST_ERROR',
            'cannot read one qualification input', '/path');
    my $sha = Digest::SHA->new(256);
    $sha->addfile($fh);
    close $fh;
    return $sha->hexdigest;
}

sub _decode_json($text, $path) {
    my $value = eval { JSON::PP->new->decode($text) };
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_RESULT_ERROR',
        'runtime emitted malformed JSON evidence', $path)
        unless defined($value) && !$@ && ref($value) eq 'HASH' && !blessed($value);
    return $value;
}

sub _json_text($value) {
    my $text = JSON::PP->new->ascii->canonical->pretty->encode($value);
    $text .= "\n" unless $text =~ /\n\z/;
    return $text;
}

sub _closed_record($value, $keys, $label) {
    my %expected = map { $_ => 1 } @$keys;
    confess "$label has unknown key(s)" if grep { !$expected{$_} } keys %$value;
    confess "$label is missing key(s)" if grep { !exists($value->{$_}) } @$keys;
}

sub _require_exact_keys($value, $keys, $label) {
    my %expected = map { $_ => 1 } @$keys;
    my @unknown = sort grep { !$expected{$_} } keys %$value;
    my @missing = grep { !exists($value->{$_}) } @$keys;
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_INVOCATION_ERROR',
        "$label has unknown key '$unknown[0]'", '/') if @unknown;
    _throw('VIAL_OSVVM_GHDL_QUALIFICATION_INVOCATION_ERROR',
        "$label is missing key '$missing[0]'", '/') if @missing;
}

sub _exact_class($class, $method) {
    confess __PACKAGE__ . "->$method requires the exact class invocant\n"
        unless defined($class) && !ref($class) && $class eq __PACKAGE__;
}

sub _throw($code, $message, $path) {
    die bless {code => $code, message => $message, path => $path},
        'FSM::VIAL::Backend::VHDLOSVVMGHDLQualification::Failure';
}

sub _failure($code, $message, $path) {
    return _result({
        ok => JSON::PP::false,
        status => 'error',
        report => undef,
        content => undef,
        diagnostics => [{
            code => $code,
            severity => 'error',
            message => $message,
            path => $path,
        }],
        cleanup => {
            staging_identity => undef,
            state => 'not_started',
            removed => JSON::PP::false,
            same_volume => JSON::PP::false,
            provider_tree_clean => JSON::PP::false,
        },
    });
}

sub _result($value) {
    _closed_record($value, \@RESULT_KEYS, 'qualification result');
    return _clone($value);
}

sub _sanitize_exception($error) {
    my $message = defined($error) ? "$error" : 'unknown qualification host failure';
    $message =~ s/\s+at\s+\S+\s+line\s+\d+\.?\s*\z//s;
    $message =~ s{(?:[A-Za-z]:)?[/\\][^\s:]+[/\\][^\s:]+}{<host-path>}g;
    $message =~ s/[\r\n]+/ /g;
    $message =~ s/\s+/ /g;
    $message =~ s/\A\s+|\s+\z//g;
    return length($message) ? $message : 'unknown qualification host failure';
}

sub _clone($value) {
    return undef unless defined $value;
    return $value ? JSON::PP::true : JSON::PP::false
        if blessed($value) && $value->isa('JSON::PP::Boolean');
    return {map { $_ => _clone($value->{$_}) } sort keys %$value}
        if ref($value) eq 'HASH';
    return [map { _clone($_) } @$value] if ref($value) eq 'ARRAY';
    confess 'qualification projection contains an unsupported reference' if ref($value);
    return $value;
}

package FSM::VIAL::Backend::VHDLOSVVMGHDLQualification::Failure;

use overload '""' => sub {
    $_[0]{message} // 'OSVVM GHDL qualification failure'
}, fallback => 1;

1;
