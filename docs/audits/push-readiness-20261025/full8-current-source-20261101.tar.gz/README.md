# FSMGen

FSMGen targets full digital-chip source authoring through IAL1/IAL2.
It compiles bounded state-machine and intent sources to synthesizable HDL
with explicit semantics and reviewable lowering.

For exact current coverage, use the [mdBook](docs/book/src/SUMMARY.md) and
capability manifest; parser acceptance alone does not imply support.

## What FSMGen does

FSMGen accepts three intent layers:

| Layer | Public sources | Responsibility |
| --- | --- | --- |
| IAL2 | `.ppif`, with bounded `.axi`, `.apb`, and `.ahb` profile aliases | Protocol and platform intent |
| IAL1 | `.isf` | Actors, transactions, scheduling, control flow, priorities, and verification intent |
| IAL0 | `.fsm` | Explicit cycle-authored state machines and decision trees |

Lowering is always reviewable and ordered:

```text
IAL2 -> IAL1 -> IAL0 -> SystemVerilog / Verilog / bounded VHDL
```

IAL2 never bypasses IAL1. The public formats and their observable behavior are
backend-language-neutral contracts; the current Perl 5 implementation is the
reference implementation, not the definition of those layers. See decisions
[0014](docs/decisions/0014-protocol-platform-intent-surface-and-layered-lowering.md),
[0015](docs/decisions/0015-ial2-profile-extensions-are-vocabulary-aliases.md),
and
[0018](docs/decisions/0018-ial-contracts-are-backend-language-neutral.md).

The primary backend is SystemVerilog. Verilog uses the compatible generation
path, while VHDL intentionally supports only documented, fail-closed subsets.
The precise backend and language boundaries live in
[Backends and Validation](docs/book/src/14-feature-backlog.md#backends-and-validation).

## Requirements

- Perl 5.20 or newer for the main implementation.
- mdBook to build or serve the user manual.
- Python 3.9+ on macOS/Linux for the RAM guard and book; Pod::Simple 3.42+ for POD.
- Verilator and Yosys only when `--verify-hdl` external SystemVerilog
  validation is requested.

Run commands from the repository root. Project-owned outputs, logs, caches,
fixtures, and temporary workspaces must stay on the repository filesystem
volume; see [PROJECT_DATA_LOCALITY.md](PROJECT_DATA_LOCALITY.md).

## Quick start

Inspect the CLI and validate a shipped direct FSM without writing HDL:

```bash
./bin/fsmgen --help
./bin/fsmgen --quiet --strict --check --json fsm/ahb_lite_subordinate.fsm
```

Generate SystemVerilog:

```bash
./bin/fsmgen --strict fsm/ahb_lite_subordinate.fsm
./bin/fsmgen --strict --output .artifacts/sv/ahb_lite_subordinate.sv fsm/ahb_lite_subordinate.fsm
```

Without `--output`, generated HDL goes to the git-ignored
`.artifacts/<language>/` tree. Explicit output paths must also remain inside
the repository.

Preview higher-level lowering without writing HDL:

```bash
./bin/fsmgen --quiet --strict --emit-schedule-json isf/i2c_master.isf
./bin/fsmgen --quiet --strict --emit-schedule-json ppif/axi_aw_valid_ready.ppif
```

Inspect capabilities and the bounded VIAL regression gate:

```bash
./bin/fsmgen --capability-manifest
./bin/fsmgen vial check vial/ahb_subordinate_base_output_arbitration.vial
./bin/ci-regression vial-gate --dry-run --no-book
```

Common modes are discoverable through `./bin/fsmgen --help`:

| Need | Option |
| --- | --- |
| Check without writing HDL | `--check --json` |
| Emit normalized semantics | `--emit-semantic-json` |
| Preview IAL1/IAL2 scheduling | `--emit-schedule-json` |
| Select HDL | `--language systemverilog|verilog|vhdl` |
| Validate generated SystemVerilog externally | `--verify-hdl` |
| Emit a supported verification artifact | `--emit-verification-output TARGET --verification-outdir DIR` |
| Supported/VIAL surfaces | `--capability-manifest`; `vial capabilities|check|inspect|format|plan|run` |
| Enable deterministic trace output | `--trace-verbosity LEVEL --trace-log FILE` |

FSMGen provides `bin/fsmgen-mcp`, a read-only local JSON-RPC stdio
adapter over the semantic-introspection contract. Its supported resources,
tools, safety boundary, and examples are documented in
[Extensions and Embedding](docs/book/src/11-extensions-and-embedding.md).

## Documentation

The mdBook is the manual:

- [Introduction](docs/book/src/00-introduction.md)
- [Your First FSM](docs/book/src/01-first-fsm.md)
- [Language Basics](docs/book/src/02-language-basics.md)
- [Cookbook](docs/book/src/12-cookbook.md)
- [Perl API Reference](docs/book/src/11a-perl-api-reference.md)
- [HIAL/VIAL Verification](docs/book/src/16d-hial-vial-verification-architecture.md)
- [Contents](docs/book/src/SUMMARY.md)

Build or serve from the repository:

```bash
mdbook build docs/book
cd docs/book
mdbook serve
```

Focused references outside the book provide narrower contracts:

| Topic | Canonical reference |
| --- | --- |
| Progressive language and product guide | [docs/book/src/SUMMARY.md](docs/book/src/SUMMARY.md) |
| IAL1 syntax and semantics | [docs/ISF_SPEC.md](docs/ISF_SPEC.md) |
| Downstream IAL1/IAL2 integration | [docs/ISF_DOWNSTREAM_INTEGRATION_SPEC.md](docs/ISF_DOWNSTREAM_INTEGRATION_SPEC.md) |
| Composition boundary | [docs/COMPOSITION_SCOPE.md](docs/COMPOSITION_SCOPE.md) |
| Typed extension boundary | [docs/EXTENSION_MODEL.md](docs/EXTENSION_MODEL.md) |
| Supported sample corpus | [docs/REGRESSION_CORPUS.md](docs/REGRESSION_CORPUS.md) |
| Live CLI import architecture | [docs/BIN_FSMGEN_IMPORT_TREE.md](docs/BIN_FSMGEN_IMPORT_TREE.md) |
| Change/claim evidence | [TASK_ACCEPTANCE.md](TASK_ACCEPTANCE.md), [CLAIM_VERIFICATION.md](CLAIM_VERIFICATION.md) |

Generated classification: [focused/ancillary document index](docs/index/FOCUSED_DOCUMENTS.md).

## Where current truth lives

Find current state here:

| Question | Source of truth |
| --- | --- |
| What does shipped behavior do? | [mdBook](docs/book/src/SUMMARY.md) |
| What capabilities are reported now? | `./bin/fsmgen --capability-manifest` |
| What is the high-level direction? | [ROADMAP_V2.md](ROADMAP_V2.md) |
| What is active and what comes next? | [MEMORY.md](MEMORY.md), then [docs/TASK_TREE.md](docs/TASK_TREE.md) |
| What owns a task and its evidence? | The matching tree under [docs/tasks/](docs/tasks/) |
| Why was a cross-cutting choice made? | [docs/decisions/INDEX.md](docs/decisions/INDEX.md) |
| Is a fact already established? | [Query](knowledge-map/README.md) |
| What changed in a work unit? | The owning task under [docs/tasks/](docs/tasks/), then `git log --grep=<UNIT-ID>` |
| How do I diagnose a failure? | [TOOLBOX.md](TOOLBOX.md) |
| Which repository rules are enforced? | [DOCTRINE_ENFORCEMENT.md](DOCTRINE_ENFORCEMENT.md) |

`DEVELOPMENT_NOTES.md` changes only for durable engineering rationale.
Decisions [0047](docs/decisions/0047-changes-history-is-task-trees-and-git.md),
[0048](docs/decisions/0048-achievement-history-is-task-trees-book-and-git.md),
and [0049](docs/decisions/0049-roadmap-status-is-roadmap-task-trees-memory-and-git.md)
retire the former changelog and status journals; decision 0046 keeps the
rationale-ledger owner.

## Repository orientation

| Path | Purpose |
| --- | --- |
| `bin/fsmgen` | Main CLI |
| `bin/fsmgen-mcp` | Read-only semantic-introspection adapter |
| `perl/FSM/` | Reference parser, lowering, IR, generation, reporting, and support implementation |
| `fsm/`, `isf/`, `ppif/` | Public samples and support-accounted source corpus |
| `t/` | Perl regression and contract tests |
| `docs/book/` | mdBook source |
| `docs/tasks/` | Task-tree work memory |
| `docs/decisions/` | Durable decision records |
| `docs/knowledge/` | Dated fact cards indexed by `KNOWLEDGE_MAP.md` |
| `scripts/` | Doctrine, validation, resource-guard, and maintenance tooling |
| `.artifacts/` | Git-ignored, repository-local generated output |

For the transitive entrypoint graph and package ownership, see
[docs/BIN_FSMGEN_IMPORT_TREE.md](docs/BIN_FSMGEN_IMPORT_TREE.md).

## Development workflow

Before changing code, tests, sources, generated artifacts, configuration, or
durable documentation:

1. Read [AGENTS.md](AGENTS.md), [MEMORY_ARCHITECTURE.md](MEMORY_ARCHITECTURE.md),
   [DOCTRINE_ENFORCEMENT.md](DOCTRINE_ENFORCEMENT.md), and
   [TOOLBOX.md](TOOLBOX.md).
2. Resume from [MEMORY.md](MEMORY.md), the active task tree, and only the
   relevant decision/fact records.
3. Ensure an exact task-tree leaf owns the change before making it.
4. Keep code, live references, task-tree evidence, and mdBook behavior
   documentation synchronized in the same slice.
5. Complete and commit each slice through [COMMIT.md](COMMIT.md) before
   switching tasks.

Activate the repository hooks once per clone:

```bash
git config core.hooksPath .githooks
```

Validation entrypoints:

```bash
scripts/check_doctrines.sh
./bin/ci-regression quick
./bin/ci-regression
prove -Iperl t/248-regression-corpus-accounting.t
mdbook build docs/book
```

Run broad or potentially heavy commands through the repository RAM guard:

```bash
scripts/run_with_ram_guard.sh -- ./bin/ci-regression
scripts/run_with_ram_guard.sh -- prove -Iperl t/248-regression-corpus-accounting.t
```

Use [SESSION_BOOTSTRAP.md](SESSION_BOOTSTRAP.md) for the full fresh-session
ritual. Paths recorded by the project must remain relative to the repository
root so the repository can move without invalidating its state.

## README maintenance

This file is a stable landing page, not a status board, implementation catalog,
or changelog. Change it only when the project objective, first-use path,
top-level architecture, or canonical navigation changes. Put feature detail in
the mdBook, work state in task trees, decisions in decision records, established
facts in the Knowledge Map, and history in git.

The bounded-entrypoint rationale is recorded in decision
[0021](docs/decisions/0021-readme-is-a-bounded-discovery-entrypoint.md). The
shareable, project-neutral guard and adoption checklist are tracked in
[README_POLICY.md](README_POLICY.md).

## License

FSMGen is licensed under the [Apache License 2.0](LICENSE).
