"""Shorten only the owned task-index frontier; never widen document allowances."""
import argparse
import re
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, 'docs/audits/raw-semantic-association-product-20261011')
from common import BASE as PRODUCT, OWNER, REVISION, canonical, git, identity, load, local, need, pin

BASE = Path('docs/audits/raw-semantic-association-product-gate-repair-20261011')
INDEX = Path('docs/TASK_TREE.md')
PUBLISHED = b'raw admission done; full-body candidates done; independent semantics next.'
PREVIOUS = b'raw admission done; full-body association next.'
OLD = b'task contained; ' + PUBLISHED
NEW = b'raw admitted; candidates done; semantic check next.'
NATIVE = r'''use strict; use warnings; use JSON::PP;
my @rows;
for my $path (@ARGV) {
    open my $fh, '<:raw', $path or die "open whole index width: $!";
    my ($bytes, $lines, $width) = (0, 0, 0);
    while (my $row = <$fh>) {
        $bytes += length($row);
        $lines += ($row =~ s/\n\z//);
        $row =~ s/\r\z//;
        $width = length($row) if length($row) > $width;
    }
    close $fh or die "close whole index width: $!";
    push @rows, {bytes => $bytes, lines => $lines, max_line_bytes => $width};
}
print JSON::PP->new->canonical->encode(\@rows), "\n";
'''


def write(name, raw):
    path = local(BASE / name, exists=False)
    need(not path.exists(), 'retain first complete index-width repair evidence')
    path.write_bytes(raw)


def metric(raw):
    return dict(bytes=len(raw), lines=raw.count(b'\n'), max_line_bytes=max(map(len, raw.split(b'\n')), default=0))


def check(before, after, failure, native):
    fixed = git('show', REVISION + ':' + str(INDEX))
    need(fixed.count(PREVIOUS) == 1 and before == fixed.replace(PREVIOUS, PUBLISHED, 1), 'whole fixed index and sole owned construction status publication')
    need(before.count(OLD) == 1 and after == before.replace(OLD, NEW, 1), 'whole index changes only the current frontier pointer')
    need(type(failure['status']) is int and failure['status'] == 1 and failure['command'] == ['scripts/check_live_document_size.sh'],
         'actual complete first size refusal')
    diagnostic = re.search(r'focused_documents transition debt exceeded its owned allowance: max line bytes is (\d+) \(> baseline (\d+) \+ growth (\d+)\)', failure['stderr'])
    need(diagnostic is not None, 'actual intended task-index width failure')
    width, baseline, growth = map(int, diagnostic.groups())
    measured = [metric(before), metric(after)]
    need(measured[0]['max_line_bytes'] == width > baseline + growth >= measured[1]['max_line_bytes']
         and measured[0]['lines'] == measured[1]['lines'], 'actual original refusal and bounded non-growing index repair')
    need(type(native['status']) is int and native['status'] == 0 and native['stderr'] == ''
         and __import__('json').loads(native['stdout']) == measured, 'whole separate native index byte/line/width parity')
    need(native['programme'] == NATIVE and native['command'] == ['perl', '-e', NATIVE, str(BASE / 'index-before.md'), str(BASE / 'index-after.md')],
         'complete actual independent index-width programme and invocation')
    return dict(before=pin(before), after=pin(after), metrics=measured, unchanged_bound=baseline + growth,
                failed_actual=pin(canonical(failure)), native_actual=pin(canonical(native)))


def catalog():
    return {p.name: identity(p) for p in sorted(BASE.iterdir()) if p.name != 'manifest.json'}


def main():
    import json
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify', action='store_true')
    args = parser.parse_args()
    if args.verify:
        before, after = (local(BASE / name).read_bytes() for name in ('index-before.md', 'index-after.md'))
        failure = json.loads(local(BASE / 'first-size-refusal.json').read_bytes())
        native = json.loads(local(BASE / 'native-width.json').read_bytes())
        proof = json.loads(local(BASE / 'proof.json').read_bytes())
        need(proof['qualification'] == check(before, after, failure, native)
             and json.loads(local(BASE / 'manifest.json').read_bytes()) == catalog(), 'whole sealed dated index-width repair')
    else:
        before = local(INDEX).read_bytes()
        need(before.count(OLD) == 1, 'unique owned current task-index status')
        after = before.replace(OLD, NEW, 1)
        failure = load('checks.json')['size']
        write('index-before.md', before)
        write('index-after.md', after)
        write('first-size-refusal.json', canonical(failure))
        command = ['perl', '-e', NATIVE, str(BASE / 'index-before.md'), str(BASE / 'index-after.md')]
        result = subprocess.run(command, capture_output=True)
        native = dict(command=command, programme=NATIVE, status=result.returncode, stdout=result.stdout.decode(), stderr=result.stderr.decode())
        write('native-width.json', canonical(native))
        qualified = check(before, after, failure, native)
        need(local(INDEX).read_bytes() == before, 'whole live index epoch before owned repair')
        local(INDEX).write_bytes(after)
        write('proof.json', canonical(dict(owner=OWNER, revision=REVISION,
            scope='Dated whole task-index pointer shortening only. Original Task/Goal/Acceptance, sealed candidate namespace, book prose, source/native/products and every allowance remain unchanged.', qualification=qualified,
            legs=dict(rederive='Exact fixed cb5d85b9 index plus the sole construction-status update and whole byte-preserving pointer replacement.',
                      falsify='Complete first actual size refusal and separate native Perl whole byte/line/width census prove the original exceeds and replacement fits the unchanged bound.',
                      durability='Complete before/after index bodies, actual failed gate/programmes/streams, full native command/outcome and strict own manifest in the owning commit.'))))
        write('manifest.json', canonical(catalog()))
    print('PASS whole dated task-index frontier shortening, actual first refusal and separate native byte-width parity; all allowances remain unchanged.')


if __name__ == '__main__':
    main()
